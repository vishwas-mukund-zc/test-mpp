#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class ZmsKmmConstantsCONFIGCompanion, ZmsKmmConstantsDBCompanion, ZmsKmmLogCompanion, ZmsKmmZMSNotificationName, ZmsKmmKotlinEnumCompanion, ZmsKmmKotlinEnum<E>, ZmsKmmPlatformType, ZmsKmmKotlinArray<T>, ZmsKmmPrivateKeysSegment, ZmsKmmZMSStorageZMSStorageKey, ZmsKmmZAddressTypeCompanion, ZmsKmmZAddressType, ZmsKmmZMSGeoFenceCompanion, ZmsKmmZMSGeoFence, ZmsKmmZMSSettingGeofenceDataCompanion, ZmsKmmZMSSettingGeofenceData, ZmsKmmZMSEnvironment, ZmsKmmZMSError, ZmsKmmZMSVehicleType, ZmsKmmZMSVehicleTypeVO, ZmsKmmZMSSettingsVOCompanion, ZmsKmmZMSSettingsVO, ZmsKmmZMSVehicleTypeCompanion, ZmsKmmZMSVehicleTypeVOCompanion, ZmsKmmSegmentUtilCompanion, ZmsKmmSegmentUtil, ZmsKmmSegmentUtilSegmentKeyCompanion, ZmsKmmSegmentUtilSegmentsCategoryCompanion, ZmsKmmSegmentUtilSegmentsParamsCompanion, ZmsKmmSegmentsWriteKey, ZmsKmmSegmentConfiguration, ZmsKmmSegmentsCompanion, SEGAnalytics, ZmsKmmSegments, ZmsKmmZCPLoginRequestOTP, ZmsKmmZMSLoginAssociatedIdentityCompanion, ZmsKmmZMSLoginAssociatedIdentity, ZmsKmmZMSLoginPhoneCountryVOCompanion, ZmsKmmZMSLoginPhoneCountryVO, ZmsKmmZMSLoginPhoneExtensionVOCompanion, ZmsKmmZMSLoginUserPhoneVOCompanion, ZmsKmmZMSLoginUserTypeCompanion, ZmsKmmZMSLoginUserType, ZmsKmmZMSLoginUserPhoneVO, ZmsKmmZMSLoginUserVOCompanion, ZmsKmmZMSLoginUserVO, ZmsKmmZMSLoginVOCompanion, ZmsKmmZMSLoginValidateVOCompanion, ZmsKmmZMSParamsCompanion, ZmsKmmZMSHttpMethod, ZmsKmmKtor_httpHttpMethod, ZmsKmmZMSBaseResponseCompanion, ZmsKmmZMSBaseResponse, ZmsKmmZMSEndPoint, ZmsKmmZMSMockType, ZmsKmmZMSBaseBodyParam, ZmsKmmKtor_client_coreHttpResponse, ZmsKmmKotlinUnit, ZmsKmmKtor_client_coreHttpClient, ZmsKmmZMSBaseBodyParamCompanion, ZmsKmmZMSErrorCompanion, ZmsKmmTripRemovalReason, ZmsKmmZMSLifetimeScoreVO, ZmsKmmZCPTripData, ZmsKmmZMSTripScoreVO, ZmsKmmZMSTripAlertType, ZmsKmmZMSAlertOverviewVOCompanion, ZmsKmmZMSAlertOverviewVO, ZmsKmmZMSHomeVOCompanion, ZmsKmmZMSHomeVO, ZmsKmmZMSPerformanceTipVO, ZmsKmmZMSLifetimeScoreVOCompanion, ZmsKmmZMSScoreCategoryType, ZmsKmmZMSPerformanceTipVOCompanion, ZmsKmmZMSScoreCategoryTypeCompanion, ZmsKmmZMSTripRankScaleVOCompanion, ZmsKmmZMSTripRankScaleVO, ZmsKmmZMSTripVO, ZmsKmmZMSTripScoreVOCompanion, ZmsKmmTripRemovalReasonCompanion, ZmsKmmZMSTripListVOCompanion, ZmsKmmZMSTripListVO, ZmsKmmZMSTripVOCompanion, ZmsKmmZMSAlertTypeVOCompanion, ZmsKmmZMSAlertTypeVO, ZmsKmmZMSTripAlertSeverity, ZmsKmmZMSAlertsVOCompanion, ZmsKmmZMSAlertsVO, ZmsKmmZMSTripAlertVO, ZmsKmmZMSTripAlertSeverityCompanion, ZmsKmmZMSTripAlertTypeCompanion, ZmsKmmZMSTripAlertVOCompanion, ZmsKmmEventType, ZmsKmmTripUploadResponseCompanion, ZmsKmmTripUploadResponse, ZmsKmmTripPoint, ZmsKmmTrip, ZmsKmmZMSTripRepository, ZmsKmmRuntimeQuery<__covariant RowType>, ZmsKmmZmsDbCompanion, ZmsKmmZMSLogSegments, ZmsKmmKotlinx_serialization_jsonJson, ZmsKmmKodein_diDIModule, ZmsKmmKodein_diLazyDI, ZmsKmmKtor_httpHttpMethodCompanion, ZmsKmmKotlinThrowable, ZmsKmmKotlinException, ZmsKmmKotlinRuntimeException, ZmsKmmKotlinIllegalStateException, ZmsKmmKtor_client_coreHttpClientCall, ZmsKmmKtor_utilsGMTDate, ZmsKmmKtor_httpHttpStatusCode, ZmsKmmKtor_httpHttpProtocolVersion, ZmsKmmKtor_client_coreHttpClientEngineConfig, ZmsKmmKtor_client_coreHttpClientConfig<T>, ZmsKmmKtor_client_coreHttpRequestBuilder, ZmsKmmKotlinx_coroutines_coreCoroutineDispatcher, ZmsKmmKtor_client_coreHttpReceivePipeline, ZmsKmmKtor_client_coreHttpRequestPipeline, ZmsKmmKtor_client_coreHttpResponsePipeline, ZmsKmmKtor_client_coreHttpSendPipeline, ZmsKmmRuntimeTransacterTransaction, ZmsKmmKotlinx_serialization_coreSerializersModule, ZmsKmmKotlinx_serialization_jsonJsonConfiguration, ZmsKmmKotlinx_serialization_jsonJsonDefault, ZmsKmmKotlinx_serialization_jsonJsonElement, ZmsKmmKodein_diDITrigger, ZmsKmmKotlinx_serialization_coreSerialKind, ZmsKmmKotlinNothing, ZmsKmmKtor_client_coreHttpClientCallCompanion, ZmsKmmKtor_client_coreTypeInfo, ZmsKmmKtor_ioMemory, ZmsKmmKtor_ioIoBuffer, ZmsKmmKotlinByteArray, ZmsKmmKtor_ioByteReadPacket, ZmsKmmKtor_ioByteOrder, ZmsKmmKtor_utilsGMTDateCompanion, ZmsKmmKtor_utilsWeekDay, ZmsKmmKtor_utilsMonth, ZmsKmmKtor_httpHttpStatusCodeCompanion, ZmsKmmKtor_httpHttpProtocolVersionCompanion, ZmsKmmKtor_client_coreHttpRequestData, ZmsKmmKtor_client_coreHttpResponseData, ZmsKmmKtor_client_coreProxyConfig, ZmsKmmKtor_httpHeadersBuilder, ZmsKmmKtor_client_coreHttpRequestBuilderCompanion, ZmsKmmKtor_httpURLBuilder, ZmsKmmKtor_utilsAttributeKey<T>, ZmsKmmKotlinAbstractCoroutineContextElement, ZmsKmmKotlinx_coroutines_coreCoroutineDispatcherKey, ZmsKmmKtor_utilsPipelinePhase, ZmsKmmKtor_utilsPipeline<TSubject, TContext>, ZmsKmmKtor_client_coreHttpReceivePipelinePhases, ZmsKmmKtor_client_coreHttpRequestPipelinePhases, ZmsKmmKtor_client_coreHttpResponsePipelinePhases, ZmsKmmKtor_client_coreHttpResponseContainer, ZmsKmmKtor_client_coreHttpSendPipelinePhases, ZmsKmmKotlinx_serialization_jsonJsonElementCompanion, ZmsKmmKodein_diDIKey<__contravariant C, __contravariant A, __covariant T>, ZmsKmmKtor_httpOutgoingContent, ZmsKmmKtor_httpUrl, ZmsKmmKtor_ioMemoryCompanion, ZmsKmmKtor_ioBufferCompanion, ZmsKmmKtor_ioBuffer, ZmsKmmKtor_ioChunkBuffer, ZmsKmmKtor_ioChunkBufferCompanion, ZmsKmmKotlinCharArray, ZmsKmmKtor_ioIoBufferCompanion, ZmsKmmKotlinByteIterator, ZmsKmmKtor_ioAbstractInputCompanion, ZmsKmmKtor_ioAbstractInput, ZmsKmmKtor_ioByteReadPacketBaseCompanion, ZmsKmmKtor_ioByteReadPacketBase, ZmsKmmKtor_ioByteReadPacketPlatformBase, ZmsKmmKtor_ioByteReadPacketCompanion, ZmsKmmKtor_ioByteOrderCompanion, ZmsKmmKtor_utilsWeekDayCompanion, ZmsKmmKtor_utilsMonthCompanion, ZmsKmmKtor_utilsStringValuesBuilder, ZmsKmmKtor_httpURLProtocol, ZmsKmmKtor_httpParametersBuilder, ZmsKmmKtor_httpURLBuilderCompanion, ZmsKmmKotlinCancellationException, ZmsKmmKotlinAbstractCoroutineContextKey<B, E>, ZmsKmmKodein_diScopeRegistry, ZmsKmmKodein_diDIDefinition<C, A, T>, ZmsKmmKotlinTriple<__covariant A, __covariant B, __covariant C>, ZmsKmmKodein_diSearchSpecs, ZmsKmmKotlinKTypeProjection, ZmsKmmKtor_httpContentType, ZmsKmmKtor_httpUrlCompanion, ZmsKmmKotlinCharIterator, ZmsKmmKtor_httpURLProtocolCompanion, ZmsKmmKtor_httpUrlEncodingOption, ZmsKmmKodein_diReference<__covariant T>, ZmsKmmKodein_diDIDefining<C, A, T>, ZmsKmmKotlinKVariance, ZmsKmmKotlinKTypeProjectionCompanion, ZmsKmmKtor_httpHeaderValueParam, ZmsKmmKtor_httpHeaderValueWithParametersCompanion, ZmsKmmKtor_httpHeaderValueWithParameters, ZmsKmmKtor_httpContentTypeCompanion, ZmsKmmKotlinx_coroutines_coreAtomicDesc, ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp, ZmsKmmKotlinx_coroutines_coreAtomicOp<__contravariant T>, ZmsKmmKotlinx_coroutines_coreOpDescriptor, ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode, ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc, ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<T>, ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<T>;

@protocol ZmsKmmKotlinComparable, ZmsKmmKotlinx_serialization_coreKSerializer, ZmsKmmZMSBaseEndPoint, ZmsKmmZMSBaseEnvironment, ZmsKmmZmsDb, ZmsKmmKotlinx_coroutines_coreCoroutineScope, ZmsKmmRuntimeTransactionWithoutReturn, ZmsKmmRuntimeTransactionWithReturn, ZmsKmmRuntimeTransacter, ZmsKmmTripPointQueries, ZmsKmmTripQueries, ZmsKmmRuntimeSqlDriver, ZmsKmmRuntimeSqlDriverSchema, ZmsKmmObservableSettings, ZmsKmmZMSDateTimeFormatter, ZmsKmmKotlinCoroutineContext, ZmsKmmSharedPrefs, ZmsKmmKotlinIterator, ZmsKmmKotlinx_serialization_coreEncoder, ZmsKmmKotlinx_serialization_coreSerialDescriptor, ZmsKmmKotlinx_serialization_coreSerializationStrategy, ZmsKmmKotlinx_serialization_coreDecoder, ZmsKmmKotlinx_serialization_coreDeserializationStrategy, ZmsKmmKtor_httpHeaders, ZmsKmmKtor_httpHttpMessage, ZmsKmmKtor_ioByteReadChannel, ZmsKmmKtor_ioCloseable, ZmsKmmKtor_client_coreHttpClientEngine, ZmsKmmKtor_client_coreHttpClientEngineCapability, ZmsKmmKtor_utilsAttributes, ZmsKmmRuntimeSqlCursor, ZmsKmmRuntimeQueryListener, ZmsKmmRuntimeTransactionCallbacks, ZmsKmmRuntimeSqlPreparedStatement, ZmsKmmRuntimeCloseable, ZmsKmmKotlinCoroutineContextElement, ZmsKmmKotlinCoroutineContextKey, ZmsKmmKotlinx_serialization_coreSerialFormat, ZmsKmmKotlinx_serialization_coreStringFormat, ZmsKmmKodein_diDIBuilder, ZmsKmmKodein_diDIContainer, ZmsKmmKodein_diDI, ZmsKmmKodein_diDIContext, ZmsKmmKodein_diDIAware, ZmsKmmKotlinKProperty, ZmsKmmKotlinx_serialization_coreCompositeEncoder, ZmsKmmKotlinAnnotation, ZmsKmmKotlinx_serialization_coreCompositeDecoder, ZmsKmmKotlinMapEntry, ZmsKmmKtor_utilsStringValues, ZmsKmmKtor_utilsTypeInfo, ZmsKmmKtor_client_coreHttpRequest, ZmsKmmKtor_ioReadSession, ZmsKmmKotlinSuspendFunction1, ZmsKmmKotlinAppendable, ZmsKmmKtor_client_coreHttpClientFeature, ZmsKmmKtor_httpHttpMessageBuilder, ZmsKmmKotlinx_coroutines_coreJob, ZmsKmmKotlinContinuation, ZmsKmmKotlinContinuationInterceptor, ZmsKmmKotlinx_coroutines_coreRunnable, ZmsKmmKotlinSuspendFunction2, ZmsKmmKotlinx_serialization_coreSerializersModuleCollector, ZmsKmmKotlinKClass, ZmsKmmKodein_diDIBuilderDirectBinder, ZmsKmmKodein_diDIBinding, ZmsKmmKodein_diDIBuilderTypeBinder, ZmsKmmKodein_typeTypeToken, ZmsKmmKodein_diContextTranslator, ZmsKmmKodein_diDIBuilderConstantBinder, ZmsKmmKodein_diDirectDI, ZmsKmmKodein_diDIContainerBuilder, ZmsKmmKodein_diDIBindBuilder, ZmsKmmKodein_diScope, ZmsKmmKodein_diDIBindBuilderWithScope, ZmsKmmKodein_diDITree, ZmsKmmKotlinLazy, ZmsKmmKotlinKType, ZmsKmmKotlinKAnnotatedElement, ZmsKmmKotlinKCallable, ZmsKmmKtor_ioObjectPool, ZmsKmmKtor_ioInput, ZmsKmmKtor_ioOutput, ZmsKmmKotlinFunction, ZmsKmmKotlinx_coroutines_coreChildHandle, ZmsKmmKotlinx_coroutines_coreChildJob, ZmsKmmKotlinx_coroutines_coreDisposableHandle, ZmsKmmKotlinSequence, ZmsKmmKotlinx_coroutines_coreSelectClause0, ZmsKmmKotlinKDeclarationContainer, ZmsKmmKotlinKClassifier, ZmsKmmKodein_diDIBindingCopier, ZmsKmmKodein_diBindingDI, ZmsKmmKodein_diBinding, ZmsKmmKodein_diDirectDIAware, ZmsKmmKodein_diDirectDIBase, ZmsKmmKodein_diExternalSource, ZmsKmmKtor_httpParameters, ZmsKmmKotlinx_coroutines_coreParentJob, ZmsKmmKotlinx_coroutines_coreSelectInstance, ZmsKmmKotlinSuspendFunction0, ZmsKmmKodein_diWithContext, ZmsKmmKodein_diScopeCloseable;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface ZmsKmmBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end;

@interface ZmsKmmBase (ZmsKmmBaseCopying) <NSCopying>
@end;

__attribute__((swift_name("KotlinMutableSet")))
@interface ZmsKmmMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end;

__attribute__((swift_name("KotlinMutableDictionary")))
@interface ZmsKmmMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end;

@interface NSError (NSErrorZmsKmmKotlinException)
@property (readonly) id _Nullable kotlinException;
@end;

__attribute__((swift_name("KotlinNumber")))
@interface ZmsKmmNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end;

__attribute__((swift_name("KotlinByte")))
@interface ZmsKmmByte : ZmsKmmNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end;

__attribute__((swift_name("KotlinUByte")))
@interface ZmsKmmUByte : ZmsKmmNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end;

__attribute__((swift_name("KotlinShort")))
@interface ZmsKmmShort : ZmsKmmNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end;

__attribute__((swift_name("KotlinUShort")))
@interface ZmsKmmUShort : ZmsKmmNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end;

__attribute__((swift_name("KotlinInt")))
@interface ZmsKmmInt : ZmsKmmNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end;

__attribute__((swift_name("KotlinUInt")))
@interface ZmsKmmUInt : ZmsKmmNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end;

__attribute__((swift_name("KotlinLong")))
@interface ZmsKmmLong : ZmsKmmNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end;

__attribute__((swift_name("KotlinULong")))
@interface ZmsKmmULong : ZmsKmmNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end;

__attribute__((swift_name("KotlinFloat")))
@interface ZmsKmmFloat : ZmsKmmNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end;

__attribute__((swift_name("KotlinDouble")))
@interface ZmsKmmDouble : ZmsKmmNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end;

__attribute__((swift_name("KotlinBoolean")))
@interface ZmsKmmBoolean : ZmsKmmNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Constants")))
@interface ZmsKmmConstants : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Constants.CONFIG")))
@interface ZmsKmmConstantsCONFIG : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) ZmsKmmConstantsCONFIGCompanion *companion __attribute__((swift_name("companion")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Constants.CONFIGCompanion")))
@interface ZmsKmmConstantsCONFIGCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmConstantsCONFIGCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) int32_t ANDROID_SDK_VERSION __attribute__((swift_name("ANDROID_SDK_VERSION")));
@property (readonly) int32_t IOS_SDK_VERSION __attribute__((swift_name("IOS_SDK_VERSION")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Constants.DB")))
@interface ZmsKmmConstantsDB : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) ZmsKmmConstantsDBCompanion *companion __attribute__((swift_name("companion")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Constants.DBCompanion")))
@interface ZmsKmmConstantsDBCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmConstantsDBCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *DATABASE_NAME __attribute__((swift_name("DATABASE_NAME")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Log")))
@interface ZmsKmmLog : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) ZmsKmmLogCompanion *companion __attribute__((swift_name("companion")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Log.Companion")))
@interface ZmsKmmLogCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmLogCompanion *shared __attribute__((swift_name("shared")));
- (void)dMessage:(NSString *)message __attribute__((swift_name("d(message:)")));
- (void)eMessage:(NSString *)message __attribute__((swift_name("e(message:)")));
- (void)iMessage:(NSString *)message __attribute__((swift_name("i(message:)")));
- (void)vMessage:(NSString *)message __attribute__((swift_name("v(message:)")));
- (void)wMessage:(NSString *)message __attribute__((swift_name("w(message:)")));
@end;

__attribute__((swift_name("Logger")))
@protocol ZmsKmmLogger
@required
- (void)logMessage:(NSString *)message __attribute__((swift_name("log(message:)")));
@end;

__attribute__((swift_name("ObservableSettings")))
@protocol ZmsKmmObservableSettings
@required
- (void)postNotificationNotificationName:(ZmsKmmZMSNotificationName *)notificationName userInfo:(NSDictionary<id, id> * _Nullable)userInfo __attribute__((swift_name("postNotification(notificationName:userInfo:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Platform")))
@interface ZmsKmmPlatform : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (readonly) NSString *deviceId __attribute__((swift_name("deviceId")));
@property (readonly) NSString *deviceMake __attribute__((swift_name("deviceMake")));
@property (readonly) NSString *osVersion __attribute__((swift_name("osVersion")));
@property (readonly) NSString *platform __attribute__((swift_name("platform")));
@property (readonly) int32_t skdVersion __attribute__((swift_name("skdVersion")));
@end;

__attribute__((swift_name("KotlinComparable")))
@protocol ZmsKmmKotlinComparable
@required
- (int32_t)compareToOther:(id _Nullable)other __attribute__((swift_name("compareTo(other:)")));
@end;

__attribute__((swift_name("KotlinEnum")))
@interface ZmsKmmKotlinEnum<E> : ZmsKmmBase <ZmsKmmKotlinComparable>
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKotlinEnumCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(E)other __attribute__((swift_name("compareTo(other:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t ordinal __attribute__((swift_name("ordinal")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformType")))
@interface ZmsKmmPlatformType : ZmsKmmKotlinEnum<ZmsKmmPlatformType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) ZmsKmmPlatformType *ios __attribute__((swift_name("ios")));
@property (class, readonly) ZmsKmmPlatformType *android __attribute__((swift_name("android")));
+ (ZmsKmmKotlinArray<ZmsKmmPlatformType *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivateKeys")))
@interface ZmsKmmPrivateKeys : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) ZmsKmmPrivateKeysSegment *companion __attribute__((swift_name("companion")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PrivateKeys.Segment")))
@interface ZmsKmmPrivateKeysSegment : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)segment __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmPrivateKeysSegment *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *androidKey __attribute__((swift_name("androidKey")));
@property (readonly) NSString *iosKey __attribute__((swift_name("iosKey")));
@end;

__attribute__((swift_name("SharedPrefs")))
@protocol ZmsKmmSharedPrefs
@required
- (ZmsKmmBoolean * _Nullable)getBooleanKey:(NSString *)key __attribute__((swift_name("getBoolean(key:)")));
- (ZmsKmmDouble * _Nullable)getDoubleKey:(NSString *)key __attribute__((swift_name("getDouble(key:)")));
- (int32_t)getIntKey:(NSString *)key __attribute__((swift_name("getInt(key:)")));
- (NSString * _Nullable)getStringKey:(NSString *)key __attribute__((swift_name("getString(key:)")));
- (void)setBooleanKey:(NSString *)key value:(BOOL)value __attribute__((swift_name("setBoolean(key:value:)")));
- (void)setDoubleKey:(NSString *)key value:(double)value __attribute__((swift_name("setDouble(key:value:)")));
- (void)setIntKey:(NSString *)key value:(int32_t)value __attribute__((swift_name("setInt(key:value:)")));
- (void)setStringKey:(NSString *)key value:(NSString *)value __attribute__((swift_name("setString(key:value:)")));
@end;

__attribute__((swift_name("ZMSDateTimeFormatter")))
@protocol ZmsKmmZMSDateTimeFormatter
@required
- (NSString *)epochToDateEpoch:(int64_t)epoch format:(NSString *)format __attribute__((swift_name("epochToDate(epoch:format:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSStorage")))
@interface ZmsKmmZMSStorage : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property NSString *authToken __attribute__((swift_name("authToken")));
@property BOOL isLoggedIn __attribute__((swift_name("isLoggedIn")));
@property (readonly) BOOL isUserDataStored __attribute__((swift_name("isUserDataStored")));
@property NSString *merchantId __attribute__((swift_name("merchantId")));
@property NSString *merchantUserToken __attribute__((swift_name("merchantUserToken")));
@property BOOL onboarding_done __attribute__((swift_name("onboarding_done")));
@property NSString *phoneNumber __attribute__((swift_name("phoneNumber")));
@property NSString *tripSessionId __attribute__((swift_name("tripSessionId")));
@property NSString *userCarName __attribute__((swift_name("userCarName")));
@property NSString *userCarType __attribute__((swift_name("userCarType")));
@property NSString *userHomeAddress __attribute__((swift_name("userHomeAddress")));
@property double userHomeLat __attribute__((swift_name("userHomeLat")));
@property double userHomeLng __attribute__((swift_name("userHomeLng")));
@property NSString *userId __attribute__((swift_name("userId")));
@property NSString *userWorkAddress __attribute__((swift_name("userWorkAddress")));
@property double userWorkLat __attribute__((swift_name("userWorkLat")));
@property double userWorkLng __attribute__((swift_name("userWorkLng")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSStorage.ZMSStorageKey")))
@interface ZmsKmmZMSStorageZMSStorageKey : ZmsKmmKotlinEnum<ZmsKmmZMSStorageZMSStorageKey *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *email __attribute__((swift_name("email")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *authtoken __attribute__((swift_name("authtoken")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *isloggedin __attribute__((swift_name("isloggedin")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *userhomelat __attribute__((swift_name("userhomelat")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *userhomelng __attribute__((swift_name("userhomelng")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *userhomeAddr __attribute__((swift_name("userhomeAddr")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *userworklat __attribute__((swift_name("userworklat")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *userworklng __attribute__((swift_name("userworklng")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *userworkAddr __attribute__((swift_name("userworkAddr")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *usercartype __attribute__((swift_name("usercartype")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *usercarname __attribute__((swift_name("usercarname")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *tripSessionId __attribute__((swift_name("tripSessionId")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *onboardingDone __attribute__((swift_name("onboardingDone")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *userId __attribute__((swift_name("userId")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *phoneNumber __attribute__((swift_name("phoneNumber")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *merchantId __attribute__((swift_name("merchantId")));
@property (class, readonly) ZmsKmmZMSStorageZMSStorageKey *merchantUserToken __attribute__((swift_name("merchantUserToken")));
+ (ZmsKmmKotlinArray<ZmsKmmZMSStorageZMSStorageKey *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZAddressType")))
@interface ZmsKmmZAddressType : ZmsKmmKotlinEnum<ZmsKmmZAddressType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmZAddressTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) ZmsKmmZAddressType *home __attribute__((swift_name("home")));
@property (class, readonly) ZmsKmmZAddressType *work __attribute__((swift_name("work")));
+ (ZmsKmmKotlinArray<ZmsKmmZAddressType *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZAddressType.Companion")))
@interface ZmsKmmZAddressTypeCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZAddressTypeCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSGeoFence")))
@interface ZmsKmmZMSGeoFence : ZmsKmmBase
- (instancetype)initWithLabel:(ZmsKmmZAddressType * _Nullable)label lat:(ZmsKmmDouble * _Nullable)lat lng:(ZmsKmmDouble * _Nullable)lng address:(NSString * _Nullable)address __attribute__((swift_name("init(label:lat:lng:address:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSGeoFenceCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmZAddressType * _Nullable)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmDouble * _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmDouble * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()")));
- (ZmsKmmZMSGeoFence *)doCopyLabel:(ZmsKmmZAddressType * _Nullable)label lat:(ZmsKmmDouble * _Nullable)lat lng:(ZmsKmmDouble * _Nullable)lng address:(NSString * _Nullable)address __attribute__((swift_name("doCopy(label:lat:lng:address:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable address __attribute__((swift_name("address")));
@property (readonly) ZmsKmmZAddressType * _Nullable label __attribute__((swift_name("label")));
@property (readonly) ZmsKmmDouble * _Nullable lat __attribute__((swift_name("lat")));
@property (readonly) ZmsKmmDouble * _Nullable lng __attribute__((swift_name("lng")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSGeoFence.Companion")))
@interface ZmsKmmZMSGeoFenceCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSGeoFenceCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSSettingGeofenceData")))
@interface ZmsKmmZMSSettingGeofenceData : ZmsKmmBase
- (instancetype)initWithLat:(ZmsKmmDouble * _Nullable)lat lng:(ZmsKmmDouble * _Nullable)lng address:(NSString * _Nullable)address label:(ZmsKmmZAddressType * _Nullable)label __attribute__((swift_name("init(lat:lng:address:label:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSSettingGeofenceDataCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmDouble * _Nullable)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmDouble * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (ZmsKmmZAddressType * _Nullable)component4 __attribute__((swift_name("component4()")));
- (ZmsKmmZMSSettingGeofenceData *)doCopyLat:(ZmsKmmDouble * _Nullable)lat lng:(ZmsKmmDouble * _Nullable)lng address:(NSString * _Nullable)address label:(ZmsKmmZAddressType * _Nullable)label __attribute__((swift_name("doCopy(lat:lng:address:label:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable address __attribute__((swift_name("address")));
@property (readonly) ZmsKmmZAddressType * _Nullable label __attribute__((swift_name("label")));
@property (readonly) ZmsKmmDouble * _Nullable lat __attribute__((swift_name("lat")));
@property (readonly) ZmsKmmDouble * _Nullable lng __attribute__((swift_name("lng")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSSettingGeofenceData.Companion")))
@interface ZmsKmmZMSSettingGeofenceDataCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSSettingGeofenceDataCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSSettingsVM")))
@interface ZmsKmmZMSSettingsVM : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)fetchSettingsCarEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("fetchSettings(carEnvironment:isMock:completionHandler:)")));
- (void)updateSettingsVehicleType:(ZmsKmmZMSVehicleType * _Nullable)vehicleType brandAndMake:(NSString * _Nullable)brandAndMake geoFences:(NSArray<ZmsKmmZMSSettingGeofenceData *> * _Nullable)geoFences carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("updateSettings(vehicleType:brandAndMake:geoFences:carEnvironment:isMock:completionHandler:)")));
@property (readonly) NSArray<ZmsKmmZMSGeoFence *> * _Nullable geoFences __attribute__((swift_name("geoFences")));
@property (readonly) NSString * _Nullable userVehicleBrandAndMake __attribute__((swift_name("userVehicleBrandAndMake")));
@property (readonly) ZmsKmmZMSVehicleType * _Nullable userVehicleType __attribute__((swift_name("userVehicleType")));
@property (readonly) NSArray<ZmsKmmZMSVehicleTypeVO *> * _Nullable vehicleTypes __attribute__((swift_name("vehicleTypes")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSSettingsVO")))
@interface ZmsKmmZMSSettingsVO : ZmsKmmBase
- (instancetype)initWithVehicleTypes:(NSArray<ZmsKmmZMSVehicleTypeVO *> * _Nullable)vehicleTypes userVehicleType:(ZmsKmmZMSVehicleType * _Nullable)userVehicleType userVehicleBrandAndMake:(NSString * _Nullable)userVehicleBrandAndMake userGeoFences:(NSArray<ZmsKmmZMSGeoFence *> * _Nullable)userGeoFences __attribute__((swift_name("init(vehicleTypes:userVehicleType:userVehicleBrandAndMake:userGeoFences:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSSettingsVOCompanion *companion __attribute__((swift_name("companion")));
- (NSArray<ZmsKmmZMSVehicleTypeVO *> * _Nullable)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmZMSVehicleType * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSArray<ZmsKmmZMSGeoFence *> * _Nullable)component4 __attribute__((swift_name("component4()")));
- (ZmsKmmZMSSettingsVO *)doCopyVehicleTypes:(NSArray<ZmsKmmZMSVehicleTypeVO *> * _Nullable)vehicleTypes userVehicleType:(ZmsKmmZMSVehicleType * _Nullable)userVehicleType userVehicleBrandAndMake:(NSString * _Nullable)userVehicleBrandAndMake userGeoFences:(NSArray<ZmsKmmZMSGeoFence *> * _Nullable)userGeoFences __attribute__((swift_name("doCopy(vehicleTypes:userVehicleType:userVehicleBrandAndMake:userGeoFences:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<ZmsKmmZMSGeoFence *> * _Nullable userGeoFences __attribute__((swift_name("userGeoFences")));
@property (readonly) NSString * _Nullable userVehicleBrandAndMake __attribute__((swift_name("userVehicleBrandAndMake")));
@property (readonly) ZmsKmmZMSVehicleType * _Nullable userVehicleType __attribute__((swift_name("userVehicleType")));
@property (readonly) NSArray<ZmsKmmZMSVehicleTypeVO *> * _Nullable vehicleTypes __attribute__((swift_name("vehicleTypes")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSSettingsVO.Companion")))
@interface ZmsKmmZMSSettingsVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSSettingsVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSVehicleType")))
@interface ZmsKmmZMSVehicleType : ZmsKmmKotlinEnum<ZmsKmmZMSVehicleType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmZMSVehicleTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) ZmsKmmZMSVehicleType *suv __attribute__((swift_name("suv")));
@property (class, readonly) ZmsKmmZMSVehicleType *hatchback __attribute__((swift_name("hatchback")));
@property (class, readonly) ZmsKmmZMSVehicleType *sedan __attribute__((swift_name("sedan")));
+ (ZmsKmmKotlinArray<ZmsKmmZMSVehicleType *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSVehicleType.Companion")))
@interface ZmsKmmZMSVehicleTypeCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSVehicleTypeCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSVehicleTypeVO")))
@interface ZmsKmmZMSVehicleTypeVO : ZmsKmmBase
- (instancetype)initWithTitle:(NSString * _Nullable)title vehicleType:(ZmsKmmZMSVehicleType * _Nullable)vehicleType __attribute__((swift_name("init(title:vehicleType:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSVehicleTypeVOCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmZMSVehicleType * _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmZMSVehicleTypeVO *)doCopyTitle:(NSString * _Nullable)title vehicleType:(ZmsKmmZMSVehicleType * _Nullable)vehicleType __attribute__((swift_name("doCopy(title:vehicleType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@property (readonly) ZmsKmmZMSVehicleType * _Nullable vehicleType __attribute__((swift_name("vehicleType")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSVehicleTypeVO.Companion")))
@interface ZmsKmmZMSVehicleTypeVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSVehicleTypeVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SegmentUtil")))
@interface ZmsKmmSegmentUtil : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) ZmsKmmSegmentUtilCompanion *companion __attribute__((swift_name("companion")));
- (void)sendEventCategory:(NSString *)category data:(ZmsKmmMutableDictionary<id, id> *)data __attribute__((swift_name("sendEvent(category:data:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SegmentUtil.Companion")))
@interface ZmsKmmSegmentUtilCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmSegmentUtilCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmSegmentUtil *)getInstance __attribute__((swift_name("getInstance()")));
- (void)setUpSDKContext:(id _Nullable)context __attribute__((swift_name("setUpSDK(context:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SegmentUtil.SegmentKey")))
@interface ZmsKmmSegmentUtilSegmentKey : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) ZmsKmmSegmentUtilSegmentKeyCompanion *companion __attribute__((swift_name("companion")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SegmentUtil.SegmentKeyCompanion")))
@interface ZmsKmmSegmentUtilSegmentKeyCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmSegmentUtilSegmentKeyCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *MESSAGE __attribute__((swift_name("MESSAGE")));
@property (readonly) NSString *TAG __attribute__((swift_name("TAG")));
@property (readonly) NSString *TIMESTAMP __attribute__((swift_name("TIMESTAMP")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SegmentUtil.SegmentsCategory")))
@interface ZmsKmmSegmentUtilSegmentsCategory : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) ZmsKmmSegmentUtilSegmentsCategoryCompanion *companion __attribute__((swift_name("companion")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SegmentUtil.SegmentsCategoryCompanion")))
@interface ZmsKmmSegmentUtilSegmentsCategoryCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmSegmentUtilSegmentsCategoryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *LOG __attribute__((swift_name("LOG")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SegmentUtil.SegmentsParams")))
@interface ZmsKmmSegmentUtilSegmentsParams : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) ZmsKmmSegmentUtilSegmentsParamsCompanion *companion __attribute__((swift_name("companion")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SegmentUtil.SegmentsParamsCompanion")))
@interface ZmsKmmSegmentUtilSegmentsParamsCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmSegmentUtilSegmentsParamsCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSString *DEVICE_ID __attribute__((swift_name("DEVICE_ID")));
@property (readonly) NSString *PHONE_NUMBER __attribute__((swift_name("PHONE_NUMBER")));
@property (readonly) NSString *TRIP_ID __attribute__((swift_name("TRIP_ID")));
@property (readonly) NSString *USER_ID __attribute__((swift_name("USER_ID")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SegmentConfiguration")))
@interface ZmsKmmSegmentConfiguration : ZmsKmmBase
- (instancetype)initWithWriteKey:(ZmsKmmSegmentsWriteKey *)writeKey context:(id _Nullable)context __attribute__((swift_name("init(writeKey:context:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithWriteKey:(NSString *)writeKey application:(id _Nullable)application collectDeviceId:(BOOL)collectDeviceId trackApplicationLifecycleEvents:(BOOL)trackApplicationLifecycleEvents useLifecycleObserver:(BOOL)useLifecycleObserver trackDeepLinks:(BOOL)trackDeepLinks flushAt:(int32_t)flushAt flushInterval:(int32_t)flushInterval apiHost:(NSString * _Nullable)apiHost __attribute__((swift_name("init(writeKey:application:collectDeviceId:trackApplicationLifecycleEvents:useLifecycleObserver:trackDeepLinks:flushAt:flushInterval:apiHost:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (id _Nullable)component2 __attribute__((swift_name("component2()")));
- (BOOL)component3 __attribute__((swift_name("component3()")));
- (BOOL)component4 __attribute__((swift_name("component4()")));
- (BOOL)component5 __attribute__((swift_name("component5()")));
- (BOOL)component6 __attribute__((swift_name("component6()")));
- (int32_t)component7 __attribute__((swift_name("component7()")));
- (int32_t)component8 __attribute__((swift_name("component8()")));
- (NSString * _Nullable)component9 __attribute__((swift_name("component9()")));
- (ZmsKmmSegmentConfiguration *)doCopyWriteKey:(NSString *)writeKey application:(id _Nullable)application collectDeviceId:(BOOL)collectDeviceId trackApplicationLifecycleEvents:(BOOL)trackApplicationLifecycleEvents useLifecycleObserver:(BOOL)useLifecycleObserver trackDeepLinks:(BOOL)trackDeepLinks flushAt:(int32_t)flushAt flushInterval:(int32_t)flushInterval apiHost:(NSString * _Nullable)apiHost __attribute__((swift_name("doCopy(writeKey:application:collectDeviceId:trackApplicationLifecycleEvents:useLifecycleObserver:trackDeepLinks:flushAt:flushInterval:apiHost:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable apiHost __attribute__((swift_name("apiHost")));
@property (readonly) id _Nullable application __attribute__((swift_name("application")));
@property (readonly) BOOL collectDeviceId __attribute__((swift_name("collectDeviceId")));
@property (readonly) int32_t flushAt __attribute__((swift_name("flushAt")));
@property (readonly) int32_t flushInterval __attribute__((swift_name("flushInterval")));
@property (readonly) BOOL trackApplicationLifecycleEvents __attribute__((swift_name("trackApplicationLifecycleEvents")));
@property (readonly) BOOL trackDeepLinks __attribute__((swift_name("trackDeepLinks")));
@property (readonly) BOOL useLifecycleObserver __attribute__((swift_name("useLifecycleObserver")));
@property (readonly) NSString *writeKey __attribute__((swift_name("writeKey")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Segments")))
@interface ZmsKmmSegments : ZmsKmmBase
@property (class, readonly, getter=companion) ZmsKmmSegmentsCompanion *companion __attribute__((swift_name("companion")));
- (void)aliasUserId:(NSString *)userId options:(NSDictionary<id, id> * _Nullable)options __attribute__((swift_name("alias(userId:options:)")));
- (void)groupGroupId:(NSString *)groupId traits:(NSDictionary<id, id> * _Nullable)traits options:(NSDictionary<id, id> * _Nullable)options __attribute__((swift_name("group(groupId:traits:options:)")));
- (void)identifyUserId:(NSString *)userId traits:(NSDictionary<id, id> * _Nullable)traits options:(NSDictionary<id, id> * _Nullable)options __attribute__((swift_name("identify(userId:traits:options:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)screenScreenTitle:(NSString *)screenTitle properties:(NSDictionary<id, id> * _Nullable)properties options:(NSDictionary<id, id> * _Nullable)options __attribute__((swift_name("screen(screenTitle:properties:options:)")));
- (void)trackName:(NSString *)name properties:(NSDictionary<id, id> * _Nullable)properties options:(NSDictionary<id, id> * _Nullable)options __attribute__((swift_name("track(name:properties:options:)")));
@property (readonly) SEGAnalytics *segment __attribute__((swift_name("segment")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Segments.Companion")))
@interface ZmsKmmSegmentsCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmSegmentsCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmSegments *)setupWithConfigurationConfiguration:(ZmsKmmSegmentConfiguration *)configuration __attribute__((swift_name("setupWithConfiguration(configuration:)")));
- (ZmsKmmSegments *)sharedContext:(id _Nullable)context __attribute__((swift_name("shared(context:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("SegmentsWriteKey")))
@interface ZmsKmmSegmentsWriteKey : ZmsKmmBase
- (instancetype)initWithAndroid:(NSString * _Nullable)android ios:(NSString * _Nullable)ios __attribute__((swift_name("init(android:ios:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmSegmentsWriteKey *)doCopyAndroid:(NSString * _Nullable)android ios:(NSString * _Nullable)ios __attribute__((swift_name("doCopy(android:ios:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)keyForPlatform __attribute__((swift_name("keyForPlatform()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable android __attribute__((swift_name("android")));
@property (readonly) NSString * _Nullable ios __attribute__((swift_name("ios")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZCPLoginRequestOTP")))
@interface ZmsKmmZCPLoginRequestOTP : ZmsKmmKotlinEnum<ZmsKmmZCPLoginRequestOTP *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) ZmsKmmZCPLoginRequestOTP *unverifiedphone __attribute__((swift_name("unverifiedphone")));
@property (class, readonly) ZmsKmmZCPLoginRequestOTP *otplogin __attribute__((swift_name("otplogin")));
@property (class, readonly) ZmsKmmZCPLoginRequestOTP *forgotpassword __attribute__((swift_name("forgotpassword")));
@property (class, readonly) ZmsKmmZCPLoginRequestOTP *newnumber __attribute__((swift_name("newnumber")));
+ (ZmsKmmKotlinArray<ZmsKmmZCPLoginRequestOTP *> *)values __attribute__((swift_name("values()")));
@property (readonly) BOOL eOTP __attribute__((swift_name("eOTP")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginAssociatedIdentity")))
@interface ZmsKmmZMSLoginAssociatedIdentity : ZmsKmmKotlinEnum<ZmsKmmZMSLoginAssociatedIdentity *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmZMSLoginAssociatedIdentityCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) ZmsKmmZMSLoginAssociatedIdentity *invalid __attribute__((swift_name("invalid")));
@property (class, readonly) ZmsKmmZMSLoginAssociatedIdentity *phone __attribute__((swift_name("phone")));
@property (class, readonly) ZmsKmmZMSLoginAssociatedIdentity *email __attribute__((swift_name("email")));
+ (ZmsKmmKotlinArray<ZmsKmmZMSLoginAssociatedIdentity *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginAssociatedIdentity.Companion")))
@interface ZmsKmmZMSLoginAssociatedIdentityCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSLoginAssociatedIdentityCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmZMSLoginAssociatedIdentity *)fromIntValue:(int32_t)value __attribute__((swift_name("fromInt(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginPhoneCountryVO")))
@interface ZmsKmmZMSLoginPhoneCountryVO : ZmsKmmBase
- (instancetype)initWithCountry:(NSString * _Nullable)country prefix:(NSString * _Nullable)prefix phoneRegex:(NSString * _Nullable)phoneRegex isDefault:(BOOL)isDefault flagUrl:(NSString * _Nullable)flagUrl __attribute__((swift_name("init(country:prefix:phoneRegex:isDefault:flagUrl:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSLoginPhoneCountryVOCompanion *companion __attribute__((swift_name("companion")));
@property NSString * _Nullable country __attribute__((swift_name("country")));
@property NSString * _Nullable flagUrl __attribute__((swift_name("flagUrl")));
@property BOOL isDefault __attribute__((swift_name("isDefault")));
@property NSString * _Nullable phoneRegex __attribute__((swift_name("phoneRegex")));
@property NSString * _Nullable prefix __attribute__((swift_name("prefix")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginPhoneCountryVO.Companion")))
@interface ZmsKmmZMSLoginPhoneCountryVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSLoginPhoneCountryVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@property (readonly, getter=default) ZmsKmmZMSLoginPhoneCountryVO *default_ __attribute__((swift_name("default_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginPhoneExtensionVO")))
@interface ZmsKmmZMSLoginPhoneExtensionVO : ZmsKmmBase
- (instancetype)initWithPhoneCountries:(NSArray<ZmsKmmZMSLoginPhoneCountryVO *> * _Nullable)phoneCountries __attribute__((swift_name("init(phoneCountries:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSLoginPhoneExtensionVOCompanion *companion __attribute__((swift_name("companion")));
@property NSArray<ZmsKmmZMSLoginPhoneCountryVO *> * _Nullable phoneCountries __attribute__((swift_name("phoneCountries")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginPhoneExtensionVO.Companion")))
@interface ZmsKmmZMSLoginPhoneExtensionVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSLoginPhoneExtensionVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginUserPhoneVO")))
@interface ZmsKmmZMSLoginUserPhoneVO : ZmsKmmBase
- (instancetype)initWithNumber:(NSString * _Nullable)number prefix:(NSString * _Nullable)prefix __attribute__((swift_name("init(number:prefix:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSLoginUserPhoneVOCompanion *companion __attribute__((swift_name("companion")));
@property NSString * _Nullable number __attribute__((swift_name("number")));
@property NSString * _Nullable prefix __attribute__((swift_name("prefix")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginUserPhoneVO.Companion")))
@interface ZmsKmmZMSLoginUserPhoneVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSLoginUserPhoneVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginUserType")))
@interface ZmsKmmZMSLoginUserType : ZmsKmmKotlinEnum<ZmsKmmZMSLoginUserType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmZMSLoginUserTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) ZmsKmmZMSLoginUserType *invalid __attribute__((swift_name("invalid")));
@property (class, readonly) ZmsKmmZMSLoginUserType *theNew __attribute__((swift_name("theNew")));
@property (class, readonly) ZmsKmmZMSLoginUserType *existing __attribute__((swift_name("existing")));
+ (ZmsKmmKotlinArray<ZmsKmmZMSLoginUserType *> *)values __attribute__((swift_name("values()")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginUserType.Companion")))
@interface ZmsKmmZMSLoginUserTypeCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSLoginUserTypeCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmZMSLoginUserType *)fromIntValue:(int32_t)value __attribute__((swift_name("fromInt(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginUserVO")))
@interface ZmsKmmZMSLoginUserVO : ZmsKmmBase
- (instancetype)initWithAuthToken:(NSString * _Nullable)authToken email:(NSString * _Nullable)email userId:(NSString * _Nullable)userId avatarUrl:(NSString * _Nullable)avatarUrl phone:(ZmsKmmZMSLoginUserPhoneVO * _Nullable)phone unverifiedPhone:(ZmsKmmZMSLoginUserPhoneVO * _Nullable)unverifiedPhone phoneVerified:(ZmsKmmBoolean * _Nullable)phoneVerified __attribute__((swift_name("init(authToken:email:userId:avatarUrl:phone:unverifiedPhone:phoneVerified:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSLoginUserVOCompanion *companion __attribute__((swift_name("companion")));
@property NSString * _Nullable authToken __attribute__((swift_name("authToken")));
@property NSString * _Nullable avatarUrl __attribute__((swift_name("avatarUrl")));
@property NSString * _Nullable email __attribute__((swift_name("email")));
@property ZmsKmmZMSLoginUserPhoneVO * _Nullable phone __attribute__((swift_name("phone")));
@property ZmsKmmBoolean * _Nullable phoneVerified __attribute__((swift_name("phoneVerified")));
@property ZmsKmmZMSLoginUserPhoneVO * _Nullable unverifiedPhone __attribute__((swift_name("unverifiedPhone")));
@property NSString * _Nullable userId __attribute__((swift_name("userId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginUserVO.Companion")))
@interface ZmsKmmZMSLoginUserVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSLoginUserVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginVM")))
@interface ZmsKmmZMSLoginVM : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)fetchPhoneExtensionCarEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("fetchPhoneExtension(carEnvironment:isMock:completionHandler:)")));
- (void)getOTPLoginId:(NSString *)loginId type:(ZmsKmmZMSLoginAssociatedIdentity *)type requestCode:(ZmsKmmZCPLoginRequestOTP *)requestCode carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("getOTP(loginId:type:requestCode:carEnvironment:isMock:completionHandler:)")));
- (void)logOutUser __attribute__((swift_name("logOutUser()")));
- (void)loginWithPasswordPassword:(NSString *)password loginId:(NSString *)loginId type:(ZmsKmmZMSLoginAssociatedIdentity *)type carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("loginWithPassword(password:loginId:type:carEnvironment:isMock:completionHandler:)")));
- (void)signUpName:(NSString *)name email:(NSString *)email phone:(NSString *)phone password:(NSString *)password carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("signUp(name:email:phone:password:carEnvironment:isMock:completionHandler:)")));
- (void)validateEmailEmailId:(NSString *)emailId carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("validateEmail(emailId:carEnvironment:isMock:completionHandler:)")));
- (void)validateForSignUpLoginId:(NSString *)loginId type:(ZmsKmmZMSLoginAssociatedIdentity *)type carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("validateForSignUp(loginId:type:carEnvironment:isMock:completionHandler:)")));
- (void)validateMerchantUserMerchantId:(NSString *)merchantId merchantUserToken:(NSString *)merchantUserToken carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("validateMerchantUser(merchantId:merchantUserToken:carEnvironment:isMock:completionHandler:)")));
- (void)validateMobileNumberMobileNumber:(NSString *)mobileNumber carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("validateMobileNumber(mobileNumber:carEnvironment:isMock:completionHandler:)")));
- (void)verifyOTPOtp:(NSString *)otp loginId:(NSString *)loginId type:(ZmsKmmZMSLoginAssociatedIdentity *)type requestCode:(ZmsKmmZCPLoginRequestOTP *)requestCode carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("verifyOTP(otp:loginId:type:requestCode:carEnvironment:isMock:completionHandler:)")));
@property (readonly) ZmsKmmZMSLoginAssociatedIdentity *associationType __attribute__((swift_name("associationType")));
@property (readonly) ZmsKmmZMSLoginUserVO * _Nullable loggedInUser __attribute__((swift_name("loggedInUser")));
@property (readonly) NSArray<ZmsKmmZMSLoginPhoneCountryVO *> *phoneExtensions __attribute__((swift_name("phoneExtensions")));
@property ZmsKmmZMSLoginPhoneCountryVO *selectedPhoneExtension __attribute__((swift_name("selectedPhoneExtension")));
@property (readonly) ZmsKmmZMSLoginUserType *userStatus __attribute__((swift_name("userStatus")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginVO")))
@interface ZmsKmmZMSLoginVO : ZmsKmmBase
- (instancetype)initWithStatus:(ZmsKmmInt * _Nullable)status user:(ZmsKmmZMSLoginUserVO * _Nullable)user __attribute__((swift_name("init(status:user:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSLoginVOCompanion *companion __attribute__((swift_name("companion")));
@property ZmsKmmInt * _Nullable status __attribute__((swift_name("status")));
@property ZmsKmmZMSLoginUserVO * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginVO.Companion")))
@interface ZmsKmmZMSLoginVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSLoginVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginValidateVO")))
@interface ZmsKmmZMSLoginValidateVO : ZmsKmmBase
- (instancetype)initWithUserStatus:(ZmsKmmInt * _Nullable)userStatus associationCode:(ZmsKmmInt * _Nullable)associationCode __attribute__((swift_name("init(userStatus:associationCode:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSLoginValidateVOCompanion *companion __attribute__((swift_name("companion")));
@property ZmsKmmInt * _Nullable associationCode __attribute__((swift_name("associationCode")));
@property ZmsKmmZMSLoginAssociatedIdentity *associationCodeType __attribute__((swift_name("associationCodeType")));
@property ZmsKmmInt * _Nullable userStatus __attribute__((swift_name("userStatus")));
@property ZmsKmmZMSLoginUserType *userStatusType __attribute__((swift_name("userStatusType")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLoginValidateVO.Companion")))
@interface ZmsKmmZMSLoginValidateVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSLoginValidateVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSParams")))
@interface ZmsKmmZMSParams : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) ZmsKmmZMSParamsCompanion *companion __attribute__((swift_name("companion")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSParams.Companion")))
@interface ZmsKmmZMSParamsCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSParamsCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) NSDictionary<NSString *, id> *paramDict __attribute__((swift_name("paramDict")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSHttpMethod")))
@interface ZmsKmmZMSHttpMethod : ZmsKmmKotlinEnum<ZmsKmmZMSHttpMethod *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) ZmsKmmZMSHttpMethod *zget __attribute__((swift_name("zget")));
@property (class, readonly) ZmsKmmZMSHttpMethod *zpost __attribute__((swift_name("zpost")));
@property (class, readonly) ZmsKmmZMSHttpMethod *zput __attribute__((swift_name("zput")));
@property (class, readonly) ZmsKmmZMSHttpMethod *zdelete __attribute__((swift_name("zdelete")));
+ (ZmsKmmKotlinArray<ZmsKmmZMSHttpMethod *> *)values __attribute__((swift_name("values()")));
@property (readonly) ZmsKmmKtor_httpHttpMethod *ktorHttpMethod __attribute__((swift_name("ktorHttpMethod")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSBaseResponse")))
@interface ZmsKmmZMSBaseResponse : ZmsKmmBase
- (instancetype)initWithStatus:(ZmsKmmInt * _Nullable)status msg:(NSString * _Nullable)msg __attribute__((swift_name("init(status:msg:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSBaseResponseCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmInt * _Nullable)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmZMSBaseResponse *)doCopyStatus:(ZmsKmmInt * _Nullable)status msg:(NSString * _Nullable)msg __attribute__((swift_name("doCopy(status:msg:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable msg __attribute__((swift_name("msg")));
@property (readonly) ZmsKmmInt * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSBaseResponse.Companion")))
@interface ZmsKmmZMSBaseResponseCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSBaseResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSNotificationName")))
@interface ZmsKmmZMSNotificationName : ZmsKmmKotlinEnum<ZmsKmmZMSNotificationName *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) ZmsKmmZMSNotificationName *authexpired __attribute__((swift_name("authexpired")));
@property (class, readonly) ZmsKmmZMSNotificationName *apiresponse __attribute__((swift_name("apiresponse")));
+ (ZmsKmmKotlinArray<ZmsKmmZMSNotificationName *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSRequestSender")))
@interface ZmsKmmZMSRequestSender : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@end;

__attribute__((swift_name("ZMSBaseEndPoint")))
@protocol ZmsKmmZMSBaseEndPoint
@required
- (NSString *)urlData:(NSString *)data __attribute__((swift_name("url(data:)")));
@property (readonly) ZmsKmmZMSHttpMethod *zHttpMethod __attribute__((swift_name("zHttpMethod")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSEndPoint")))
@interface ZmsKmmZMSEndPoint : ZmsKmmKotlinEnum<ZmsKmmZMSEndPoint *> <ZmsKmmZMSBaseEndPoint>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) ZmsKmmZMSEndPoint *validate __attribute__((swift_name("validate")));
@property (class, readonly) ZmsKmmZMSEndPoint *phonecountries __attribute__((swift_name("phonecountries")));
@property (class, readonly) ZmsKmmZMSEndPoint *requestotp __attribute__((swift_name("requestotp")));
@property (class, readonly) ZmsKmmZMSEndPoint *verifyotp __attribute__((swift_name("verifyotp")));
@property (class, readonly) ZmsKmmZMSEndPoint *signup __attribute__((swift_name("signup")));
@property (class, readonly) ZmsKmmZMSEndPoint *login __attribute__((swift_name("login")));
@property (class, readonly) ZmsKmmZMSEndPoint *trips __attribute__((swift_name("trips")));
@property (class, readonly) ZmsKmmZMSEndPoint *tripalerts __attribute__((swift_name("tripalerts")));
@property (class, readonly) ZmsKmmZMSEndPoint *home __attribute__((swift_name("home")));
@property (class, readonly) ZmsKmmZMSEndPoint *uploadTripData __attribute__((swift_name("uploadTripData")));
@property (class, readonly) ZmsKmmZMSEndPoint *vehicles __attribute__((swift_name("vehicles")));
@property (class, readonly) ZmsKmmZMSEndPoint *updateVehicleDetails __attribute__((swift_name("updateVehicleDetails")));
@property (class, readonly) ZmsKmmZMSEndPoint *removeTrip __attribute__((swift_name("removeTrip")));
@property (class, readonly) ZmsKmmZMSEndPoint *getSettings __attribute__((swift_name("getSettings")));
@property (class, readonly) ZmsKmmZMSEndPoint *updateSettings __attribute__((swift_name("updateSettings")));
@property (class, readonly) ZmsKmmZMSEndPoint *stopTrip __attribute__((swift_name("stopTrip")));
@property (class, readonly) ZmsKmmZMSEndPoint *validateMerchantUserToken __attribute__((swift_name("validateMerchantUserToken")));
+ (ZmsKmmKotlinArray<ZmsKmmZMSEndPoint *> *)values __attribute__((swift_name("values()")));
- (NSString *)urlData:(NSString *)data __attribute__((swift_name("url(data:)")));
@property (readonly) ZmsKmmZMSHttpMethod *zHttpMethod __attribute__((swift_name("zHttpMethod")));
@end;

__attribute__((swift_name("ZMSBaseEnvironment")))
@protocol ZmsKmmZMSBaseEnvironment
@required
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSEnvironment")))
@interface ZmsKmmZMSEnvironment : ZmsKmmKotlinEnum<ZmsKmmZMSEnvironment *> <ZmsKmmZMSBaseEnvironment>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) ZmsKmmZMSEnvironment *production __attribute__((swift_name("production")));
@property (class, readonly) ZmsKmmZMSEnvironment *testing __attribute__((swift_name("testing")));
+ (ZmsKmmKotlinArray<ZmsKmmZMSEnvironment *> *)values __attribute__((swift_name("values()")));
@property NSString *baseUrl __attribute__((swift_name("baseUrl")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSMock")))
@interface ZmsKmmZMSMock : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)readFromJSONType:(ZmsKmmZMSMockType *)type completionHandler:(void (^)(id _Nullable, ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("readFromJSON(type:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSMockData")))
@interface ZmsKmmZMSMockData : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property NSString *homeData __attribute__((swift_name("homeData")));
@property NSString *settings __attribute__((swift_name("settings")));
@property NSString *tripAlertsListJson __attribute__((swift_name("tripAlertsListJson")));
@property NSString *tripListJson __attribute__((swift_name("tripListJson")));
@property NSString *validateMerchantUserToken __attribute__((swift_name("validateMerchantUserToken")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSMockType")))
@interface ZmsKmmZMSMockType : ZmsKmmBase
- (instancetype)initWithEndPoint:(id<ZmsKmmZMSBaseEndPoint>)endPoint __attribute__((swift_name("init(endPoint:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<ZmsKmmZMSBaseEndPoint> endPoint __attribute__((swift_name("endPoint")));
@property (readonly) NSString *json __attribute__((swift_name("json")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSRequestData")))
@interface ZmsKmmZMSRequestData : ZmsKmmBase
- (instancetype)initWithEnvironment:(ZmsKmmZMSEnvironment *)environment parameters:(ZmsKmmZMSBaseBodyParam * _Nullable)parameters getParameters:(NSDictionary<NSString *, id> * _Nullable)getParameters headers:(NSDictionary<NSString *, id> *)headers zmsEndPoint:(id<ZmsKmmZMSBaseEndPoint>)zmsEndPoint endPoint:(NSString *)endPoint __attribute__((swift_name("init(environment:parameters:getParameters:headers:zmsEndPoint:endPoint:)"))) __attribute__((objc_designated_initializer));
@property NSDictionary<NSString *, id> *defaultHeaders __attribute__((swift_name("defaultHeaders")));
@property NSString *endPoint __attribute__((swift_name("endPoint")));
@property ZmsKmmZMSEnvironment *environment __attribute__((swift_name("environment")));
@property NSDictionary<NSString *, id> *getParameters __attribute__((swift_name("getParameters")));
@property ZmsKmmZMSBaseBodyParam * _Nullable parameters __attribute__((swift_name("parameters")));
@property id<ZmsKmmZMSBaseEndPoint> zmsEndPoint __attribute__((swift_name("zmsEndPoint")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSServiceProvider")))
@interface ZmsKmmZMSServiceProvider : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)submitRequestRequestUrl:(NSString *)requestUrl requestHttpMethod:(ZmsKmmZMSHttpMethod *)requestHttpMethod requestBodyParameters:(ZmsKmmZMSBaseBodyParam * _Nullable)requestBodyParameters requestGetParameters:(NSDictionary<NSString *, id> * _Nullable)requestGetParameters requestHeaders:(NSDictionary<NSString *, id> * _Nullable)requestHeaders completionHandler:(void (^)(ZmsKmmKtor_client_coreHttpResponse * _Nullable))completionHandler completionHandler:(void (^)(ZmsKmmKotlinUnit * _Nullable, NSError * _Nullable))completionHandler_ __attribute__((swift_name("submitRequest(requestUrl:requestHttpMethod:requestBodyParameters:requestGetParameters:requestHeaders:completionHandler:completionHandler:)")));
@property (readonly) ZmsKmmKtor_client_coreHttpClient *client __attribute__((swift_name("client")));
@end;

__attribute__((swift_name("ZMSBaseBodyParam")))
@interface ZmsKmmZMSBaseBodyParam : ZmsKmmBase
- (instancetype)initWithBody:(NSString *)body __attribute__((swift_name("init(body:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSBaseBodyParamCompanion *companion __attribute__((swift_name("companion")));
@property (readonly) NSString *body __attribute__((swift_name("body")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSBaseBodyParam.Companion")))
@interface ZmsKmmZMSBaseBodyParamCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSBaseBodyParamCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSError")))
@interface ZmsKmmZMSError : ZmsKmmBase
- (instancetype)initWithStatus:(ZmsKmmInt * _Nullable)status msg:(NSString * _Nullable)msg errorCode:(NSString * _Nullable)errorCode title:(NSString * _Nullable)title __attribute__((swift_name("init(status:msg:errorCode:title:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSErrorCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)description __attribute__((swift_name("description()")));
@property NSString * _Nullable errorCode __attribute__((swift_name("errorCode")));
@property NSString * _Nullable msg __attribute__((swift_name("msg")));
@property ZmsKmmInt * _Nullable status __attribute__((swift_name("status")));
@property NSString * _Nullable title __attribute__((swift_name("title")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSError.Companion")))
@interface ZmsKmmZMSErrorCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSErrorCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@property (readonly, getter=default) ZmsKmmZMSError *default_ __attribute__((swift_name("default_")));
@property (readonly) ZmsKmmZMSError *noInternet __attribute__((swift_name("noInternet")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSHomeVM")))
@interface ZmsKmmZMSHomeVM : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)fetchHomeDetailsCarEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment getParameters:(NSDictionary<NSString *, id> * _Nullable)getParameters headers:(NSDictionary<NSString *, id> *)headers isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("fetchHomeDetails(carEnvironment:getParameters:headers:isMock:completionHandler:)")));
- (void)removeTripTripId:(NSString *)tripId tripRemovalReason:(ZmsKmmTripRemovalReason *)tripRemovalReason carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("removeTrip(tripId:tripRemovalReason:carEnvironment:isMock:completionHandler:)")));
- (void)stopOngoingTripIfAnyCarEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("stopOngoingTripIfAny(carEnvironment:isMock:completionHandler:)")));
@property (readonly) ZmsKmmZMSLifetimeScoreVO * _Nullable lifeTimeScore __attribute__((swift_name("lifeTimeScore")));
@property NSArray<ZmsKmmTripRemovalReason *> *reasonList __attribute__((swift_name("reasonList")));
@property (readonly) ZmsKmmZCPTripData * _Nullable tripData __attribute__((swift_name("tripData")));
@property (readonly) ZmsKmmZMSTripScoreVO * _Nullable tripScore __attribute__((swift_name("tripScore")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSAlertOverviewVO")))
@interface ZmsKmmZMSAlertOverviewVO : ZmsKmmBase
- (instancetype)initWithName:(NSString * _Nullable)name category:(NSString * _Nullable)category count:(int32_t)count alertType:(ZmsKmmZMSTripAlertType * _Nullable)alertType __attribute__((swift_name("init(name:category:count:alertType:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSAlertOverviewVOCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (ZmsKmmZMSTripAlertType * _Nullable)component4 __attribute__((swift_name("component4()")));
- (ZmsKmmZMSAlertOverviewVO *)doCopyName:(NSString * _Nullable)name category:(NSString * _Nullable)category count:(int32_t)count alertType:(ZmsKmmZMSTripAlertType * _Nullable)alertType __attribute__((swift_name("doCopy(name:category:count:alertType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmZMSTripAlertType * _Nullable alertType __attribute__((swift_name("alertType")));
@property (readonly) NSString * _Nullable category __attribute__((swift_name("category")));
@property (readonly) int32_t count __attribute__((swift_name("count")));
@property (readonly) NSString * _Nullable name __attribute__((swift_name("name")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSAlertOverviewVO.Companion")))
@interface ZmsKmmZMSAlertOverviewVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSAlertOverviewVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSHomeVO")))
@interface ZmsKmmZMSHomeVO : ZmsKmmBase
- (instancetype)initWithTripScore:(ZmsKmmZMSTripScoreVO * _Nullable)tripScore lifetimeScore:(ZmsKmmZMSLifetimeScoreVO * _Nullable)lifetimeScore __attribute__((swift_name("init(tripScore:lifetimeScore:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSHomeVOCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmZMSTripScoreVO * _Nullable)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmZMSLifetimeScoreVO * _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmZMSHomeVO *)doCopyTripScore:(ZmsKmmZMSTripScoreVO * _Nullable)tripScore lifetimeScore:(ZmsKmmZMSLifetimeScoreVO * _Nullable)lifetimeScore __attribute__((swift_name("doCopy(tripScore:lifetimeScore:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmZMSLifetimeScoreVO * _Nullable lifetimeScore __attribute__((swift_name("lifetimeScore")));
@property (readonly) ZmsKmmZMSTripScoreVO * _Nullable tripScore __attribute__((swift_name("tripScore")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSHomeVO.Companion")))
@interface ZmsKmmZMSHomeVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSHomeVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLifetimeScoreVO")))
@interface ZmsKmmZMSLifetimeScoreVO : ZmsKmmBase
- (instancetype)initWithScore:(ZmsKmmInt * _Nullable)score scoreSubtitle:(NSString * _Nullable)scoreSubtitle disclaimer:(NSString * _Nullable)disclaimer title:(NSString * _Nullable)title weekScore:(ZmsKmmInt * _Nullable)weekScore kms:(NSString * _Nullable)kms trips:(NSString * _Nullable)trips performanceTips:(NSArray<ZmsKmmZMSPerformanceTipVO *> * _Nullable)performanceTips __attribute__((swift_name("init(score:scoreSubtitle:disclaimer:title:weekScore:kms:trips:performanceTips:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSLifetimeScoreVOCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmInt * _Nullable)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()")));
- (ZmsKmmInt * _Nullable)component5 __attribute__((swift_name("component5()")));
- (NSString * _Nullable)component6 __attribute__((swift_name("component6()")));
- (NSString * _Nullable)component7 __attribute__((swift_name("component7()")));
- (NSArray<ZmsKmmZMSPerformanceTipVO *> * _Nullable)component8 __attribute__((swift_name("component8()")));
- (ZmsKmmZMSLifetimeScoreVO *)doCopyScore:(ZmsKmmInt * _Nullable)score scoreSubtitle:(NSString * _Nullable)scoreSubtitle disclaimer:(NSString * _Nullable)disclaimer title:(NSString * _Nullable)title weekScore:(ZmsKmmInt * _Nullable)weekScore kms:(NSString * _Nullable)kms trips:(NSString * _Nullable)trips performanceTips:(NSArray<ZmsKmmZMSPerformanceTipVO *> * _Nullable)performanceTips __attribute__((swift_name("doCopy(score:scoreSubtitle:disclaimer:title:weekScore:kms:trips:performanceTips:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable disclaimer __attribute__((swift_name("disclaimer")));
@property (readonly) NSString * _Nullable kms __attribute__((swift_name("kms")));
@property (readonly) NSArray<ZmsKmmZMSPerformanceTipVO *> * _Nullable performanceTips __attribute__((swift_name("performanceTips")));
@property (readonly) ZmsKmmInt * _Nullable score __attribute__((swift_name("score")));
@property (readonly) NSString * _Nullable scoreSubtitle __attribute__((swift_name("scoreSubtitle")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@property (readonly) NSString * _Nullable trips __attribute__((swift_name("trips")));
@property (readonly) ZmsKmmInt * _Nullable weekScore __attribute__((swift_name("weekScore")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLifetimeScoreVO.Companion")))
@interface ZmsKmmZMSLifetimeScoreVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSLifetimeScoreVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSPerformanceTipVO")))
@interface ZmsKmmZMSPerformanceTipVO : ZmsKmmBase
- (instancetype)initWithCategory:(ZmsKmmZMSScoreCategoryType * _Nullable)category alertType:(ZmsKmmZMSTripAlertType * _Nullable)alertType title:(NSString * _Nullable)title description:(NSString * _Nullable)description __attribute__((swift_name("init(category:alertType:title:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSPerformanceTipVOCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmZMSScoreCategoryType * _Nullable)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmZMSTripAlertType * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()")));
- (ZmsKmmZMSPerformanceTipVO *)doCopyCategory:(ZmsKmmZMSScoreCategoryType * _Nullable)category alertType:(ZmsKmmZMSTripAlertType * _Nullable)alertType title:(NSString * _Nullable)title description:(NSString * _Nullable)description __attribute__((swift_name("doCopy(category:alertType:title:description:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmZMSTripAlertType * _Nullable alertType __attribute__((swift_name("alertType")));
@property (readonly) ZmsKmmZMSScoreCategoryType * _Nullable category __attribute__((swift_name("category")));
@property (readonly) NSString * _Nullable description_ __attribute__((swift_name("description_")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSPerformanceTipVO.Companion")))
@interface ZmsKmmZMSPerformanceTipVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSPerformanceTipVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSScoreCategoryType")))
@interface ZmsKmmZMSScoreCategoryType : ZmsKmmKotlinEnum<ZmsKmmZMSScoreCategoryType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmZMSScoreCategoryTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) ZmsKmmZMSScoreCategoryType *good __attribute__((swift_name("good")));
@property (class, readonly) ZmsKmmZMSScoreCategoryType *bad __attribute__((swift_name("bad")));
@property (class, readonly) ZmsKmmZMSScoreCategoryType *average __attribute__((swift_name("average")));
@property (class, readonly) ZmsKmmZMSScoreCategoryType *unknown __attribute__((swift_name("unknown")));
+ (ZmsKmmKotlinArray<ZmsKmmZMSScoreCategoryType *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSScoreCategoryType.Companion")))
@interface ZmsKmmZMSScoreCategoryTypeCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSScoreCategoryTypeCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripRankScaleVO")))
@interface ZmsKmmZMSTripRankScaleVO : ZmsKmmBase
- (instancetype)initWithLow:(ZmsKmmInt * _Nullable)low high:(ZmsKmmInt * _Nullable)high category:(ZmsKmmZMSScoreCategoryType * _Nullable)category __attribute__((swift_name("init(low:high:category:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSTripRankScaleVOCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmInt * _Nullable)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmInt * _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmZMSScoreCategoryType * _Nullable)component3 __attribute__((swift_name("component3()")));
- (ZmsKmmZMSTripRankScaleVO *)doCopyLow:(ZmsKmmInt * _Nullable)low high:(ZmsKmmInt * _Nullable)high category:(ZmsKmmZMSScoreCategoryType * _Nullable)category __attribute__((swift_name("doCopy(low:high:category:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmZMSScoreCategoryType * _Nullable category __attribute__((swift_name("category")));
@property (readonly) ZmsKmmInt * _Nullable high __attribute__((swift_name("high")));
@property (readonly) ZmsKmmInt * _Nullable low __attribute__((swift_name("low")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripRankScaleVO.Companion")))
@interface ZmsKmmZMSTripRankScaleVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSTripRankScaleVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripScoreVO")))
@interface ZmsKmmZMSTripScoreVO : ZmsKmmBase
- (instancetype)initWithScore:(ZmsKmmInt * _Nullable)score tripInfo:(ZmsKmmZMSTripVO * _Nullable)tripInfo category:(ZmsKmmZMSScoreCategoryType * _Nullable)category rankScale:(NSArray<ZmsKmmZMSTripRankScaleVO *> * _Nullable)rankScale status:(NSString * _Nullable)status alerts:(NSArray<ZmsKmmZMSAlertOverviewVO *> * _Nullable)alerts carouselTexts:(NSArray<NSString *> * _Nullable)carouselTexts showStopTripButton:(BOOL)showStopTripButton __attribute__((swift_name("init(score:tripInfo:category:rankScale:status:alerts:carouselTexts:showStopTripButton:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSTripScoreVOCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmInt * _Nullable)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmZMSTripVO * _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmZMSScoreCategoryType * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSArray<ZmsKmmZMSTripRankScaleVO *> * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSString * _Nullable)component5 __attribute__((swift_name("component5()")));
- (NSArray<ZmsKmmZMSAlertOverviewVO *> * _Nullable)component6 __attribute__((swift_name("component6()")));
- (NSArray<NSString *> * _Nullable)component7 __attribute__((swift_name("component7()")));
- (BOOL)component8 __attribute__((swift_name("component8()")));
- (ZmsKmmZMSTripScoreVO *)doCopyScore:(ZmsKmmInt * _Nullable)score tripInfo:(ZmsKmmZMSTripVO * _Nullable)tripInfo category:(ZmsKmmZMSScoreCategoryType * _Nullable)category rankScale:(NSArray<ZmsKmmZMSTripRankScaleVO *> * _Nullable)rankScale status:(NSString * _Nullable)status alerts:(NSArray<ZmsKmmZMSAlertOverviewVO *> * _Nullable)alerts carouselTexts:(NSArray<NSString *> * _Nullable)carouselTexts showStopTripButton:(BOOL)showStopTripButton __attribute__((swift_name("doCopy(score:tripInfo:category:rankScale:status:alerts:carouselTexts:showStopTripButton:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<ZmsKmmZMSAlertOverviewVO *> * _Nullable alerts __attribute__((swift_name("alerts")));
@property (readonly) NSArray<NSString *> * _Nullable carouselTexts __attribute__((swift_name("carouselTexts")));
@property (readonly) ZmsKmmZMSScoreCategoryType * _Nullable category __attribute__((swift_name("category")));
@property (readonly) NSArray<ZmsKmmZMSTripRankScaleVO *> * _Nullable rankScale __attribute__((swift_name("rankScale")));
@property (readonly) ZmsKmmInt * _Nullable score __attribute__((swift_name("score")));
@property (readonly) BOOL showStopTripButton __attribute__((swift_name("showStopTripButton")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@property (readonly) ZmsKmmZMSTripVO * _Nullable tripInfo __attribute__((swift_name("tripInfo")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripScoreVO.Companion")))
@interface ZmsKmmZMSTripScoreVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSTripScoreVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TripRemovalReason")))
@interface ZmsKmmTripRemovalReason : ZmsKmmKotlinEnum<ZmsKmmTripRemovalReason *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmTripRemovalReasonCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) ZmsKmmTripRemovalReason *train __attribute__((swift_name("train")));
@property (class, readonly) ZmsKmmTripRemovalReason *bus __attribute__((swift_name("bus")));
@property (class, readonly) ZmsKmmTripRemovalReason *twoWheeler __attribute__((swift_name("twoWheeler")));
@property (class, readonly) ZmsKmmTripRemovalReason *cabAutoRickshawSimilar __attribute__((swift_name("cabAutoRickshawSimilar")));
@property (class, readonly) ZmsKmmTripRemovalReason *walkRun __attribute__((swift_name("walkRun")));
@property (class, readonly) ZmsKmmTripRemovalReason *metro __attribute__((swift_name("metro")));
@property (class, readonly) ZmsKmmTripRemovalReason *someoneElseDriving __attribute__((swift_name("someoneElseDriving")));
@property (class, readonly) ZmsKmmTripRemovalReason *appDetectedFalseTrip __attribute__((swift_name("appDetectedFalseTrip")));
+ (ZmsKmmKotlinArray<ZmsKmmTripRemovalReason *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TripRemovalReason.Companion")))
@interface ZmsKmmTripRemovalReasonCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmTripRemovalReasonCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZCPTripData")))
@interface ZmsKmmZCPTripData : ZmsKmmBase
- (instancetype)initWithData:(ZmsKmmZMSTripVO *)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithId:(NSString * _Nullable)id header:(NSString * _Nullable)header subHeader:(NSString * _Nullable)subHeader driverScore:(NSString * _Nullable)driverScore category:(ZmsKmmZMSScoreCategoryType * _Nullable)category isScored:(ZmsKmmBoolean * _Nullable)isScored __attribute__((swift_name("init(id:header:subHeader:driverScore:category:isScored:)"))) __attribute__((objc_designated_initializer));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSString * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()")));
- (ZmsKmmZMSScoreCategoryType * _Nullable)component5 __attribute__((swift_name("component5()")));
- (ZmsKmmBoolean * _Nullable)component6 __attribute__((swift_name("component6()")));
- (ZmsKmmZCPTripData *)doCopyId:(NSString * _Nullable)id header:(NSString * _Nullable)header subHeader:(NSString * _Nullable)subHeader driverScore:(NSString * _Nullable)driverScore category:(ZmsKmmZMSScoreCategoryType * _Nullable)category isScored:(ZmsKmmBoolean * _Nullable)isScored __attribute__((swift_name("doCopy(id:header:subHeader:driverScore:category:isScored:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property ZmsKmmZMSScoreCategoryType * _Nullable category __attribute__((swift_name("category")));
@property NSString * _Nullable driverScore __attribute__((swift_name("driverScore")));
@property NSString * _Nullable header __attribute__((swift_name("header")));
@property NSString * _Nullable id __attribute__((swift_name("id")));
@property ZmsKmmBoolean * _Nullable isScored __attribute__((swift_name("isScored")));
@property NSString * _Nullable subHeader __attribute__((swift_name("subHeader")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripListVO")))
@interface ZmsKmmZMSTripListVO : ZmsKmmBase
- (instancetype)initWithList:(NSArray<ZmsKmmZMSTripVO *> * _Nullable)list __attribute__((swift_name("init(list:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSTripListVOCompanion *companion __attribute__((swift_name("companion")));
- (NSArray<ZmsKmmZMSTripVO *> * _Nullable)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmZMSTripListVO *)doCopyList:(NSArray<ZmsKmmZMSTripVO *> * _Nullable)list __attribute__((swift_name("doCopy(list:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<ZmsKmmZMSTripVO *> * _Nullable list __attribute__((swift_name("list")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripListVO.Companion")))
@interface ZmsKmmZMSTripListVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSTripListVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripManager")))
@interface ZmsKmmZMSTripManager : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString * _Nullable)getOngoingTripId __attribute__((swift_name("getOngoingTripId()")));
- (void)invalidateCurrentTripTripRemovalReason:(ZmsKmmTripRemovalReason *)tripRemovalReason environment:(ZmsKmmZMSEnvironment *)environment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("invalidateCurrentTrip(tripRemovalReason:environment:isMock:completionHandler:)")));
- (BOOL)isTripInSession __attribute__((swift_name("isTripInSession()")));
- (void)onGPSStatusChangeIsGPSOn:(BOOL)isGPSOn __attribute__((swift_name("onGPSStatusChange(isGPSOn:)")));
- (void)onNewLocationLat:(double)lat lon:(double)lon __attribute__((swift_name("onNewLocation(lat:lon:)")));
- (void)startTripEnvironment:(ZmsKmmZMSEnvironment *)environment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("startTrip(environment:isMock:completionHandler:)")));
- (void)stopCurrentTripEnvironment:(ZmsKmmZMSEnvironment *)environment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("stopCurrentTrip(environment:isMock:completionHandler:)")));
@property (readonly) NSString * _Nullable tripSessionId __attribute__((swift_name("tripSessionId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripVM")))
@interface ZmsKmmZMSTripVM : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)fetchListCarEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("fetchList(carEnvironment:isMock:completionHandler:)")));
- (void)removeTripTripId:(NSString *)tripId tripRemovalReason:(ZmsKmmTripRemovalReason *)tripRemovalReason carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("removeTrip(tripId:tripRemovalReason:carEnvironment:isMock:completionHandler:)")));
@property NSMutableArray<ZmsKmmZCPTripData *> *listData __attribute__((swift_name("listData")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripVO")))
@interface ZmsKmmZMSTripVO : ZmsKmmBase
- (instancetype)initWithId:(NSString * _Nullable)id startTime:(ZmsKmmLong * _Nullable)startTime endTime:(ZmsKmmLong * _Nullable)endTime driverScore:(NSString * _Nullable)driverScore category:(ZmsKmmZMSScoreCategoryType * _Nullable)category status:(NSString * _Nullable)status isScored:(ZmsKmmBoolean * _Nullable)isScored __attribute__((swift_name("init(id:startTime:endTime:driverScore:category:status:isScored:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSTripVOCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmLong * _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmLong * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSString * _Nullable)component4 __attribute__((swift_name("component4()")));
- (ZmsKmmZMSScoreCategoryType * _Nullable)component5 __attribute__((swift_name("component5()")));
- (NSString * _Nullable)component6 __attribute__((swift_name("component6()")));
- (ZmsKmmBoolean * _Nullable)component7 __attribute__((swift_name("component7()")));
- (ZmsKmmZMSTripVO *)doCopyId:(NSString * _Nullable)id startTime:(ZmsKmmLong * _Nullable)startTime endTime:(ZmsKmmLong * _Nullable)endTime driverScore:(NSString * _Nullable)driverScore category:(ZmsKmmZMSScoreCategoryType * _Nullable)category status:(NSString * _Nullable)status isScored:(ZmsKmmBoolean * _Nullable)isScored __attribute__((swift_name("doCopy(id:startTime:endTime:driverScore:category:status:isScored:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmZMSScoreCategoryType * _Nullable category __attribute__((swift_name("category")));
@property (readonly) NSString * _Nullable driverScore __attribute__((swift_name("driverScore")));
@property (readonly) ZmsKmmLong * _Nullable endTime __attribute__((swift_name("endTime")));
@property (readonly) NSString * _Nullable id __attribute__((swift_name("id")));
@property (readonly) ZmsKmmBoolean * _Nullable isScored __attribute__((swift_name("isScored")));
@property (readonly) ZmsKmmLong * _Nullable startTime __attribute__((swift_name("startTime")));
@property (readonly) NSString * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripVO.Companion")))
@interface ZmsKmmZMSTripVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSTripVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSAlertTypeVO")))
@interface ZmsKmmZMSAlertTypeVO : ZmsKmmBase
- (instancetype)initWithTitle:(NSString * _Nullable)title icon:(NSString * _Nullable)icon type:(ZmsKmmZMSTripAlertType * _Nullable)type isDefault:(ZmsKmmBoolean * _Nullable)isDefault __attribute__((swift_name("init(title:icon:type:isDefault:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSAlertTypeVOCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmZMSTripAlertType * _Nullable)component3 __attribute__((swift_name("component3()")));
- (ZmsKmmBoolean * _Nullable)component4 __attribute__((swift_name("component4()")));
- (ZmsKmmZMSAlertTypeVO *)doCopyTitle:(NSString * _Nullable)title icon:(NSString * _Nullable)icon type:(ZmsKmmZMSTripAlertType * _Nullable)type isDefault:(ZmsKmmBoolean * _Nullable)isDefault __attribute__((swift_name("doCopy(title:icon:type:isDefault:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString * _Nullable icon __attribute__((swift_name("icon")));
@property (readonly) ZmsKmmBoolean * _Nullable isDefault __attribute__((swift_name("isDefault")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@property (readonly) ZmsKmmZMSTripAlertType * _Nullable type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSAlertTypeVO.Companion")))
@interface ZmsKmmZMSAlertTypeVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSAlertTypeVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSAlertsVO")))
@interface ZmsKmmZMSAlertsVO : ZmsKmmBase
- (instancetype)initWithTitle:(NSString * _Nullable)title subTitle:(NSString * _Nullable)subTitle severity:(ZmsKmmZMSTripAlertSeverity * _Nullable)severity type:(ZmsKmmZMSTripAlertType * _Nullable)type icon:(NSString * _Nullable)icon startTime:(ZmsKmmLong * _Nullable)startTime endTime:(ZmsKmmLong * _Nullable)endTime lat:(ZmsKmmDouble * _Nullable)lat lon:(ZmsKmmDouble * _Nullable)lon rangeRoute:(NSString * _Nullable)rangeRoute __attribute__((swift_name("init(title:subTitle:severity:type:icon:startTime:endTime:lat:lon:rangeRoute:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSAlertsVOCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component10 __attribute__((swift_name("component10()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmZMSTripAlertSeverity * _Nullable)component3 __attribute__((swift_name("component3()")));
- (ZmsKmmZMSTripAlertType * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSString * _Nullable)component5 __attribute__((swift_name("component5()")));
- (ZmsKmmLong * _Nullable)component6 __attribute__((swift_name("component6()")));
- (ZmsKmmLong * _Nullable)component7 __attribute__((swift_name("component7()")));
- (ZmsKmmDouble * _Nullable)component8 __attribute__((swift_name("component8()")));
- (ZmsKmmDouble * _Nullable)component9 __attribute__((swift_name("component9()")));
- (ZmsKmmZMSAlertsVO *)doCopyTitle:(NSString * _Nullable)title subTitle:(NSString * _Nullable)subTitle severity:(ZmsKmmZMSTripAlertSeverity * _Nullable)severity type:(ZmsKmmZMSTripAlertType * _Nullable)type icon:(NSString * _Nullable)icon startTime:(ZmsKmmLong * _Nullable)startTime endTime:(ZmsKmmLong * _Nullable)endTime lat:(ZmsKmmDouble * _Nullable)lat lon:(ZmsKmmDouble * _Nullable)lon rangeRoute:(NSString * _Nullable)rangeRoute __attribute__((swift_name("doCopy(title:subTitle:severity:type:icon:startTime:endTime:lat:lon:rangeRoute:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmLong * _Nullable endTime __attribute__((swift_name("endTime")));
@property (readonly) NSString * _Nullable icon __attribute__((swift_name("icon")));
@property (readonly) ZmsKmmDouble * _Nullable lat __attribute__((swift_name("lat")));
@property (readonly) ZmsKmmDouble * _Nullable lon __attribute__((swift_name("lon")));
@property (readonly) NSString * _Nullable rangeRoute __attribute__((swift_name("rangeRoute")));
@property (readonly) ZmsKmmZMSTripAlertSeverity * _Nullable severity __attribute__((swift_name("severity")));
@property (readonly) ZmsKmmLong * _Nullable startTime __attribute__((swift_name("startTime")));
@property (readonly) NSString * _Nullable subTitle __attribute__((swift_name("subTitle")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@property (readonly) ZmsKmmZMSTripAlertType * _Nullable type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSAlertsVO.Companion")))
@interface ZmsKmmZMSAlertsVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSAlertsVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripAlertApiVM")))
@interface ZmsKmmZMSTripAlertApiVM : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)fetchTripAlertListTripId:(NSString *)tripId carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSTripAlertVO * _Nullable, ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("fetchTripAlertList(tripId:carEnvironment:isMock:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripAlertSeverity")))
@interface ZmsKmmZMSTripAlertSeverity : ZmsKmmKotlinEnum<ZmsKmmZMSTripAlertSeverity *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmZMSTripAlertSeverityCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) ZmsKmmZMSTripAlertSeverity *low __attribute__((swift_name("low")));
@property (class, readonly) ZmsKmmZMSTripAlertSeverity *medium __attribute__((swift_name("medium")));
@property (class, readonly) ZmsKmmZMSTripAlertSeverity *high __attribute__((swift_name("high")));
+ (ZmsKmmKotlinArray<ZmsKmmZMSTripAlertSeverity *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripAlertSeverity.Companion")))
@interface ZmsKmmZMSTripAlertSeverityCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSTripAlertSeverityCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripAlertType")))
@interface ZmsKmmZMSTripAlertType : ZmsKmmKotlinEnum<ZmsKmmZMSTripAlertType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmZMSTripAlertTypeCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) ZmsKmmZMSTripAlertType *hardbraking __attribute__((swift_name("hardbraking")));
@property (class, readonly) ZmsKmmZMSTripAlertType *overspeeding __attribute__((swift_name("overspeeding")));
@property (class, readonly) ZmsKmmZMSTripAlertType *rapidacc __attribute__((swift_name("rapidacc")));
@property (class, readonly) ZmsKmmZMSTripAlertType *drivesafely __attribute__((swift_name("drivesafely")));
+ (ZmsKmmKotlinArray<ZmsKmmZMSTripAlertType *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripAlertType.Companion")))
@interface ZmsKmmZMSTripAlertTypeCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSTripAlertTypeCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripAlertVM")))
@interface ZmsKmmZMSTripAlertVM : ZmsKmmBase
- (instancetype)initWithTripId:(NSString *)tripId __attribute__((swift_name("init(tripId:)"))) __attribute__((objc_designated_initializer));
- (void)fetchAlertListCarEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("fetchAlertList(carEnvironment:isMock:completionHandler:)")));
- (void)filterAppliedFilter:(ZmsKmmZMSAlertTypeVO *)filter __attribute__((swift_name("filterApplied(filter:)")));
@property NSMutableArray<ZmsKmmZMSAlertTypeVO *> *alertTypes __attribute__((swift_name("alertTypes")));
@property NSMutableArray<ZmsKmmZMSAlertTypeVO *> *appliedAlert __attribute__((swift_name("appliedAlert")));
@property (readonly) NSArray<ZmsKmmZMSAlertsVO *> *filteredAlerts __attribute__((swift_name("filteredAlerts")));
@property (readonly) NSString *navHeader __attribute__((swift_name("navHeader")));
@property (readonly) NSString *navSubHeader __attribute__((swift_name("navSubHeader")));
@property (readonly) NSString * _Nullable route __attribute__((swift_name("route")));
@property (readonly) NSString *tripId __attribute__((swift_name("tripId")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripAlertVO")))
@interface ZmsKmmZMSTripAlertVO : ZmsKmmBase
- (instancetype)initWithNavHeader:(NSString * _Nullable)navHeader navSubHeader:(NSString * _Nullable)navSubHeader alertTypes:(NSArray<ZmsKmmZMSAlertTypeVO *> * _Nullable)alertTypes alerts:(NSArray<ZmsKmmZMSAlertsVO *> * _Nullable)alerts route:(NSString * _Nullable)route __attribute__((swift_name("init(navHeader:navSubHeader:alertTypes:alerts:route:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmZMSTripAlertVOCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (NSArray<ZmsKmmZMSAlertTypeVO *> * _Nullable)component3 __attribute__((swift_name("component3()")));
- (NSArray<ZmsKmmZMSAlertsVO *> * _Nullable)component4 __attribute__((swift_name("component4()")));
- (NSString * _Nullable)component5 __attribute__((swift_name("component5()")));
- (ZmsKmmZMSTripAlertVO *)doCopyNavHeader:(NSString * _Nullable)navHeader navSubHeader:(NSString * _Nullable)navSubHeader alertTypes:(NSArray<ZmsKmmZMSAlertTypeVO *> * _Nullable)alertTypes alerts:(NSArray<ZmsKmmZMSAlertsVO *> * _Nullable)alerts route:(NSString * _Nullable)route __attribute__((swift_name("doCopy(navHeader:navSubHeader:alertTypes:alerts:route:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<ZmsKmmZMSAlertTypeVO *> * _Nullable alertTypes __attribute__((swift_name("alertTypes")));
@property (readonly) NSArray<ZmsKmmZMSAlertsVO *> * _Nullable alerts __attribute__((swift_name("alerts")));
@property (readonly) NSString * _Nullable navHeader __attribute__((swift_name("navHeader")));
@property (readonly) NSString * _Nullable navSubHeader __attribute__((swift_name("navSubHeader")));
@property (readonly) NSString * _Nullable route __attribute__((swift_name("route")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripAlertVO.Companion")))
@interface ZmsKmmZMSTripAlertVOCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSTripAlertVOCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("EventType")))
@interface ZmsKmmEventType : ZmsKmmKotlinEnum<ZmsKmmEventType *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) ZmsKmmEventType *location __attribute__((swift_name("location")));
@property (class, readonly) ZmsKmmEventType *startTrip __attribute__((swift_name("startTrip")));
@property (class, readonly) ZmsKmmEventType *endTrip __attribute__((swift_name("endTrip")));
@property (class, readonly) ZmsKmmEventType *falseTrip __attribute__((swift_name("falseTrip")));
@property (class, readonly) ZmsKmmEventType *gpsOn __attribute__((swift_name("gpsOn")));
@property (class, readonly) ZmsKmmEventType *gpsOff __attribute__((swift_name("gpsOff")));
+ (ZmsKmmKotlinArray<ZmsKmmEventType *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TripUploadResponse")))
@interface ZmsKmmTripUploadResponse : ZmsKmmBase
- (instancetype)initWithData:(NSArray<ZmsKmmLong *> * _Nullable)data __attribute__((swift_name("init(data:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmTripUploadResponseCompanion *companion __attribute__((swift_name("companion")));
- (NSArray<ZmsKmmLong *> * _Nullable)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmTripUploadResponse *)doCopyData:(NSArray<ZmsKmmLong *> * _Nullable)data __attribute__((swift_name("doCopy(data:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<ZmsKmmLong *> * _Nullable data __attribute__((swift_name("data")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TripUploadResponse.Companion")))
@interface ZmsKmmTripUploadResponseCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmTripUploadResponseCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripUploader")))
@interface ZmsKmmZMSTripUploader : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)uploadTripPointsNumberOfTripPoints:(int32_t)numberOfTripPoints carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("uploadTripPoints(numberOfTripPoints:carEnvironment:isMock:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripUploaderApiVM")))
@interface ZmsKmmZMSTripUploaderApiVM : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)endTripTripId:(NSString *)tripId endTimestamp:(int64_t)endTimestamp carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("endTrip(tripId:endTimestamp:carEnvironment:isMock:completionHandler:)")));
- (void)removeTripTripId:(NSString *)tripId tripRemovalReason:(ZmsKmmTripRemovalReason *)tripRemovalReason carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("removeTrip(tripId:tripRemovalReason:carEnvironment:isMock:completionHandler:)")));
- (void)sendTripDataPointsTripPoints:(NSArray<ZmsKmmTripPoint *> *)tripPoints carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmTripUploadResponse * _Nullable, ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("sendTripDataPoints(tripPoints:carEnvironment:isMock:completionHandler:)")));
- (void)startTripTripId:(NSString *)tripId startTimestamp:(int64_t)startTimestamp carEnvironment:(ZmsKmmZMSEnvironment *)carEnvironment isMock:(BOOL)isMock completionHandler:(void (^)(ZmsKmmZMSError * _Nullable))completionHandler __attribute__((swift_name("startTrip(tripId:startTimestamp:carEnvironment:isMock:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSTripRepository")))
@interface ZmsKmmZMSTripRepository : ZmsKmmBase
- (instancetype)initWithDb:(id<ZmsKmmZmsDb>)db scope:(id<ZmsKmmKotlinx_coroutines_coreCoroutineScope>)scope __attribute__((swift_name("init(db:scope:)"))) __attribute__((objc_designated_initializer));
- (void)addTripEventsTripId:(NSString *)tripId timestamp:(int64_t)timestamp eventType:(ZmsKmmEventType *)eventType __attribute__((swift_name("addTripEvents(tripId:timestamp:eventType:)")));
- (void)addTripPointTripId:(NSString *)tripId lat:(double)lat lon:(double)lon timestamp:(int64_t)timestamp __attribute__((swift_name("addTripPoint(tripId:lat:lon:timestamp:)")));
- (void)deleteProcessedTripPoints __attribute__((swift_name("deleteProcessedTripPoints()")));
- (void)getAllTripPointsTripId:(NSString *)tripId onTripPointsFetched:(void (^)(NSArray<ZmsKmmTripPoint *> *))onTripPointsFetched __attribute__((swift_name("getAllTripPoints(tripId:onTripPointsFetched:)")));
- (void)getAllTripsOnTripsFetched:(void (^)(NSArray<ZmsKmmTrip *> *))onTripsFetched __attribute__((swift_name("getAllTrips(onTripsFetched:)")));
- (void)getUnprocessedTripPointsCount:(int32_t)count onTripPointsFetched:(void (^)(NSArray<ZmsKmmTripPoint *> *))onTripPointsFetched __attribute__((swift_name("getUnprocessedTripPoints(count:onTripPointsFetched:)")));
- (void)markAsProcessedTimestamp:(int64_t)timestamp __attribute__((swift_name("markAsProcessed(timestamp:)")));
- (NSString *)startTrip __attribute__((swift_name("startTrip()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DIHelper")))
@interface ZmsKmmDIHelper : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (ZmsKmmZMSTripRepository *)getTripRepository __attribute__((swift_name("getTripRepository()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DatabaseProvider")))
@interface ZmsKmmDatabaseProvider : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id<ZmsKmmZmsDb>)getZmsDatabase __attribute__((swift_name("getZmsDatabase()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Trip")))
@interface ZmsKmmTrip : ZmsKmmBase
- (instancetype)initWithId:(NSString *)id started_at:(NSString * _Nullable)started_at __attribute__((swift_name("init(id:started_at:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString * _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmTrip *)doCopyId:(NSString *)id started_at:(NSString * _Nullable)started_at __attribute__((swift_name("doCopy(id:started_at:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *id __attribute__((swift_name("id")));
@property (readonly) NSString * _Nullable started_at __attribute__((swift_name("started_at")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TripPoint")))
@interface ZmsKmmTripPoint : ZmsKmmBase
- (instancetype)initWithId:(int64_t)id trip_id:(NSString *)trip_id lat:(double)lat lon:(double)lon timestamp:(ZmsKmmDouble * _Nullable)timestamp processed:(ZmsKmmLong * _Nullable)processed eventType:(NSString *)eventType __attribute__((swift_name("init(id:trip_id:lat:lon:timestamp:processed:eventType:)"))) __attribute__((objc_designated_initializer));
- (int64_t)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (double)component3 __attribute__((swift_name("component3()")));
- (double)component4 __attribute__((swift_name("component4()")));
- (ZmsKmmDouble * _Nullable)component5 __attribute__((swift_name("component5()")));
- (ZmsKmmLong * _Nullable)component6 __attribute__((swift_name("component6()")));
- (NSString *)component7 __attribute__((swift_name("component7()")));
- (ZmsKmmTripPoint *)doCopyId:(int64_t)id trip_id:(NSString *)trip_id lat:(double)lat lon:(double)lon timestamp:(ZmsKmmDouble * _Nullable)timestamp processed:(ZmsKmmLong * _Nullable)processed eventType:(NSString *)eventType __attribute__((swift_name("doCopy(id:trip_id:lat:lon:timestamp:processed:eventType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *eventType __attribute__((swift_name("eventType")));
@property (readonly) int64_t id __attribute__((swift_name("id")));
@property (readonly) double lat __attribute__((swift_name("lat")));
@property (readonly) double lon __attribute__((swift_name("lon")));
@property (readonly) ZmsKmmLong * _Nullable processed __attribute__((swift_name("processed")));
@property (readonly) ZmsKmmDouble * _Nullable timestamp __attribute__((swift_name("timestamp")));
@property (readonly) NSString *trip_id __attribute__((swift_name("trip_id")));
@end;

__attribute__((swift_name("RuntimeTransacter")))
@protocol ZmsKmmRuntimeTransacter
@required
- (void)transactionNoEnclosing:(BOOL)noEnclosing body:(void (^)(id<ZmsKmmRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(noEnclosing:body:)")));
- (id _Nullable)transactionWithResultNoEnclosing:(BOOL)noEnclosing bodyWithReturn:(id _Nullable (^)(id<ZmsKmmRuntimeTransactionWithReturn>))bodyWithReturn __attribute__((swift_name("transactionWithResult(noEnclosing:bodyWithReturn:)")));
@end;

__attribute__((swift_name("TripPointQueries")))
@protocol ZmsKmmTripPointQueries <ZmsKmmRuntimeTransacter>
@required
- (void)deleteProcessedPoints __attribute__((swift_name("deleteProcessedPoints()")));
- (void)markProcessedTrip_id:(NSString *)trip_id id:(int64_t)id __attribute__((swift_name("markProcessed(trip_id:id:)")));
- (void)markProcessedUsingTimestampTimestamp:(ZmsKmmDouble * _Nullable)timestamp __attribute__((swift_name("markProcessedUsingTimestamp(timestamp:)")));
- (void)markUnProcessedTrip_id:(NSString *)trip_id id:(int64_t)id __attribute__((swift_name("markUnProcessed(trip_id:id:)")));
- (void)markUnProcessedUsingTimestampTimestamp:(ZmsKmmDouble * _Nullable)timestamp __attribute__((swift_name("markUnProcessedUsingTimestamp(timestamp:)")));
- (ZmsKmmRuntimeQuery<ZmsKmmTripPoint *> *)selectToProcessValue:(int64_t)value __attribute__((swift_name("selectToProcess(value:)")));
- (ZmsKmmRuntimeQuery<id> *)selectToProcessValue:(int64_t)value mapper:(id (^)(ZmsKmmLong *, NSString *, ZmsKmmDouble *, ZmsKmmDouble *, ZmsKmmDouble * _Nullable, ZmsKmmLong * _Nullable, NSString *))mapper __attribute__((swift_name("selectToProcess(value:mapper:)")));
@end;

__attribute__((swift_name("TripQueries")))
@protocol ZmsKmmTripQueries <ZmsKmmRuntimeTransacter>
@required
- (void)deleteALL __attribute__((swift_name("deleteALL()")));
- (void)insertTrip:(ZmsKmmTrip *)trip __attribute__((swift_name("insert(trip:)")));
- (void)insertTripPointTrip_id:(NSString *)trip_id lat:(double)lat lon:(double)lon timestamp:(ZmsKmmDouble * _Nullable)timestamp eventType:(NSString *)eventType __attribute__((swift_name("insertTripPoint(trip_id:lat:lon:timestamp:eventType:)")));
- (ZmsKmmRuntimeQuery<ZmsKmmTrip *> *)selectAll __attribute__((swift_name("selectAll()")));
- (ZmsKmmRuntimeQuery<id> *)selectAllMapper:(id (^)(NSString *, NSString * _Nullable))mapper __attribute__((swift_name("selectAll(mapper:)")));
- (ZmsKmmRuntimeQuery<ZmsKmmTripPoint *> *)selectAllTripPointsTrip_id:(NSString *)trip_id __attribute__((swift_name("selectAllTripPoints(trip_id:)")));
- (ZmsKmmRuntimeQuery<id> *)selectAllTripPointsTrip_id:(NSString *)trip_id mapper:(id (^)(ZmsKmmLong *, NSString *, ZmsKmmDouble *, ZmsKmmDouble *, ZmsKmmDouble * _Nullable, ZmsKmmLong * _Nullable, NSString *))mapper __attribute__((swift_name("selectAllTripPoints(trip_id:mapper:)")));
@end;

__attribute__((swift_name("ZmsDb")))
@protocol ZmsKmmZmsDb <ZmsKmmRuntimeTransacter>
@required
@property (readonly) id<ZmsKmmTripPointQueries> tripPointQueries __attribute__((swift_name("tripPointQueries")));
@property (readonly) id<ZmsKmmTripQueries> tripQueries __attribute__((swift_name("tripQueries")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZmsDbCompanion")))
@interface ZmsKmmZmsDbCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZmsDbCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmZmsDb>)invokeDriver:(id<ZmsKmmRuntimeSqlDriver>)driver __attribute__((swift_name("invoke(driver:)")));
@property (readonly) id<ZmsKmmRuntimeSqlDriverSchema> Schema __attribute__((swift_name("Schema")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSLogSegments")))
@interface ZmsKmmZMSLogSegments : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)zMSLogSegments __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmZMSLogSegments *shared __attribute__((swift_name("shared")));
- (ZmsKmmMutableDictionary<id, id> *)createEventDictionaryTimestamp:(NSString *)timestamp tag:(NSString * _Nullable)tag message:(NSString * _Nullable)message __attribute__((swift_name("createEventDictionary(timestamp:tag:message:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ObserversKt")))
@interface ZmsKmmObserversKt : ZmsKmmBase
@property (class, readonly) id<ZmsKmmObservableSettings> Observer __attribute__((swift_name("Observer")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DateTimeFormatterKt")))
@interface ZmsKmmDateTimeFormatterKt : ZmsKmmBase
@property (class, readonly) id<ZmsKmmZMSDateTimeFormatter> dateTimeFormatter __attribute__((swift_name("dateTimeFormatter")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DispatchersKt")))
@interface ZmsKmmDispatchersKt : ZmsKmmBase
@property (class, readonly) id<ZmsKmmKotlinCoroutineContext> defaultDispatcher __attribute__((swift_name("defaultDispatcher")));
@property (class, readonly) id<ZmsKmmKotlinCoroutineContext> ioDispatcher __attribute__((swift_name("ioDispatcher")));
@property (class, readonly) id<ZmsKmmKotlinCoroutineContext> uiDispatcher __attribute__((swift_name("uiDispatcher")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlatformKt")))
@interface ZmsKmmPlatformKt : ZmsKmmBase
@property (class, readonly) ZmsKmmPlatformType *platform __attribute__((swift_name("platform")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UserDefaultsKt")))
@interface ZmsKmmUserDefaultsKt : ZmsKmmBase
@property (class, readonly) id<ZmsKmmSharedPrefs> sharedPreference __attribute__((swift_name("sharedPreference")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("UUIDProviderKt")))
@interface ZmsKmmUUIDProviderKt : ZmsKmmBase
+ (NSString *)getUUID __attribute__((swift_name("getUUID()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSRequestSenderKt")))
@interface ZmsKmmZMSRequestSenderKt : ZmsKmmBase
+ (id _Nullable)deserializeDataRequest:(NSString *)request __attribute__((swift_name("deserializeData(request:)")));
@property (class, readonly) ZmsKmmKotlinx_serialization_jsonJson *json __attribute__((swift_name("json")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("ZMSServiceProviderKt")))
@interface ZmsKmmZMSServiceProviderKt : ZmsKmmBase
+ (NSDictionary<id, id> *)filterNotNull:(NSDictionary<id, id> * _Nullable)receiver __attribute__((swift_name("filterNotNull(_:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DatabaseModuleKt")))
@interface ZmsKmmDatabaseModuleKt : ZmsKmmBase
@property (class, readonly) ZmsKmmKodein_diDIModule *databaseModule __attribute__((swift_name("databaseModule")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DIContainerKt")))
@interface ZmsKmmDIContainerKt : ZmsKmmBase
@property (class, readonly) ZmsKmmKodein_diLazyDI *di __attribute__((swift_name("di")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("DatabaseDriverKt")))
@interface ZmsKmmDatabaseDriverKt : ZmsKmmBase
@property (class, readonly) id<ZmsKmmRuntimeSqlDriver> databaseDriver __attribute__((swift_name("databaseDriver")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinEnumCompanion")))
@interface ZmsKmmKotlinEnumCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKotlinEnumCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface ZmsKmmKotlinArray<T> : ZmsKmmBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(ZmsKmmInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<ZmsKmmKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol ZmsKmmKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<ZmsKmmKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<ZmsKmmKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol ZmsKmmKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<ZmsKmmKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<ZmsKmmKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol ZmsKmmKotlinx_serialization_coreKSerializer <ZmsKmmKotlinx_serialization_coreSerializationStrategy, ZmsKmmKotlinx_serialization_coreDeserializationStrategy>
@required
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod")))
@interface ZmsKmmKtor_httpHttpMethod : ZmsKmmBase
- (instancetype)initWithValue:(NSString *)value __attribute__((swift_name("init(value:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKtor_httpHttpMethodCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (ZmsKmmKtor_httpHttpMethod *)doCopyValue:(NSString *)value __attribute__((swift_name("doCopy(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((swift_name("KotlinThrowable")))
@interface ZmsKmmKotlinThrowable : ZmsKmmBase
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(ZmsKmmKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(ZmsKmmKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (ZmsKmmKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end;

__attribute__((swift_name("KotlinException")))
@interface ZmsKmmKotlinException : ZmsKmmKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(ZmsKmmKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(ZmsKmmKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinRuntimeException")))
@interface ZmsKmmKotlinRuntimeException : ZmsKmmKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(ZmsKmmKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(ZmsKmmKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinIllegalStateException")))
@interface ZmsKmmKotlinIllegalStateException : ZmsKmmKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(ZmsKmmKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(ZmsKmmKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("KotlinCancellationException")))
@interface ZmsKmmKotlinCancellationException : ZmsKmmKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(ZmsKmmKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(ZmsKmmKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((swift_name("Ktor_httpHttpMessage")))
@protocol ZmsKmmKtor_httpHttpMessage
@required
@property (readonly) id<ZmsKmmKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineScope")))
@protocol ZmsKmmKotlinx_coroutines_coreCoroutineScope
@required
@property (readonly) id<ZmsKmmKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpResponse")))
@interface ZmsKmmKtor_client_coreHttpResponse : ZmsKmmBase <ZmsKmmKtor_httpHttpMessage, ZmsKmmKotlinx_coroutines_coreCoroutineScope>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) id<ZmsKmmKtor_ioByteReadChannel> content __attribute__((swift_name("content")));
@property (readonly) ZmsKmmKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) ZmsKmmKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *status __attribute__((swift_name("status")));
@property (readonly) ZmsKmmKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinUnit")))
@interface ZmsKmmKotlinUnit : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)unit __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKotlinUnit *shared __attribute__((swift_name("shared")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Ktor_ioCloseable")))
@protocol ZmsKmmKtor_ioCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClient")))
@interface ZmsKmmKtor_client_coreHttpClient : ZmsKmmBase <ZmsKmmKotlinx_coroutines_coreCoroutineScope, ZmsKmmKtor_ioCloseable>
- (instancetype)initWithEngine:(id<ZmsKmmKtor_client_coreHttpClientEngine>)engine userConfig:(ZmsKmmKtor_client_coreHttpClientConfig<ZmsKmmKtor_client_coreHttpClientEngineConfig *> *)userConfig __attribute__((swift_name("init(engine:userConfig:)"))) __attribute__((objc_designated_initializer));
- (void)close __attribute__((swift_name("close()")));
- (ZmsKmmKtor_client_coreHttpClient *)configBlock:(void (^)(ZmsKmmKtor_client_coreHttpClientConfig<id> *))block __attribute__((swift_name("config(block:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeBuilder:(ZmsKmmKtor_client_coreHttpRequestBuilder *)builder completionHandler:(void (^)(ZmsKmmKtor_client_coreHttpClientCall * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(builder:completionHandler:)"))) __attribute__((unavailable("Unbound [HttpClientCall] is deprecated. Consider using [request<HttpResponse>(builder)] instead.")));
- (BOOL)isSupportedCapability:(id<ZmsKmmKtor_client_coreHttpClientEngineCapability>)capability __attribute__((swift_name("isSupported(capability:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<ZmsKmmKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) id<ZmsKmmKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher"))) __attribute__((unavailable("[dispatcher] is deprecated. Use coroutineContext instead.")));
@property (readonly) id<ZmsKmmKtor_client_coreHttpClientEngine> engine __attribute__((swift_name("engine")));
@property (readonly) ZmsKmmKtor_client_coreHttpClientEngineConfig *engineConfig __attribute__((swift_name("engineConfig")));
@property (readonly) ZmsKmmKtor_client_coreHttpReceivePipeline *receivePipeline __attribute__((swift_name("receivePipeline")));
@property (readonly) ZmsKmmKtor_client_coreHttpRequestPipeline *requestPipeline __attribute__((swift_name("requestPipeline")));
@property (readonly) ZmsKmmKtor_client_coreHttpResponsePipeline *responsePipeline __attribute__((swift_name("responsePipeline")));
@property (readonly) ZmsKmmKtor_client_coreHttpSendPipeline *sendPipeline __attribute__((swift_name("sendPipeline")));
@end;

__attribute__((swift_name("RuntimeQuery")))
@interface ZmsKmmRuntimeQuery<__covariant RowType> : ZmsKmmBase
- (instancetype)initWithQueries:(NSMutableArray<ZmsKmmRuntimeQuery<id> *> *)queries mapper:(RowType (^)(id<ZmsKmmRuntimeSqlCursor>))mapper __attribute__((swift_name("init(queries:mapper:)"))) __attribute__((objc_designated_initializer));
- (void)addListenerListener:(id<ZmsKmmRuntimeQueryListener>)listener __attribute__((swift_name("addListener(listener:)")));
- (id<ZmsKmmRuntimeSqlCursor>)execute __attribute__((swift_name("execute()")));
- (NSArray<RowType> *)executeAsList __attribute__((swift_name("executeAsList()")));
- (RowType)executeAsOne __attribute__((swift_name("executeAsOne()")));
- (RowType _Nullable)executeAsOneOrNull __attribute__((swift_name("executeAsOneOrNull()")));
- (void)notifyDataChanged __attribute__((swift_name("notifyDataChanged()")));
- (void)removeListenerListener:(id<ZmsKmmRuntimeQueryListener>)listener __attribute__((swift_name("removeListener(listener:)")));
@property (readonly) RowType (^mapper)(id<ZmsKmmRuntimeSqlCursor>) __attribute__((swift_name("mapper")));
@end;

__attribute__((swift_name("RuntimeTransactionCallbacks")))
@protocol ZmsKmmRuntimeTransactionCallbacks
@required
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
@end;

__attribute__((swift_name("RuntimeTransactionWithoutReturn")))
@protocol ZmsKmmRuntimeTransactionWithoutReturn <ZmsKmmRuntimeTransactionCallbacks>
@required
- (void)rollback __attribute__((swift_name("rollback()")));
- (void)transactionBody:(void (^)(id<ZmsKmmRuntimeTransactionWithoutReturn>))body __attribute__((swift_name("transaction(body:)")));
@end;

__attribute__((swift_name("RuntimeTransactionWithReturn")))
@protocol ZmsKmmRuntimeTransactionWithReturn <ZmsKmmRuntimeTransactionCallbacks>
@required
- (void)rollbackReturnValue:(id _Nullable)returnValue __attribute__((swift_name("rollback(returnValue:)")));
- (id _Nullable)transactionBody_:(id _Nullable (^)(id<ZmsKmmRuntimeTransactionWithReturn>))body __attribute__((swift_name("transaction(body_:)")));
@end;

__attribute__((swift_name("RuntimeCloseable")))
@protocol ZmsKmmRuntimeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((swift_name("RuntimeSqlDriver")))
@protocol ZmsKmmRuntimeSqlDriver <ZmsKmmRuntimeCloseable>
@required
- (ZmsKmmRuntimeTransacterTransaction * _Nullable)currentTransaction __attribute__((swift_name("currentTransaction()")));
- (void)executeIdentifier:(ZmsKmmInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<ZmsKmmRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("execute(identifier:sql:parameters:binders:)")));
- (id<ZmsKmmRuntimeSqlCursor>)executeQueryIdentifier:(ZmsKmmInt * _Nullable)identifier sql:(NSString *)sql parameters:(int32_t)parameters binders:(void (^ _Nullable)(id<ZmsKmmRuntimeSqlPreparedStatement>))binders __attribute__((swift_name("executeQuery(identifier:sql:parameters:binders:)")));
- (ZmsKmmRuntimeTransacterTransaction *)doNewTransaction __attribute__((swift_name("doNewTransaction()")));
@end;

__attribute__((swift_name("RuntimeSqlDriverSchema")))
@protocol ZmsKmmRuntimeSqlDriverSchema
@required
- (void)createDriver:(id<ZmsKmmRuntimeSqlDriver>)driver __attribute__((swift_name("create(driver:)")));
- (void)migrateDriver:(id<ZmsKmmRuntimeSqlDriver>)driver oldVersion:(int32_t)oldVersion newVersion:(int32_t)newVersion __attribute__((swift_name("migrate(driver:oldVersion:newVersion:)")));
@property (readonly) int32_t version_ __attribute__((swift_name("version_")));
@end;

__attribute__((swift_name("KotlinCoroutineContext")))
@protocol ZmsKmmKotlinCoroutineContext
@required
- (id _Nullable)foldInitial:(id _Nullable)initial operation:(id _Nullable (^)(id _Nullable, id<ZmsKmmKotlinCoroutineContextElement>))operation __attribute__((swift_name("fold(initial:operation:)")));
- (id<ZmsKmmKotlinCoroutineContextElement> _Nullable)getKey:(id<ZmsKmmKotlinCoroutineContextKey>)key __attribute__((swift_name("get(key:)")));
- (id<ZmsKmmKotlinCoroutineContext>)minusKeyKey:(id<ZmsKmmKotlinCoroutineContextKey>)key __attribute__((swift_name("minusKey(key:)")));
- (id<ZmsKmmKotlinCoroutineContext>)plusContext:(id<ZmsKmmKotlinCoroutineContext>)context __attribute__((swift_name("plus(context:)")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerialFormat")))
@protocol ZmsKmmKotlinx_serialization_coreSerialFormat
@required
@property (readonly) ZmsKmmKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreStringFormat")))
@protocol ZmsKmmKotlinx_serialization_coreStringFormat <ZmsKmmKotlinx_serialization_coreSerialFormat>
@required
- (id _Nullable)decodeFromStringDeserializer:(id<ZmsKmmKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (NSString *)encodeToStringSerializer:(id<ZmsKmmKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
@end;

__attribute__((swift_name("Kotlinx_serialization_jsonJson")))
@interface ZmsKmmKotlinx_serialization_jsonJson : ZmsKmmBase <ZmsKmmKotlinx_serialization_coreStringFormat>
- (instancetype)initWithConfiguration:(ZmsKmmKotlinx_serialization_jsonJsonConfiguration *)configuration serializersModule:(ZmsKmmKotlinx_serialization_coreSerializersModule *)serializersModule __attribute__((swift_name("init(configuration:serializersModule:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKotlinx_serialization_jsonJsonDefault *companion __attribute__((swift_name("companion")));
- (id _Nullable)decodeFromJsonElementDeserializer:(id<ZmsKmmKotlinx_serialization_coreDeserializationStrategy>)deserializer element:(ZmsKmmKotlinx_serialization_jsonJsonElement *)element __attribute__((swift_name("decodeFromJsonElement(deserializer:element:)")));
- (id _Nullable)decodeFromStringDeserializer:(id<ZmsKmmKotlinx_serialization_coreDeserializationStrategy>)deserializer string:(NSString *)string __attribute__((swift_name("decodeFromString(deserializer:string:)")));
- (ZmsKmmKotlinx_serialization_jsonJsonElement *)encodeToJsonElementSerializer:(id<ZmsKmmKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToJsonElement(serializer:value:)")));
- (NSString *)encodeToStringSerializer:(id<ZmsKmmKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeToString(serializer:value:)")));
- (ZmsKmmKotlinx_serialization_jsonJsonElement *)parseToJsonElementString:(NSString *)string __attribute__((swift_name("parseToJsonElement(string:)")));
@property (readonly) ZmsKmmKotlinx_serialization_jsonJsonConfiguration *configuration __attribute__((swift_name("configuration")));
@property (readonly) ZmsKmmKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDIModule")))
@interface ZmsKmmKodein_diDIModule : ZmsKmmBase
- (instancetype)initWithAllowSilentOverride:(BOOL)allowSilentOverride init:(void (^)(id<ZmsKmmKodein_diDIBuilder>))init __attribute__((swift_name("init(allowSilentOverride:init:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("You should name your modules, for debug purposes.")));
- (instancetype)initWithName:(NSString *)name allowSilentOverride:(BOOL)allowSilentOverride prefix:(NSString *)prefix init:(void (^)(id<ZmsKmmKodein_diDIBuilder>))init __attribute__((swift_name("init(name:allowSilentOverride:prefix:init:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (BOOL)component2 __attribute__((swift_name("component2()")));
- (NSString *)component3 __attribute__((swift_name("component3()")));
- (void (^)(id<ZmsKmmKodein_diDIBuilder>))component4 __attribute__((swift_name("component4()")));
- (ZmsKmmKodein_diDIModule *)doCopyName:(NSString *)name allowSilentOverride:(BOOL)allowSilentOverride prefix:(NSString *)prefix init:(void (^)(id<ZmsKmmKodein_diDIBuilder>))init __attribute__((swift_name("doCopy(name:allowSilentOverride:prefix:init:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowSilentOverride __attribute__((swift_name("allowSilentOverride")));
@property (readonly, getter=doInit) void (^init)(id<ZmsKmmKodein_diDIBuilder>) __attribute__((swift_name("init")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *prefix __attribute__((swift_name("prefix")));
@end;

__attribute__((swift_name("Kodein_diDIAware")))
@protocol ZmsKmmKodein_diDIAware
@required
@property (readonly) id<ZmsKmmKodein_diDI> di __attribute__((swift_name("di")));
@property (readonly) id<ZmsKmmKodein_diDIContext> diContext __attribute__((swift_name("diContext")));
@property (readonly) ZmsKmmKodein_diDITrigger * _Nullable diTrigger __attribute__((swift_name("diTrigger")));
@end;

__attribute__((swift_name("Kodein_diDI")))
@protocol ZmsKmmKodein_diDI <ZmsKmmKodein_diDIAware>
@required
@property (readonly) id<ZmsKmmKodein_diDIContainer> container __attribute__((swift_name("container")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diLazyDI")))
@interface ZmsKmmKodein_diLazyDI : ZmsKmmBase <ZmsKmmKodein_diDI>
- (instancetype)initWithF:(id<ZmsKmmKodein_diDI> (^)(void))f __attribute__((swift_name("init(f:)"))) __attribute__((objc_designated_initializer));
- (ZmsKmmKodein_diLazyDI *)getValueThisRef:(id _Nullable)thisRef property:(id<ZmsKmmKotlinKProperty>)property __attribute__((swift_name("getValue(thisRef:property:)")));
@property (readonly) id<ZmsKmmKodein_diDI> baseDI __attribute__((swift_name("baseDI")));
@property (readonly) id<ZmsKmmKodein_diDIContainer> container __attribute__((swift_name("container")));
@end;

__attribute__((swift_name("KotlinIterator")))
@protocol ZmsKmmKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol ZmsKmmKotlinx_serialization_coreEncoder
@required
- (id<ZmsKmmKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<ZmsKmmKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<ZmsKmmKotlinx_serialization_coreEncoder>)encodeInlineInlineDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)inlineDescriptor __attribute__((swift_name("encodeInline(inlineDescriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));
- (void)encodeNull __attribute__((swift_name("encodeNull()")));
- (void)encodeNullableSerializableValueSerializer:(id<ZmsKmmKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<ZmsKmmKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) ZmsKmmKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol ZmsKmmKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<ZmsKmmKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<ZmsKmmKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) ZmsKmmKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol ZmsKmmKotlinx_serialization_coreDecoder
@required
- (id<ZmsKmmKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<ZmsKmmKotlinx_serialization_coreDecoder>)decodeInlineInlineDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)inlineDescriptor __attribute__((swift_name("decodeInline(inlineDescriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));
- (ZmsKmmKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<ZmsKmmKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<ZmsKmmKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) ZmsKmmKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpMethod.Companion")))
@interface ZmsKmmKtor_httpHttpMethodCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_httpHttpMethodCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmKtor_httpHttpMethod *)parseMethod:(NSString *)method __attribute__((swift_name("parse(method:)")));
@property (readonly) NSArray<ZmsKmmKtor_httpHttpMethod *> *DefaultMethods __attribute__((swift_name("DefaultMethods")));
@property (readonly) ZmsKmmKtor_httpHttpMethod *Delete __attribute__((swift_name("Delete")));
@property (readonly) ZmsKmmKtor_httpHttpMethod *Get __attribute__((swift_name("Get")));
@property (readonly) ZmsKmmKtor_httpHttpMethod *Head __attribute__((swift_name("Head")));
@property (readonly) ZmsKmmKtor_httpHttpMethod *Options __attribute__((swift_name("Options")));
@property (readonly) ZmsKmmKtor_httpHttpMethod *Patch __attribute__((swift_name("Patch")));
@property (readonly) ZmsKmmKtor_httpHttpMethod *Post __attribute__((swift_name("Post")));
@property (readonly) ZmsKmmKtor_httpHttpMethod *Put __attribute__((swift_name("Put")));
@end;

__attribute__((swift_name("Ktor_utilsStringValues")))
@protocol ZmsKmmKtor_utilsStringValues
@required
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<ZmsKmmKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (void)forEachBody:(void (^)(NSString *, NSArray<NSString *> *))body __attribute__((swift_name("forEach(body:)")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@end;

__attribute__((swift_name("Ktor_httpHeaders")))
@protocol ZmsKmmKtor_httpHeaders <ZmsKmmKtor_utilsStringValues>
@required
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientCall")))
@interface ZmsKmmKtor_client_coreHttpClientCall : ZmsKmmBase <ZmsKmmKotlinx_coroutines_coreCoroutineScope>
@property (class, readonly, getter=companion) ZmsKmmKtor_client_coreHttpClientCallCompanion *companion __attribute__((swift_name("companion")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)getResponseContentWithCompletionHandler:(void (^)(id<ZmsKmmKtor_ioByteReadChannel> _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getResponseContent(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)receiveInfo:(ZmsKmmKtor_client_coreTypeInfo *)info completionHandler:(void (^)(id _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("receive(info:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)receiveInfo:(id<ZmsKmmKtor_utilsTypeInfo>)info completionHandler_:(void (^)(id _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("receive(info:completionHandler_:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowDoubleReceive __attribute__((swift_name("allowDoubleReceive")));
@property (readonly) id<ZmsKmmKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) ZmsKmmKtor_client_coreHttpClient * _Nullable client __attribute__((swift_name("client")));
@property (readonly) id<ZmsKmmKotlinCoroutineContext> coroutineContext __attribute__((swift_name("coroutineContext")));
@property (readonly) id<ZmsKmmKtor_client_coreHttpRequest> request __attribute__((swift_name("request")));
@property (readonly) ZmsKmmKtor_client_coreHttpResponse *response __attribute__((swift_name("response")));
@end;

__attribute__((swift_name("Ktor_ioByteReadChannel")))
@protocol ZmsKmmKtor_ioByteReadChannel
@required
- (BOOL)cancelCause:(ZmsKmmKotlinThrowable * _Nullable)cause __attribute__((swift_name("cancel(cause:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)discardMax:(int64_t)max completionHandler:(void (^)(ZmsKmmLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("discard(max:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)peekToDestination:(ZmsKmmKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max completionHandler:(void (^)(ZmsKmmLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(ZmsKmmKtor_ioIoBuffer *)dst completionHandler:(void (^)(ZmsKmmInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(ZmsKmmKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(ZmsKmmInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(ZmsKmmInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler_:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readAvailableDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(ZmsKmmInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readAvailable(dst:offset:length:completionHandler__:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readBooleanWithCompletionHandler:(void (^)(ZmsKmmBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readBoolean(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readByteWithCompletionHandler:(void (^)(ZmsKmmByte * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readByte(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readDoubleWithCompletionHandler:(void (^)(ZmsKmmDouble * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readDouble(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFloatWithCompletionHandler:(void (^)(ZmsKmmFloat * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFloat(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(ZmsKmmKtor_ioIoBuffer *)dst n:(int32_t)n completionHandler:(void (^)(ZmsKmmKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:n:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(ZmsKmmKotlinByteArray *)dst offset:(int32_t)offset length:(int32_t)length completionHandler:(void (^)(ZmsKmmKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int32_t)offset length:(int32_t)length completionHandler_:(void (^)(ZmsKmmKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler_:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readFullyDst:(void *)dst offset:(int64_t)offset length:(int64_t)length completionHandler__:(void (^)(ZmsKmmKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readFully(dst:offset:length:completionHandler__:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readIntWithCompletionHandler:(void (^)(ZmsKmmInt * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readInt(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readLongWithCompletionHandler:(void (^)(ZmsKmmLong * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readLong(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readPacketSize:(int32_t)size headerSizeHint:(int32_t)headerSizeHint completionHandler:(void (^)(ZmsKmmKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readPacket(size:headerSizeHint:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readRemainingLimit:(int64_t)limit headerSizeHint:(int32_t)headerSizeHint completionHandler:(void (^)(ZmsKmmKtor_ioByteReadPacket * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readRemaining(limit:headerSizeHint:completionHandler:)")));
- (void)readSessionConsumer:(void (^)(id<ZmsKmmKtor_ioReadSession>))consumer __attribute__((swift_name("readSession(consumer:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readShortWithCompletionHandler:(void (^)(ZmsKmmShort * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readShort(completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readSuspendableSessionConsumer:(id<ZmsKmmKotlinSuspendFunction1>)consumer completionHandler:(void (^)(ZmsKmmKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readSuspendableSession(consumer:completionHandler:)"))) __attribute__((deprecated("Use read { } instead.")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineLimit:(int32_t)limit completionHandler:(void (^)(NSString * _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8Line(limit:completionHandler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)readUTF8LineToOut:(id<ZmsKmmKotlinAppendable>)out limit:(int32_t)limit completionHandler:(void (^)(ZmsKmmBoolean * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("readUTF8LineTo(out:limit:completionHandler:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@property (readonly) ZmsKmmKotlinThrowable * _Nullable closedCause __attribute__((swift_name("closedCause")));
@property (readonly) BOOL isClosedForRead __attribute__((swift_name("isClosedForRead")));
@property (readonly) BOOL isClosedForWrite __attribute__((swift_name("isClosedForWrite")));
@property ZmsKmmKtor_ioByteOrder *readByteOrder __attribute__((swift_name("readByteOrder"))) __attribute__((unavailable("Setting byte order is no longer supported. Read/write in big endian and use reverseByteOrder() extensions.")));
@property (readonly) int64_t totalBytesRead __attribute__((swift_name("totalBytesRead")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate")))
@interface ZmsKmmKtor_utilsGMTDate : ZmsKmmBase <ZmsKmmKotlinComparable>
@property (class, readonly, getter=companion) ZmsKmmKtor_utilsGMTDateCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)compareToOther:(ZmsKmmKtor_utilsGMTDate *)other __attribute__((swift_name("compareTo(other:)")));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (ZmsKmmKtor_utilsWeekDay *)component4 __attribute__((swift_name("component4()")));
- (int32_t)component5 __attribute__((swift_name("component5()")));
- (int32_t)component6 __attribute__((swift_name("component6()")));
- (ZmsKmmKtor_utilsMonth *)component7 __attribute__((swift_name("component7()")));
- (int32_t)component8 __attribute__((swift_name("component8()")));
- (int64_t)component9 __attribute__((swift_name("component9()")));
- (ZmsKmmKtor_utilsGMTDate *)doCopySeconds:(int32_t)seconds minutes:(int32_t)minutes hours:(int32_t)hours dayOfWeek:(ZmsKmmKtor_utilsWeekDay *)dayOfWeek dayOfMonth:(int32_t)dayOfMonth dayOfYear:(int32_t)dayOfYear month:(ZmsKmmKtor_utilsMonth *)month year:(int32_t)year timestamp:(int64_t)timestamp __attribute__((swift_name("doCopy(seconds:minutes:hours:dayOfWeek:dayOfMonth:dayOfYear:month:year:timestamp:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t dayOfMonth __attribute__((swift_name("dayOfMonth")));
@property (readonly) ZmsKmmKtor_utilsWeekDay *dayOfWeek __attribute__((swift_name("dayOfWeek")));
@property (readonly) int32_t dayOfYear __attribute__((swift_name("dayOfYear")));
@property (readonly) int32_t hours __attribute__((swift_name("hours")));
@property (readonly) int32_t minutes __attribute__((swift_name("minutes")));
@property (readonly) ZmsKmmKtor_utilsMonth *month __attribute__((swift_name("month")));
@property (readonly) int32_t seconds __attribute__((swift_name("seconds")));
@property (readonly) int64_t timestamp __attribute__((swift_name("timestamp")));
@property (readonly) int32_t year __attribute__((swift_name("year")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode")))
@interface ZmsKmmKtor_httpHttpStatusCode : ZmsKmmBase
- (instancetype)initWithValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("init(value:description:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKtor_httpHttpStatusCodeCompanion *companion __attribute__((swift_name("companion")));
- (int32_t)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmKtor_httpHttpStatusCode *)doCopyValue:(int32_t)value description:(NSString *)description __attribute__((swift_name("doCopy(value:description:)")));
- (ZmsKmmKtor_httpHttpStatusCode *)descriptionValue:(NSString *)value __attribute__((swift_name("description(value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) int32_t value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion")))
@interface ZmsKmmKtor_httpHttpProtocolVersion : ZmsKmmBase
- (instancetype)initWithName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("init(name:major:minor:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKtor_httpHttpProtocolVersionCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (ZmsKmmKtor_httpHttpProtocolVersion *)doCopyName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("doCopy(name:major:minor:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t major __attribute__((swift_name("major")));
@property (readonly) int32_t minor __attribute__((swift_name("minor")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngine")))
@protocol ZmsKmmKtor_client_coreHttpClientEngine <ZmsKmmKotlinx_coroutines_coreCoroutineScope, ZmsKmmKtor_ioCloseable>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeData:(ZmsKmmKtor_client_coreHttpRequestData *)data completionHandler:(void (^)(ZmsKmmKtor_client_coreHttpResponseData * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(data:completionHandler:)")));
- (void)installClient:(ZmsKmmKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
@property (readonly) ZmsKmmKtor_client_coreHttpClientEngineConfig *config __attribute__((swift_name("config")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreCoroutineDispatcher *dispatcher __attribute__((swift_name("dispatcher")));
@property (readonly) NSSet<id<ZmsKmmKtor_client_coreHttpClientEngineCapability>> *supportedCapabilities __attribute__((swift_name("supportedCapabilities")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineConfig")))
@interface ZmsKmmKtor_client_coreHttpClientEngineConfig : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property BOOL pipelining __attribute__((swift_name("pipelining")));
@property ZmsKmmKtor_client_coreProxyConfig * _Nullable proxy __attribute__((swift_name("proxy")));
@property (readonly) ZmsKmmKotlinNothing *response __attribute__((swift_name("response"))) __attribute__((unavailable("Response config is deprecated. See [HttpPlainText] feature for charset configuration")));
@property int32_t threadsCount __attribute__((swift_name("threadsCount")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientConfig")))
@interface ZmsKmmKtor_client_coreHttpClientConfig<T> : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (ZmsKmmKtor_client_coreHttpClientConfig<T> *)clone __attribute__((swift_name("clone()")));
- (void)engineBlock:(void (^)(T))block __attribute__((swift_name("engine(block:)")));
- (void)installClient:(ZmsKmmKtor_client_coreHttpClient *)client __attribute__((swift_name("install(client:)")));
- (void)installFeature:(id<ZmsKmmKtor_client_coreHttpClientFeature>)feature configure:(void (^)(id))configure __attribute__((swift_name("install(feature:configure:)")));
- (void)installKey:(NSString *)key block:(void (^)(ZmsKmmKtor_client_coreHttpClient *))block __attribute__((swift_name("install(key:block:)")));
- (void)plusAssignOther:(ZmsKmmKtor_client_coreHttpClientConfig<T> *)other __attribute__((swift_name("plusAssign(other:)")));
@property BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property BOOL expectSuccess __attribute__((swift_name("expectSuccess")));
@property BOOL followRedirects __attribute__((swift_name("followRedirects")));
@property BOOL useDefaultTransformers __attribute__((swift_name("useDefaultTransformers")));
@end;

__attribute__((swift_name("Ktor_httpHttpMessageBuilder")))
@protocol ZmsKmmKtor_httpHttpMessageBuilder
@required
@property (readonly) ZmsKmmKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder")))
@interface ZmsKmmKtor_client_coreHttpRequestBuilder : ZmsKmmBase <ZmsKmmKtor_httpHttpMessageBuilder>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) ZmsKmmKtor_client_coreHttpRequestBuilderCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmKtor_client_coreHttpRequestData *)build __attribute__((swift_name("build()")));
- (id _Nullable)getCapabilityOrNullKey:(id<ZmsKmmKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (void)setAttributesBlock:(void (^)(id<ZmsKmmKtor_utilsAttributes>))block __attribute__((swift_name("setAttributes(block:)")));
- (void)setCapabilityKey:(id<ZmsKmmKtor_client_coreHttpClientEngineCapability>)key capability:(id)capability __attribute__((swift_name("setCapability(key:capability:)")));
- (ZmsKmmKtor_client_coreHttpRequestBuilder *)takeFromBuilder:(ZmsKmmKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFrom(builder:)")));
- (ZmsKmmKtor_client_coreHttpRequestBuilder *)takeFromWithExecutionContextBuilder:(ZmsKmmKtor_client_coreHttpRequestBuilder *)builder __attribute__((swift_name("takeFromWithExecutionContext(builder:)")));
- (void)urlBlock:(void (^)(ZmsKmmKtor_httpURLBuilder *, ZmsKmmKtor_httpURLBuilder *))block __attribute__((swift_name("url(block:)")));
@property (readonly) id<ZmsKmmKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property id body __attribute__((swift_name("body")));
@property (readonly) id<ZmsKmmKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) ZmsKmmKtor_httpHeadersBuilder *headers __attribute__((swift_name("headers")));
@property ZmsKmmKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) ZmsKmmKtor_httpURLBuilder *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientEngineCapability")))
@protocol ZmsKmmKtor_client_coreHttpClientEngineCapability
@required
@end;

__attribute__((swift_name("Ktor_utilsAttributes")))
@protocol ZmsKmmKtor_utilsAttributes
@required
- (id)computeIfAbsentKey:(ZmsKmmKtor_utilsAttributeKey<id> *)key block:(id (^)(void))block __attribute__((swift_name("computeIfAbsent(key:block:)")));
- (BOOL)containsKey:(ZmsKmmKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("contains(key:)")));
- (id)getKey_:(ZmsKmmKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("get(key_:)")));
- (id _Nullable)getOrNullKey:(ZmsKmmKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getOrNull(key:)")));
- (void)putKey:(ZmsKmmKtor_utilsAttributeKey<id> *)key value:(id)value __attribute__((swift_name("put(key:value:)")));
- (void)removeKey:(ZmsKmmKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("remove(key:)")));
- (id)takeKey:(ZmsKmmKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("take(key:)")));
- (id _Nullable)takeOrNullKey:(ZmsKmmKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("takeOrNull(key:)")));
@property (readonly) NSArray<ZmsKmmKtor_utilsAttributeKey<id> *> *allKeys __attribute__((swift_name("allKeys")));
@end;

__attribute__((swift_name("KotlinCoroutineContextElement")))
@protocol ZmsKmmKotlinCoroutineContextElement <ZmsKmmKotlinCoroutineContext>
@required
@property (readonly) id<ZmsKmmKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinAbstractCoroutineContextElement")))
@interface ZmsKmmKotlinAbstractCoroutineContextElement : ZmsKmmBase <ZmsKmmKotlinCoroutineContextElement>
- (instancetype)initWithKey:(id<ZmsKmmKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<ZmsKmmKotlinCoroutineContextKey> key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("KotlinContinuationInterceptor")))
@protocol ZmsKmmKotlinContinuationInterceptor <ZmsKmmKotlinCoroutineContextElement>
@required
- (id<ZmsKmmKotlinContinuation>)interceptContinuationContinuation:(id<ZmsKmmKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (void)releaseInterceptedContinuationContinuation:(id<ZmsKmmKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher")))
@interface ZmsKmmKotlinx_coroutines_coreCoroutineDispatcher : ZmsKmmKotlinAbstractCoroutineContextElement <ZmsKmmKotlinContinuationInterceptor>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithKey:(id<ZmsKmmKotlinCoroutineContextKey>)key __attribute__((swift_name("init(key:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKotlinx_coroutines_coreCoroutineDispatcherKey *companion __attribute__((swift_name("companion")));
- (void)dispatchContext:(id<ZmsKmmKotlinCoroutineContext>)context block:(id<ZmsKmmKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatch(context:block:)")));
- (void)dispatchYieldContext:(id<ZmsKmmKotlinCoroutineContext>)context block:(id<ZmsKmmKotlinx_coroutines_coreRunnable>)block __attribute__((swift_name("dispatchYield(context:block:)")));
- (id<ZmsKmmKotlinContinuation>)interceptContinuationContinuation:(id<ZmsKmmKotlinContinuation>)continuation __attribute__((swift_name("interceptContinuation(continuation:)")));
- (BOOL)isDispatchNeededContext:(id<ZmsKmmKotlinCoroutineContext>)context __attribute__((swift_name("isDispatchNeeded(context:)")));
- (ZmsKmmKotlinx_coroutines_coreCoroutineDispatcher *)plusOther:(ZmsKmmKotlinx_coroutines_coreCoroutineDispatcher *)other __attribute__((swift_name("plus(other:)"))) __attribute__((unavailable("Operator '+' on two CoroutineDispatcher objects is meaningless. CoroutineDispatcher is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The dispatcher to the right of `+` just replaces the dispatcher to the left.")));
- (void)releaseInterceptedContinuationContinuation:(id<ZmsKmmKotlinContinuation>)continuation __attribute__((swift_name("releaseInterceptedContinuation(continuation:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Ktor_utilsPipeline")))
@interface ZmsKmmKtor_utilsPipeline<TSubject, TContext> : ZmsKmmBase
- (instancetype)initWithPhase:(ZmsKmmKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<ZmsKmmKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhases:(ZmsKmmKotlinArray<ZmsKmmKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer));
- (void)addPhasePhase:(ZmsKmmKtor_utilsPipelinePhase *)phase __attribute__((swift_name("addPhase(phase:)")));
- (void)afterIntercepted __attribute__((swift_name("afterIntercepted()")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)executeContext:(TContext)context subject:(TSubject)subject completionHandler:(void (^)(TSubject _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("execute(context:subject:completionHandler:)")));
- (void)insertPhaseAfterReference:(ZmsKmmKtor_utilsPipelinePhase *)reference phase:(ZmsKmmKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseAfter(reference:phase:)")));
- (void)insertPhaseBeforeReference:(ZmsKmmKtor_utilsPipelinePhase *)reference phase:(ZmsKmmKtor_utilsPipelinePhase *)phase __attribute__((swift_name("insertPhaseBefore(reference:phase:)")));
- (void)interceptPhase:(ZmsKmmKtor_utilsPipelinePhase *)phase block:(id<ZmsKmmKotlinSuspendFunction2>)block __attribute__((swift_name("intercept(phase:block:)")));
- (void)mergeFrom:(ZmsKmmKtor_utilsPipeline<TSubject, TContext> *)from __attribute__((swift_name("merge(from:)")));
@property (readonly) id<ZmsKmmKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@property (readonly, getter=isEmpty_) BOOL isEmpty __attribute__((swift_name("isEmpty")));
@property (readonly) NSArray<ZmsKmmKtor_utilsPipelinePhase *> *items __attribute__((swift_name("items")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline")))
@interface ZmsKmmKtor_client_coreHttpReceivePipeline : ZmsKmmKtor_utilsPipeline<ZmsKmmKtor_client_coreHttpResponse *, ZmsKmmKtor_client_coreHttpClientCall *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(ZmsKmmKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<ZmsKmmKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(ZmsKmmKotlinArray<ZmsKmmKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKtor_client_coreHttpReceivePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline")))
@interface ZmsKmmKtor_client_coreHttpRequestPipeline : ZmsKmmKtor_utilsPipeline<id, ZmsKmmKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(ZmsKmmKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<ZmsKmmKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(ZmsKmmKotlinArray<ZmsKmmKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKtor_client_coreHttpRequestPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline")))
@interface ZmsKmmKtor_client_coreHttpResponsePipeline : ZmsKmmKtor_utilsPipeline<ZmsKmmKtor_client_coreHttpResponseContainer *, ZmsKmmKtor_client_coreHttpClientCall *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(ZmsKmmKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<ZmsKmmKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(ZmsKmmKotlinArray<ZmsKmmKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKtor_client_coreHttpResponsePipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline")))
@interface ZmsKmmKtor_client_coreHttpSendPipeline : ZmsKmmKtor_utilsPipeline<id, ZmsKmmKtor_client_coreHttpRequestBuilder *>
- (instancetype)initWithDevelopmentMode:(BOOL)developmentMode __attribute__((swift_name("init(developmentMode:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithPhase:(ZmsKmmKtor_utilsPipelinePhase *)phase interceptors:(NSArray<id<ZmsKmmKotlinSuspendFunction2>> *)interceptors __attribute__((swift_name("init(phase:interceptors:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (instancetype)initWithPhases:(ZmsKmmKotlinArray<ZmsKmmKtor_utilsPipelinePhase *> *)phases __attribute__((swift_name("init(phases:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKtor_client_coreHttpSendPipelinePhases *companion __attribute__((swift_name("companion")));
@property (readonly) BOOL developmentMode __attribute__((swift_name("developmentMode")));
@end;

__attribute__((swift_name("RuntimeSqlCursor")))
@protocol ZmsKmmRuntimeSqlCursor <ZmsKmmRuntimeCloseable>
@required
- (ZmsKmmKotlinByteArray * _Nullable)getBytesIndex:(int32_t)index __attribute__((swift_name("getBytes(index:)")));
- (ZmsKmmDouble * _Nullable)getDoubleIndex:(int32_t)index __attribute__((swift_name("getDouble(index:)")));
- (ZmsKmmLong * _Nullable)getLongIndex:(int32_t)index __attribute__((swift_name("getLong(index:)")));
- (NSString * _Nullable)getStringIndex:(int32_t)index __attribute__((swift_name("getString(index:)")));
- (BOOL)next_ __attribute__((swift_name("next_()")));
@end;

__attribute__((swift_name("RuntimeQueryListener")))
@protocol ZmsKmmRuntimeQueryListener
@required
- (void)queryResultsChanged __attribute__((swift_name("queryResultsChanged()")));
@end;

__attribute__((swift_name("RuntimeTransacterTransaction")))
@interface ZmsKmmRuntimeTransacterTransaction : ZmsKmmBase <ZmsKmmRuntimeTransactionCallbacks>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)afterCommitFunction:(void (^)(void))function __attribute__((swift_name("afterCommit(function:)")));
- (void)afterRollbackFunction:(void (^)(void))function __attribute__((swift_name("afterRollback(function:)")));
- (void)endTransactionSuccessful:(BOOL)successful __attribute__((swift_name("endTransaction(successful:)")));
@property (readonly) ZmsKmmRuntimeTransacterTransaction * _Nullable enclosingTransaction __attribute__((swift_name("enclosingTransaction")));
@end;

__attribute__((swift_name("RuntimeSqlPreparedStatement")))
@protocol ZmsKmmRuntimeSqlPreparedStatement
@required
- (void)bindBytesIndex:(int32_t)index bytes:(ZmsKmmKotlinByteArray * _Nullable)bytes __attribute__((swift_name("bindBytes(index:bytes:)")));
- (void)bindDoubleIndex:(int32_t)index double:(ZmsKmmDouble * _Nullable)double_ __attribute__((swift_name("bindDouble(index:double:)")));
- (void)bindLongIndex:(int32_t)index long:(ZmsKmmLong * _Nullable)long_ __attribute__((swift_name("bindLong(index:long:)")));
- (void)bindStringIndex:(int32_t)index string:(NSString * _Nullable)string __attribute__((swift_name("bindString(index:string:)")));
@end;

__attribute__((swift_name("KotlinCoroutineContextKey")))
@protocol ZmsKmmKotlinCoroutineContextKey
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface ZmsKmmKotlinx_serialization_coreSerializersModule : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)dumpToCollector:(id<ZmsKmmKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<ZmsKmmKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<ZmsKmmKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));
- (id<ZmsKmmKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<ZmsKmmKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));
- (id<ZmsKmmKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<ZmsKmmKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonConfiguration")))
@interface ZmsKmmKotlinx_serialization_jsonJsonConfiguration : ZmsKmmBase
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL allowSpecialFloatingPointValues __attribute__((swift_name("allowSpecialFloatingPointValues")));
@property (readonly) BOOL allowStructuredMapKeys __attribute__((swift_name("allowStructuredMapKeys")));
@property (readonly) NSString *classDiscriminator __attribute__((swift_name("classDiscriminator")));
@property (readonly) BOOL coerceInputValues __attribute__((swift_name("coerceInputValues")));
@property (readonly) BOOL encodeDefaults __attribute__((swift_name("encodeDefaults")));
@property (readonly) BOOL ignoreUnknownKeys __attribute__((swift_name("ignoreUnknownKeys")));
@property (readonly) BOOL isLenient __attribute__((swift_name("isLenient")));
@property (readonly) BOOL prettyPrint __attribute__((swift_name("prettyPrint")));
@property (readonly) NSString *prettyPrintIndent __attribute__((swift_name("prettyPrintIndent")));
@property (readonly) BOOL useAlternativeNames __attribute__((swift_name("useAlternativeNames")));
@property (readonly) BOOL useArrayPolymorphism __attribute__((swift_name("useArrayPolymorphism")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJson.Default")))
@interface ZmsKmmKotlinx_serialization_jsonJsonDefault : ZmsKmmKotlinx_serialization_jsonJson
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithConfiguration:(ZmsKmmKotlinx_serialization_jsonJsonConfiguration *)configuration serializersModule:(ZmsKmmKotlinx_serialization_coreSerializersModule *)serializersModule __attribute__((swift_name("init(configuration:serializersModule:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)default_ __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKotlinx_serialization_jsonJsonDefault *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface ZmsKmmKotlinx_serialization_jsonJsonElement : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
@property (class, readonly, getter=companion) ZmsKmmKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end;

__attribute__((swift_name("Kodein_diDIBindBuilder")))
@protocol ZmsKmmKodein_diDIBindBuilder
@required
@property (readonly) id<ZmsKmmKodein_typeTypeToken> contextType __attribute__((swift_name("contextType")));
@property (readonly) BOOL explicitContext __attribute__((swift_name("explicitContext")));
@end;

__attribute__((swift_name("Kodein_diDIBindBuilderWithScope")))
@protocol ZmsKmmKodein_diDIBindBuilderWithScope <ZmsKmmKodein_diDIBindBuilder>
@required
@property (readonly) id<ZmsKmmKodein_diScope> scope __attribute__((swift_name("scope")));
@end;

__attribute__((swift_name("Kodein_diDIBuilder")))
@protocol ZmsKmmKodein_diDIBuilder <ZmsKmmKodein_diDIBindBuilder, ZmsKmmKodein_diDIBindBuilderWithScope>
@required
- (id<ZmsKmmKodein_diDIBuilderDirectBinder>)BindTag:(id _Nullable)tag overrides:(ZmsKmmBoolean * _Nullable)overrides __attribute__((swift_name("Bind(tag:overrides:)")));
- (void)BindTag:(id _Nullable)tag overrides:(ZmsKmmBoolean * _Nullable)overrides binding:(id<ZmsKmmKodein_diDIBinding>)binding __attribute__((swift_name("Bind(tag:overrides:binding:)")));
- (id<ZmsKmmKodein_diDIBuilderTypeBinder>)BindType:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag overrides:(ZmsKmmBoolean * _Nullable)overrides __attribute__((swift_name("Bind(type:tag:overrides:)")));
- (void)BindSetTag:(id _Nullable)tag overrides:(ZmsKmmBoolean * _Nullable)overrides binding:(id<ZmsKmmKodein_diDIBinding>)binding __attribute__((swift_name("BindSet(tag:overrides:binding:)")));
- (void)RegisterContextTranslatorTranslator:(id<ZmsKmmKodein_diContextTranslator>)translator __attribute__((swift_name("RegisterContextTranslator(translator:)")));
- (id<ZmsKmmKodein_diDIBuilderConstantBinder>)constantTag:(id)tag overrides:(ZmsKmmBoolean * _Nullable)overrides __attribute__((swift_name("constant(tag:overrides:)")));
- (void)importModule:(ZmsKmmKodein_diDIModule *)module allowOverride:(BOOL)allowOverride __attribute__((swift_name("import(module:allowOverride:)")));
- (void)importAllModules:(ZmsKmmKotlinArray<ZmsKmmKodein_diDIModule *> *)modules allowOverride:(BOOL)allowOverride __attribute__((swift_name("importAll(modules:allowOverride:)")));
- (void)importAllModules:(id)modules allowOverride_:(BOOL)allowOverride __attribute__((swift_name("importAll(modules:allowOverride_:)")));
- (void)importOnceModule:(ZmsKmmKodein_diDIModule *)module allowOverride:(BOOL)allowOverride __attribute__((swift_name("importOnce(module:allowOverride:)")));
- (void)onReadyCb:(void (^)(id<ZmsKmmKodein_diDirectDI>))cb __attribute__((swift_name("onReady(cb:)")));
@property (readonly) id<ZmsKmmKodein_diDIContainerBuilder> containerBuilder __attribute__((swift_name("containerBuilder")));
@end;

__attribute__((swift_name("Kodein_diDIContainer")))
@protocol ZmsKmmKodein_diDIContainer
@required
- (NSArray<id (^)(id _Nullable)> *)allFactoriesKey:(ZmsKmmKodein_diDIKey<id, id, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("allFactories(key:context:overrideLevel:)")));
- (NSArray<id (^)(void)> *)allProvidersKey:(ZmsKmmKodein_diDIKey<id, ZmsKmmKotlinUnit *, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("allProviders(key:context:overrideLevel:)")));
- (id (^)(id _Nullable))factoryKey:(ZmsKmmKodein_diDIKey<id, id, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("factory(key:context:overrideLevel:)")));
- (id (^ _Nullable)(id _Nullable))factoryOrNullKey:(ZmsKmmKodein_diDIKey<id, id, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("factoryOrNull(key:context:overrideLevel:)")));
- (id (^)(void))providerKey:(ZmsKmmKodein_diDIKey<id, ZmsKmmKotlinUnit *, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("provider(key:context:overrideLevel:)")));
- (id (^ _Nullable)(void))providerOrNullKey:(ZmsKmmKodein_diDIKey<id, ZmsKmmKotlinUnit *, id> *)key context:(id)context overrideLevel:(int32_t)overrideLevel __attribute__((swift_name("providerOrNull(key:context:overrideLevel:)")));
@property (readonly) id<ZmsKmmKodein_diDITree> tree __attribute__((swift_name("tree")));
@end;

__attribute__((swift_name("Kodein_diDIContext")))
@protocol ZmsKmmKodein_diDIContext
@required
@property (readonly) id<ZmsKmmKodein_typeTypeToken> type __attribute__((swift_name("type")));
@property (readonly) id value_ __attribute__((swift_name("value_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDITrigger")))
@interface ZmsKmmKodein_diDITrigger : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)trigger __attribute__((swift_name("trigger()")));
@property (readonly) NSMutableArray<id<ZmsKmmKotlinLazy>> *properties __attribute__((swift_name("properties")));
@end;

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol ZmsKmmKotlinKAnnotatedElement
@required
@end;

__attribute__((swift_name("KotlinKCallable")))
@protocol ZmsKmmKotlinKCallable <ZmsKmmKotlinKAnnotatedElement>
@required
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) id<ZmsKmmKotlinKType> returnType __attribute__((swift_name("returnType")));
@end;

__attribute__((swift_name("KotlinKProperty")))
@protocol ZmsKmmKotlinKProperty <ZmsKmmKotlinKCallable>
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol ZmsKmmKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<ZmsKmmKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));
- (void)encodeNullableSerializableElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<ZmsKmmKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<ZmsKmmKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) ZmsKmmKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((swift_name("KotlinAnnotation")))
@protocol ZmsKmmKotlinAnnotation
@required
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface ZmsKmmKotlinx_serialization_coreSerialKind : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol ZmsKmmKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<ZmsKmmKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<ZmsKmmKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<ZmsKmmKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<ZmsKmmKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) ZmsKmmKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface ZmsKmmKotlinNothing : ZmsKmmBase
@end;

__attribute__((swift_name("KotlinMapEntry")))
@protocol ZmsKmmKotlinMapEntry
@required
@property (readonly) id _Nullable key __attribute__((swift_name("key")));
@property (readonly) id _Nullable value_ __attribute__((swift_name("value_")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpClientCall.Companion")))
@interface ZmsKmmKtor_client_coreHttpClientCallCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_client_coreHttpClientCallCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_utilsAttributeKey<id> *CustomResponse __attribute__((swift_name("CustomResponse"))) __attribute__((deprecated("This is going to be removed. Please file a ticket with clarification why and what for do you need it.")));
@end;

__attribute__((swift_name("Ktor_utilsTypeInfo")))
@protocol ZmsKmmKtor_utilsTypeInfo
@required
@property (readonly) id<ZmsKmmKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<ZmsKmmKotlinKType> reifiedType __attribute__((swift_name("reifiedType")));
@property (readonly) id<ZmsKmmKotlinKClass> type __attribute__((swift_name("type")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreTypeInfo")))
@interface ZmsKmmKtor_client_coreTypeInfo : ZmsKmmBase <ZmsKmmKtor_utilsTypeInfo>
- (instancetype)initWithType:(id<ZmsKmmKotlinKClass>)type reifiedType:(id<ZmsKmmKotlinKType>)reifiedType kotlinType:(id<ZmsKmmKotlinKType> _Nullable)kotlinType __attribute__((swift_name("init(type:reifiedType:kotlinType:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("This was moved to another package.")));
- (id<ZmsKmmKotlinKClass>)component1 __attribute__((swift_name("component1()")));
- (id<ZmsKmmKotlinKType>)component2 __attribute__((swift_name("component2()")));
- (id<ZmsKmmKotlinKType> _Nullable)component3 __attribute__((swift_name("component3()")));
- (ZmsKmmKtor_client_coreTypeInfo *)doCopyType:(id<ZmsKmmKotlinKClass>)type reifiedType:(id<ZmsKmmKotlinKType>)reifiedType kotlinType:(id<ZmsKmmKotlinKType> _Nullable)kotlinType __attribute__((swift_name("doCopy(type:reifiedType:kotlinType:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<ZmsKmmKotlinKType> _Nullable kotlinType __attribute__((swift_name("kotlinType")));
@property (readonly) id<ZmsKmmKotlinKType> reifiedType __attribute__((swift_name("reifiedType")));
@property (readonly) id<ZmsKmmKotlinKClass> type __attribute__((swift_name("type")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpRequest")))
@protocol ZmsKmmKtor_client_coreHttpRequest <ZmsKmmKtor_httpHttpMessage, ZmsKmmKotlinx_coroutines_coreCoroutineScope>
@required
@property (readonly) id<ZmsKmmKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) ZmsKmmKtor_client_coreHttpClientCall *call __attribute__((swift_name("call")));
@property (readonly) ZmsKmmKtor_httpOutgoingContent *content __attribute__((swift_name("content")));
@property (readonly) ZmsKmmKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) ZmsKmmKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory")))
@interface ZmsKmmKtor_ioMemory : ZmsKmmBase
- (instancetype)initWithPointer:(void *)pointer size:(int64_t)size __attribute__((swift_name("init(pointer:size:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKtor_ioMemoryCompanion *companion __attribute__((swift_name("companion")));
- (void)doCopyToDestination:(ZmsKmmKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length destinationOffset:(int32_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset:)")));
- (void)doCopyToDestination:(ZmsKmmKtor_ioMemory *)destination offset:(int64_t)offset length:(int64_t)length destinationOffset_:(int64_t)destinationOffset __attribute__((swift_name("doCopyTo(destination:offset:length:destinationOffset_:)")));
- (int8_t)loadAtIndex:(int32_t)index __attribute__((swift_name("loadAt(index:)")));
- (int8_t)loadAtIndex_:(int64_t)index __attribute__((swift_name("loadAt(index_:)")));
- (ZmsKmmKtor_ioMemory *)sliceOffset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("slice(offset:length:)")));
- (ZmsKmmKtor_ioMemory *)sliceOffset:(int64_t)offset length_:(int64_t)length __attribute__((swift_name("slice(offset:length_:)")));
- (void)storeAtIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("storeAt(index:value:)")));
- (void)storeAtIndex:(int64_t)index value_:(int8_t)value __attribute__((swift_name("storeAt(index:value_:)")));
@property (readonly) void *pointer __attribute__((swift_name("pointer")));
@property (readonly) int64_t size __attribute__((swift_name("size")));
@property (readonly) int32_t size32 __attribute__((swift_name("size32")));
@end;

__attribute__((swift_name("Ktor_ioBuffer")))
@interface ZmsKmmKtor_ioBuffer : ZmsKmmBase
- (instancetype)initWithMemory:(ZmsKmmKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKtor_ioBufferCompanion *companion __attribute__((swift_name("companion")));
- (void)commitWrittenCount:(int32_t)count __attribute__((swift_name("commitWritten(count:)")));
- (int32_t)discardCount:(int32_t)count __attribute__((swift_name("discard(count:)"))) __attribute__((unavailable("Use discardExact instead.")));
- (int64_t)discardCount_:(int64_t)count __attribute__((swift_name("discard(count_:)"))) __attribute__((unavailable("Use discardExact instead.")));
- (void)discardExactCount:(int32_t)count __attribute__((swift_name("discardExact(count:)")));
- (ZmsKmmKtor_ioBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)duplicateToCopy:(ZmsKmmKtor_ioBuffer *)copy __attribute__((swift_name("duplicateTo(copy:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (void)reserveEndGapEndGap:(int32_t)endGap __attribute__((swift_name("reserveEndGap(endGap:)")));
- (void)reserveStartGapStartGap:(int32_t)startGap __attribute__((swift_name("reserveStartGap(startGap:)")));
- (void)reset __attribute__((swift_name("reset()")));
- (void)resetForRead __attribute__((swift_name("resetForRead()")));
- (void)resetForWrite __attribute__((swift_name("resetForWrite()")));
- (void)resetForWriteLimit:(int32_t)limit __attribute__((swift_name("resetForWrite(limit:)")));
- (void)rewindCount:(int32_t)count __attribute__((swift_name("rewind(count:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeekByte __attribute__((swift_name("tryPeekByte()")));
- (int32_t)tryReadByte __attribute__((swift_name("tryReadByte()")));
- (void)writeByteValue:(int8_t)value __attribute__((swift_name("writeByte(value:)")));
@property id _Nullable attachment __attribute__((swift_name("attachment"))) __attribute__((deprecated("Will be removed. Inherit Buffer and add required fields instead.")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@property (readonly) int32_t endGap __attribute__((swift_name("endGap")));
@property (readonly) int32_t limit __attribute__((swift_name("limit")));
@property (readonly) ZmsKmmKtor_ioMemory *memory __attribute__((swift_name("memory")));
@property (readonly) int32_t readPosition __attribute__((swift_name("readPosition")));
@property (readonly) int32_t readRemaining __attribute__((swift_name("readRemaining")));
@property (readonly) int32_t startGap __attribute__((swift_name("startGap")));
@property (readonly) int32_t writePosition __attribute__((swift_name("writePosition")));
@property (readonly) int32_t writeRemaining __attribute__((swift_name("writeRemaining")));
@end;

__attribute__((swift_name("Ktor_ioChunkBuffer")))
@interface ZmsKmmKtor_ioChunkBuffer : ZmsKmmKtor_ioBuffer
- (instancetype)initWithMemory:(ZmsKmmKtor_ioMemory *)memory origin:(ZmsKmmKtor_ioChunkBuffer * _Nullable)origin parentPool:(id<ZmsKmmKtor_ioObjectPool> _Nullable)parentPool __attribute__((swift_name("init(memory:origin:parentPool:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMemory:(ZmsKmmKtor_ioMemory *)memory __attribute__((swift_name("init(memory:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKtor_ioChunkBufferCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmKtor_ioChunkBuffer * _Nullable)cleanNext __attribute__((swift_name("cleanNext()")));
- (ZmsKmmKtor_ioChunkBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)releasePool:(id<ZmsKmmKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool:)")));
- (void)reset __attribute__((swift_name("reset()")));
@property (getter=next__) ZmsKmmKtor_ioChunkBuffer * _Nullable next __attribute__((swift_name("next")));
@property (readonly) ZmsKmmKtor_ioChunkBuffer * _Nullable origin __attribute__((swift_name("origin")));
@property (readonly) int32_t referenceCount __attribute__((swift_name("referenceCount")));
@end;

__attribute__((swift_name("Ktor_ioInput")))
@protocol ZmsKmmKtor_ioInput <ZmsKmmKtor_ioCloseable>
@required
- (int64_t)discardN:(int64_t)n __attribute__((swift_name("discard(n:)")));
- (int64_t)peekToDestination:(ZmsKmmKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
@property ZmsKmmKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((unavailable("Not supported anymore. All operations are big endian by default. Use readXXXLittleEndian or readXXX then X.reverseByteOrder() instead.")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@end;

__attribute__((swift_name("KotlinAppendable")))
@protocol ZmsKmmKotlinAppendable
@required
- (id<ZmsKmmKotlinAppendable>)appendValue:(unichar)value __attribute__((swift_name("append(value:)")));
- (id<ZmsKmmKotlinAppendable>)appendValue_:(id _Nullable)value __attribute__((swift_name("append(value_:)")));
- (id<ZmsKmmKotlinAppendable>)appendValue:(id _Nullable)value startIndex:(int32_t)startIndex endIndex:(int32_t)endIndex __attribute__((swift_name("append(value:startIndex:endIndex:)")));
@end;

__attribute__((swift_name("Ktor_ioOutput")))
@protocol ZmsKmmKtor_ioOutput <ZmsKmmKotlinAppendable, ZmsKmmKtor_ioCloseable>
@required
- (id<ZmsKmmKotlinAppendable>)appendCsq:(ZmsKmmKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("append(csq:start:end:)")));
- (void)flush __attribute__((swift_name("flush()")));
- (void)writeByteV:(int8_t)v __attribute__((swift_name("writeByte(v:)")));
@property ZmsKmmKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((deprecated("Write with writeXXXLittleEndian or do X.reverseByteOrder() and then writeXXX instead.")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioIoBuffer")))
@interface ZmsKmmKtor_ioIoBuffer : ZmsKmmKtor_ioChunkBuffer <ZmsKmmKtor_ioInput, ZmsKmmKtor_ioOutput>
- (instancetype)initWithMemory:(ZmsKmmKtor_ioMemory *)memory origin:(ZmsKmmKtor_ioChunkBuffer * _Nullable)origin __attribute__((swift_name("init(memory:origin:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use Buffer instead.")));
- (instancetype)initWithContent:(void *)content contentCapacity:(int32_t)contentCapacity __attribute__((swift_name("init(content:contentCapacity:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Use Buffer instead.")));
- (instancetype)initWithMemory:(ZmsKmmKtor_ioMemory *)memory origin:(ZmsKmmKtor_ioChunkBuffer * _Nullable)origin parentPool:(id<ZmsKmmKtor_ioObjectPool> _Nullable)parentPool __attribute__((swift_name("init(memory:origin:parentPool:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKtor_ioIoBufferCompanion *companion __attribute__((swift_name("companion")));
- (id<ZmsKmmKotlinAppendable>)appendValue:(unichar)c __attribute__((swift_name("append(value:)")));
- (id<ZmsKmmKotlinAppendable>)appendCsq:(ZmsKmmKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("append(csq:start:end:)")));
- (id<ZmsKmmKotlinAppendable>)appendValue_:(id _Nullable)csq __attribute__((swift_name("append(value_:)")));
- (id<ZmsKmmKotlinAppendable>)appendValue:(id _Nullable)csq startIndex:(int32_t)start endIndex:(int32_t)end __attribute__((swift_name("append(value:startIndex:endIndex:)")));
- (int32_t)appendCharsCsq:(ZmsKmmKotlinCharArray *)csq start:(int32_t)start end:(int32_t)end __attribute__((swift_name("appendChars(csq:start:end:)")));
- (int32_t)appendCharsCsq:(id)csq start:(int32_t)start end_:(int32_t)end __attribute__((swift_name("appendChars(csq:start:end_:)")));
- (void)close __attribute__((swift_name("close()")));
- (ZmsKmmKtor_ioIoBuffer *)duplicate __attribute__((swift_name("duplicate()")));
- (void)flush __attribute__((swift_name("flush()")));
- (ZmsKmmKtor_ioIoBuffer *)makeView __attribute__((swift_name("makeView()")));
- (int64_t)peekToDestination:(ZmsKmmKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (int32_t)readDirectBlock:(ZmsKmmInt *(^)(id))block __attribute__((swift_name("readDirect(block:)")));
- (void)releasePool_:(id<ZmsKmmKtor_ioObjectPool>)pool __attribute__((swift_name("release(pool_:)")));
- (NSString *)description __attribute__((swift_name("description()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
- (int32_t)writeDirectBlock:(ZmsKmmInt *(^)(id))block __attribute__((swift_name("writeDirect(block:)")));
@property ZmsKmmKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((unavailable("Not supported anymore. All operations are big endian by default.")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinByteArray")))
@interface ZmsKmmKotlinByteArray : ZmsKmmBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(ZmsKmmByte *(^)(ZmsKmmInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (int8_t)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (ZmsKmmKotlinByteIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(int8_t)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((swift_name("Ktor_ioAbstractInput")))
@interface ZmsKmmKtor_ioAbstractInput : ZmsKmmBase <ZmsKmmKtor_ioInput>
- (instancetype)initWithHead:(ZmsKmmKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<ZmsKmmKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("AbstractInput is deprecated and will be merged with Input in 2.0.0")));
@property (class, readonly, getter=companion) ZmsKmmKtor_ioAbstractInputCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)canRead __attribute__((swift_name("canRead()")));
- (void)close __attribute__((swift_name("close()")));
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (int32_t)discardN_:(int32_t)n __attribute__((swift_name("discard(n_:)")));
- (int64_t)discardN:(int64_t)n __attribute__((swift_name("discard(n:)")));
- (void)discardExactN:(int32_t)n __attribute__((swift_name("discardExact(n:)")));
- (ZmsKmmKtor_ioChunkBuffer * _Nullable)ensureNextHeadCurrent:(ZmsKmmKtor_ioChunkBuffer *)current __attribute__((swift_name("ensureNextHead(current:)")));
- (ZmsKmmKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));
- (int32_t)fillDestination:(ZmsKmmKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (void)fixGapAfterReadCurrent:(ZmsKmmKtor_ioChunkBuffer *)current __attribute__((swift_name("fixGapAfterRead(current:)")));
- (BOOL)hasBytesN:(int32_t)n __attribute__((swift_name("hasBytes(n:)")));
- (void)markNoMoreChunksAvailable __attribute__((swift_name("markNoMoreChunksAvailable()")));
- (int64_t)peekToDestination:(ZmsKmmKtor_ioMemory *)destination destinationOffset:(int64_t)destinationOffset offset:(int64_t)offset min:(int64_t)min max:(int64_t)max __attribute__((swift_name("peekTo(destination:destinationOffset:offset:min:max:)")));
- (ZmsKmmKtor_ioChunkBuffer * _Nullable)prepareReadHeadMinSize:(int32_t)minSize __attribute__((swift_name("prepareReadHead(minSize:)")));
- (int8_t)readByte __attribute__((swift_name("readByte()")));
- (NSString *)readTextMin:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(min:max:)")));
- (int32_t)readTextOut:(id<ZmsKmmKotlinAppendable>)out min:(int32_t)min max:(int32_t)max __attribute__((swift_name("readText(out:min:max:)")));
- (NSString *)readTextExactExactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(exactCharacters:)")));
- (void)readTextExactOut:(id<ZmsKmmKotlinAppendable>)out exactCharacters:(int32_t)exactCharacters __attribute__((swift_name("readTextExact(out:exactCharacters:)")));
- (void)release_ __attribute__((swift_name("release()")));
- (int32_t)tryPeek __attribute__((swift_name("tryPeek()")));
- (void)updateHeadRemainingRemaining:(int32_t)remaining __attribute__((swift_name("updateHeadRemaining(remaining:)"))) __attribute__((unavailable("Not supported anymore.")));
@property ZmsKmmKtor_ioByteOrder *byteOrder __attribute__((swift_name("byteOrder"))) __attribute__((unavailable("Not supported anymore. All operations are big endian by default.")));
@property (readonly) BOOL endOfInput __attribute__((swift_name("endOfInput")));
@property (readonly) id<ZmsKmmKtor_ioObjectPool> pool __attribute__((swift_name("pool")));
@property (readonly) int64_t remaining __attribute__((swift_name("remaining")));
@end;

__attribute__((swift_name("Ktor_ioByteReadPacketBase")))
@interface ZmsKmmKtor_ioByteReadPacketBase : ZmsKmmKtor_ioAbstractInput
- (instancetype)initWithHead:(ZmsKmmKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<ZmsKmmKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer)) __attribute__((deprecated("Will be removed in the future releases. Use Input or AbstractInput instead.")));
@property (class, readonly, getter=companion) ZmsKmmKtor_ioByteReadPacketBaseCompanion *companion __attribute__((swift_name("companion")));
@end;

__attribute__((swift_name("Ktor_ioByteReadPacketPlatformBase")))
@interface ZmsKmmKtor_ioByteReadPacketPlatformBase : ZmsKmmKtor_ioByteReadPacketBase
- (instancetype)initWithHead:(ZmsKmmKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<ZmsKmmKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable("Will be removed in future releases.")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket")))
@interface ZmsKmmKtor_ioByteReadPacket : ZmsKmmKtor_ioByteReadPacketPlatformBase <ZmsKmmKtor_ioInput>
- (instancetype)initWithHead:(ZmsKmmKtor_ioChunkBuffer *)head pool:(id<ZmsKmmKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:pool:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithHead:(ZmsKmmKtor_ioChunkBuffer *)head remaining:(int64_t)remaining pool:(id<ZmsKmmKtor_ioObjectPool>)pool __attribute__((swift_name("init(head:remaining:pool:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKtor_ioByteReadPacketCompanion *companion __attribute__((swift_name("companion")));
- (void)closeSource __attribute__((swift_name("closeSource()")));
- (ZmsKmmKtor_ioByteReadPacket *)doCopy __attribute__((swift_name("doCopy()")));
- (ZmsKmmKtor_ioChunkBuffer * _Nullable)fill __attribute__((swift_name("fill()")));
- (int32_t)fillDestination:(ZmsKmmKtor_ioMemory *)destination offset:(int32_t)offset length:(int32_t)length __attribute__((swift_name("fill(destination:offset:length:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@end;

__attribute__((swift_name("Ktor_ioReadSession")))
@protocol ZmsKmmKtor_ioReadSession
@required
- (int32_t)discardN_:(int32_t)n __attribute__((swift_name("discard(n_:)")));
- (ZmsKmmKtor_ioIoBuffer * _Nullable)requestAtLeast:(int32_t)atLeast __attribute__((swift_name("request(atLeast:)")));
@property (readonly) int32_t availableForRead __attribute__((swift_name("availableForRead")));
@end;

__attribute__((swift_name("KotlinFunction")))
@protocol ZmsKmmKotlinFunction
@required
@end;

__attribute__((swift_name("KotlinSuspendFunction1")))
@protocol ZmsKmmKotlinSuspendFunction1 <ZmsKmmKotlinFunction>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteOrder")))
@interface ZmsKmmKtor_ioByteOrder : ZmsKmmKotlinEnum<ZmsKmmKtor_ioByteOrder *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKtor_ioByteOrderCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) ZmsKmmKtor_ioByteOrder *bigEndian __attribute__((swift_name("bigEndian")));
@property (class, readonly) ZmsKmmKtor_ioByteOrder *littleEndian __attribute__((swift_name("littleEndian")));
+ (ZmsKmmKotlinArray<ZmsKmmKtor_ioByteOrder *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsGMTDate.Companion")))
@interface ZmsKmmKtor_utilsGMTDateCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_utilsGMTDateCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_utilsGMTDate *START __attribute__((swift_name("START")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay")))
@interface ZmsKmmKtor_utilsWeekDay : ZmsKmmKotlinEnum<ZmsKmmKtor_utilsWeekDay *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKtor_utilsWeekDayCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) ZmsKmmKtor_utilsWeekDay *monday __attribute__((swift_name("monday")));
@property (class, readonly) ZmsKmmKtor_utilsWeekDay *tuesday __attribute__((swift_name("tuesday")));
@property (class, readonly) ZmsKmmKtor_utilsWeekDay *wednesday __attribute__((swift_name("wednesday")));
@property (class, readonly) ZmsKmmKtor_utilsWeekDay *thursday __attribute__((swift_name("thursday")));
@property (class, readonly) ZmsKmmKtor_utilsWeekDay *friday __attribute__((swift_name("friday")));
@property (class, readonly) ZmsKmmKtor_utilsWeekDay *saturday __attribute__((swift_name("saturday")));
@property (class, readonly) ZmsKmmKtor_utilsWeekDay *sunday __attribute__((swift_name("sunday")));
+ (ZmsKmmKotlinArray<ZmsKmmKtor_utilsWeekDay *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth")))
@interface ZmsKmmKtor_utilsMonth : ZmsKmmKotlinEnum<ZmsKmmKtor_utilsMonth *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKtor_utilsMonthCompanion *companion __attribute__((swift_name("companion")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *january __attribute__((swift_name("january")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *february __attribute__((swift_name("february")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *march __attribute__((swift_name("march")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *april __attribute__((swift_name("april")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *may __attribute__((swift_name("may")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *june __attribute__((swift_name("june")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *july __attribute__((swift_name("july")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *august __attribute__((swift_name("august")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *september __attribute__((swift_name("september")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *october __attribute__((swift_name("october")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *november __attribute__((swift_name("november")));
@property (class, readonly) ZmsKmmKtor_utilsMonth *december __attribute__((swift_name("december")));
+ (ZmsKmmKotlinArray<ZmsKmmKtor_utilsMonth *> *)values __attribute__((swift_name("values()")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpStatusCode.Companion")))
@interface ZmsKmmKtor_httpHttpStatusCodeCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_httpHttpStatusCodeCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmKtor_httpHttpStatusCode *)fromValueValue:(int32_t)value __attribute__((swift_name("fromValue(value:)")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *Accepted __attribute__((swift_name("Accepted")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *BadGateway __attribute__((swift_name("BadGateway")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *BadRequest __attribute__((swift_name("BadRequest")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *Conflict __attribute__((swift_name("Conflict")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *Continue __attribute__((swift_name("Continue")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *Created __attribute__((swift_name("Created")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *ExpectationFailed __attribute__((swift_name("ExpectationFailed")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *FailedDependency __attribute__((swift_name("FailedDependency")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *Forbidden __attribute__((swift_name("Forbidden")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *Found __attribute__((swift_name("Found")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *GatewayTimeout __attribute__((swift_name("GatewayTimeout")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *Gone __attribute__((swift_name("Gone")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *InsufficientStorage __attribute__((swift_name("InsufficientStorage")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *InternalServerError __attribute__((swift_name("InternalServerError")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *LengthRequired __attribute__((swift_name("LengthRequired")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *Locked __attribute__((swift_name("Locked")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *MethodNotAllowed __attribute__((swift_name("MethodNotAllowed")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *MovedPermanently __attribute__((swift_name("MovedPermanently")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *MultiStatus __attribute__((swift_name("MultiStatus")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *MultipleChoices __attribute__((swift_name("MultipleChoices")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *NoContent __attribute__((swift_name("NoContent")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *NonAuthoritativeInformation __attribute__((swift_name("NonAuthoritativeInformation")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *NotAcceptable __attribute__((swift_name("NotAcceptable")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *NotFound __attribute__((swift_name("NotFound")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *NotImplemented __attribute__((swift_name("NotImplemented")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *NotModified __attribute__((swift_name("NotModified")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *OK __attribute__((swift_name("OK")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *PartialContent __attribute__((swift_name("PartialContent")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *PayloadTooLarge __attribute__((swift_name("PayloadTooLarge")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *PaymentRequired __attribute__((swift_name("PaymentRequired")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *PermanentRedirect __attribute__((swift_name("PermanentRedirect")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *PreconditionFailed __attribute__((swift_name("PreconditionFailed")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *Processing __attribute__((swift_name("Processing")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *ProxyAuthenticationRequired __attribute__((swift_name("ProxyAuthenticationRequired")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *RequestHeaderFieldTooLarge __attribute__((swift_name("RequestHeaderFieldTooLarge")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *RequestTimeout __attribute__((swift_name("RequestTimeout")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *RequestURITooLong __attribute__((swift_name("RequestURITooLong")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *RequestedRangeNotSatisfiable __attribute__((swift_name("RequestedRangeNotSatisfiable")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *ResetContent __attribute__((swift_name("ResetContent")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *SeeOther __attribute__((swift_name("SeeOther")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *ServiceUnavailable __attribute__((swift_name("ServiceUnavailable")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *SwitchProxy __attribute__((swift_name("SwitchProxy")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *SwitchingProtocols __attribute__((swift_name("SwitchingProtocols")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *TemporaryRedirect __attribute__((swift_name("TemporaryRedirect")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *TooManyRequests __attribute__((swift_name("TooManyRequests")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *Unauthorized __attribute__((swift_name("Unauthorized")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *UnprocessableEntity __attribute__((swift_name("UnprocessableEntity")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *UnsupportedMediaType __attribute__((swift_name("UnsupportedMediaType")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *UpgradeRequired __attribute__((swift_name("UpgradeRequired")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *UseProxy __attribute__((swift_name("UseProxy")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *VariantAlsoNegotiates __attribute__((swift_name("VariantAlsoNegotiates")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *VersionNotSupported __attribute__((swift_name("VersionNotSupported")));
@property (readonly) NSArray<ZmsKmmKtor_httpHttpStatusCode *> *allStatusCodes __attribute__((swift_name("allStatusCodes")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHttpProtocolVersion.Companion")))
@interface ZmsKmmKtor_httpHttpProtocolVersionCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_httpHttpProtocolVersionCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmKtor_httpHttpProtocolVersion *)fromValueName:(NSString *)name major:(int32_t)major minor:(int32_t)minor __attribute__((swift_name("fromValue(name:major:minor:)")));
- (ZmsKmmKtor_httpHttpProtocolVersion *)parseValue:(id)value __attribute__((swift_name("parse(value:)")));
@property (readonly) ZmsKmmKtor_httpHttpProtocolVersion *HTTP_1_0 __attribute__((swift_name("HTTP_1_0")));
@property (readonly) ZmsKmmKtor_httpHttpProtocolVersion *HTTP_1_1 __attribute__((swift_name("HTTP_1_1")));
@property (readonly) ZmsKmmKtor_httpHttpProtocolVersion *HTTP_2_0 __attribute__((swift_name("HTTP_2_0")));
@property (readonly) ZmsKmmKtor_httpHttpProtocolVersion *QUIC __attribute__((swift_name("QUIC")));
@property (readonly) ZmsKmmKtor_httpHttpProtocolVersion *SPDY_3 __attribute__((swift_name("SPDY_3")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestData")))
@interface ZmsKmmKtor_client_coreHttpRequestData : ZmsKmmBase
- (instancetype)initWithUrl:(ZmsKmmKtor_httpUrl *)url method:(ZmsKmmKtor_httpHttpMethod *)method headers:(id<ZmsKmmKtor_httpHeaders>)headers body:(ZmsKmmKtor_httpOutgoingContent *)body executionContext:(id<ZmsKmmKotlinx_coroutines_coreJob>)executionContext attributes:(id<ZmsKmmKtor_utilsAttributes>)attributes __attribute__((swift_name("init(url:method:headers:body:executionContext:attributes:)"))) __attribute__((objc_designated_initializer));
- (id _Nullable)getCapabilityOrNullKey:(id<ZmsKmmKtor_client_coreHttpClientEngineCapability>)key __attribute__((swift_name("getCapabilityOrNull(key:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<ZmsKmmKtor_utilsAttributes> attributes __attribute__((swift_name("attributes")));
@property (readonly) ZmsKmmKtor_httpOutgoingContent *body __attribute__((swift_name("body")));
@property (readonly) id<ZmsKmmKotlinx_coroutines_coreJob> executionContext __attribute__((swift_name("executionContext")));
@property (readonly) id<ZmsKmmKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) ZmsKmmKtor_httpHttpMethod *method __attribute__((swift_name("method")));
@property (readonly) ZmsKmmKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseData")))
@interface ZmsKmmKtor_client_coreHttpResponseData : ZmsKmmBase
- (instancetype)initWithStatusCode:(ZmsKmmKtor_httpHttpStatusCode *)statusCode requestTime:(ZmsKmmKtor_utilsGMTDate *)requestTime headers:(id<ZmsKmmKtor_httpHeaders>)headers version:(ZmsKmmKtor_httpHttpProtocolVersion *)version body:(id)body callContext:(id<ZmsKmmKotlinCoroutineContext>)callContext __attribute__((swift_name("init(statusCode:requestTime:headers:version:body:callContext:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id body __attribute__((swift_name("body")));
@property (readonly) id<ZmsKmmKotlinCoroutineContext> callContext __attribute__((swift_name("callContext")));
@property (readonly) id<ZmsKmmKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) ZmsKmmKtor_utilsGMTDate *requestTime __attribute__((swift_name("requestTime")));
@property (readonly) ZmsKmmKtor_utilsGMTDate *responseTime __attribute__((swift_name("responseTime")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode *statusCode __attribute__((swift_name("statusCode")));
@property (readonly) ZmsKmmKtor_httpHttpProtocolVersion *version __attribute__((swift_name("version")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreProxyConfig")))
@interface ZmsKmmKtor_client_coreProxyConfig : ZmsKmmBase
- (instancetype)initWithUrl:(ZmsKmmKtor_httpUrl *)url __attribute__((swift_name("init(url:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmKtor_httpUrl *url __attribute__((swift_name("url")));
@end;

__attribute__((swift_name("Ktor_client_coreHttpClientFeature")))
@protocol ZmsKmmKtor_client_coreHttpClientFeature
@required
- (void)installFeature:(id)feature scope:(ZmsKmmKtor_client_coreHttpClient *)scope __attribute__((swift_name("install(feature:scope:)")));
- (id)prepareBlock:(void (^)(id))block __attribute__((swift_name("prepare(block:)")));
@property (readonly) ZmsKmmKtor_utilsAttributeKey<id> *key __attribute__((swift_name("key")));
@end;

__attribute__((swift_name("Ktor_utilsStringValuesBuilder")))
@interface ZmsKmmKtor_utilsStringValuesBuilder : ZmsKmmBase
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer));
- (void)appendName:(NSString *)name value:(NSString *)value __attribute__((swift_name("append(name:value:)")));
- (void)appendAllStringValues:(id<ZmsKmmKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendAll(stringValues:)")));
- (void)appendAllName:(NSString *)name values:(id)values __attribute__((swift_name("appendAll(name:values:)")));
- (void)appendMissingStringValues:(id<ZmsKmmKtor_utilsStringValues>)stringValues __attribute__((swift_name("appendMissing(stringValues:)")));
- (void)appendMissingName:(NSString *)name values:(id)values __attribute__((swift_name("appendMissing(name:values:)")));
- (id<ZmsKmmKtor_utilsStringValues>)build __attribute__((swift_name("build()")));
- (void)clear __attribute__((swift_name("clear()")));
- (BOOL)containsName:(NSString *)name __attribute__((swift_name("contains(name:)")));
- (BOOL)containsName:(NSString *)name value:(NSString *)value __attribute__((swift_name("contains(name:value:)")));
- (NSSet<id<ZmsKmmKotlinMapEntry>> *)entries __attribute__((swift_name("entries()")));
- (NSString * _Nullable)getName:(NSString *)name __attribute__((swift_name("get(name:)")));
- (NSArray<NSString *> * _Nullable)getAllName:(NSString *)name __attribute__((swift_name("getAll(name:)")));
- (BOOL)isEmpty __attribute__((swift_name("isEmpty()")));
- (NSSet<NSString *> *)names __attribute__((swift_name("names()")));
- (void)removeName:(NSString *)name __attribute__((swift_name("remove(name:)")));
- (BOOL)removeName:(NSString *)name value:(NSString *)value __attribute__((swift_name("remove(name:value:)")));
- (void)removeKeysWithNoEntries __attribute__((swift_name("removeKeysWithNoEntries()")));
- (void)setName:(NSString *)name value:(NSString *)value __attribute__((swift_name("set(name:value:)")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@property BOOL built __attribute__((swift_name("built")));
@property (readonly) BOOL caseInsensitiveName __attribute__((swift_name("caseInsensitiveName")));
@property (readonly) ZmsKmmMutableDictionary<NSString *, NSMutableArray<NSString *> *> *values __attribute__((swift_name("values")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeadersBuilder")))
@interface ZmsKmmKtor_httpHeadersBuilder : ZmsKmmKtor_utilsStringValuesBuilder
- (instancetype)initWithSize:(int32_t)size __attribute__((swift_name("init(size:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<ZmsKmmKtor_httpHeaders>)build __attribute__((swift_name("build()")));
- (void)validateNameName:(NSString *)name __attribute__((swift_name("validateName(name:)")));
- (void)validateValueValue:(NSString *)value __attribute__((swift_name("validateValue(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestBuilder.Companion")))
@interface ZmsKmmKtor_client_coreHttpRequestBuilderCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_client_coreHttpRequestBuilderCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder")))
@interface ZmsKmmKtor_httpURLBuilder : ZmsKmmBase
- (instancetype)initWithProtocol:(ZmsKmmKtor_httpURLProtocol *)protocol host:(NSString *)host port:(int32_t)port user:(NSString * _Nullable)user password:(NSString * _Nullable)password encodedPath:(NSString *)encodedPath parameters:(ZmsKmmKtor_httpParametersBuilder *)parameters fragment:(NSString *)fragment trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:port:user:password:encodedPath:parameters:fragment:trailingQuery:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKtor_httpURLBuilderCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmKtor_httpUrl *)build __attribute__((swift_name("build()")));
- (NSString *)buildString __attribute__((swift_name("buildString()")));
- (ZmsKmmKtor_httpURLBuilder *)pathComponents:(ZmsKmmKotlinArray<NSString *> *)components __attribute__((swift_name("path(components:)")));
- (ZmsKmmKtor_httpURLBuilder *)pathComponents_:(NSArray<NSString *> *)components __attribute__((swift_name("path(components_:)")));
@property NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property NSString *fragment __attribute__((swift_name("fragment")));
@property NSString *host __attribute__((swift_name("host")));
@property (readonly) ZmsKmmKtor_httpParametersBuilder *parameters __attribute__((swift_name("parameters")));
@property NSString * _Nullable password __attribute__((swift_name("password")));
@property int32_t port __attribute__((swift_name("port")));
@property ZmsKmmKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreJob")))
@protocol ZmsKmmKotlinx_coroutines_coreJob <ZmsKmmKotlinCoroutineContextElement>
@required
- (id<ZmsKmmKotlinx_coroutines_coreChildHandle>)attachChildChild:(id<ZmsKmmKotlinx_coroutines_coreChildJob>)child __attribute__((swift_name("attachChild(child:)")));
- (void)cancelCause_:(ZmsKmmKotlinCancellationException * _Nullable)cause __attribute__((swift_name("cancel(cause_:)")));
- (ZmsKmmKotlinCancellationException *)getCancellationException __attribute__((swift_name("getCancellationException()")));
- (id<ZmsKmmKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionOnCancelling:(BOOL)onCancelling invokeImmediately:(BOOL)invokeImmediately handler:(void (^)(ZmsKmmKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(onCancelling:invokeImmediately:handler:)")));
- (id<ZmsKmmKotlinx_coroutines_coreDisposableHandle>)invokeOnCompletionHandler:(void (^)(ZmsKmmKotlinThrowable * _Nullable))handler __attribute__((swift_name("invokeOnCompletion(handler:)")));

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)joinWithCompletionHandler:(void (^)(ZmsKmmKotlinUnit * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("join(completionHandler:)")));
- (id<ZmsKmmKotlinx_coroutines_coreJob>)plusOther_:(id<ZmsKmmKotlinx_coroutines_coreJob>)other __attribute__((swift_name("plus(other_:)"))) __attribute__((unavailable("Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")));
- (BOOL)start __attribute__((swift_name("start()")));
@property (readonly) id<ZmsKmmKotlinSequence> children __attribute__((swift_name("children")));
@property (readonly) BOOL isActive __attribute__((swift_name("isActive")));
@property (readonly) BOOL isCancelled __attribute__((swift_name("isCancelled")));
@property (readonly) BOOL isCompleted __attribute__((swift_name("isCompleted")));
@property (readonly) id<ZmsKmmKotlinx_coroutines_coreSelectClause0> onJoin __attribute__((swift_name("onJoin")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsAttributeKey")))
@interface ZmsKmmKtor_utilsAttributeKey<T> : ZmsKmmBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("KotlinContinuation")))
@protocol ZmsKmmKotlinContinuation
@required
- (void)resumeWithResult:(id _Nullable)result __attribute__((swift_name("resumeWith(result:)")));
@property (readonly) id<ZmsKmmKotlinCoroutineContext> context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("KotlinAbstractCoroutineContextKey")))
@interface ZmsKmmKotlinAbstractCoroutineContextKey<B, E> : ZmsKmmBase <ZmsKmmKotlinCoroutineContextKey>
- (instancetype)initWithBaseKey:(id<ZmsKmmKotlinCoroutineContextKey>)baseKey safeCast:(E _Nullable (^)(id<ZmsKmmKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreCoroutineDispatcher.Key")))
@interface ZmsKmmKotlinx_coroutines_coreCoroutineDispatcherKey : ZmsKmmKotlinAbstractCoroutineContextKey<id<ZmsKmmKotlinContinuationInterceptor>, ZmsKmmKotlinx_coroutines_coreCoroutineDispatcher *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithBaseKey:(id<ZmsKmmKotlinCoroutineContextKey>)baseKey safeCast:(id<ZmsKmmKotlinCoroutineContextElement> _Nullable (^)(id<ZmsKmmKotlinCoroutineContextElement>))safeCast __attribute__((swift_name("init(baseKey:safeCast:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)key __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKotlinx_coroutines_coreCoroutineDispatcherKey *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreRunnable")))
@protocol ZmsKmmKotlinx_coroutines_coreRunnable
@required
- (void)run __attribute__((swift_name("run()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsPipelinePhase")))
@interface ZmsKmmKtor_utilsPipelinePhase : ZmsKmmBase
- (instancetype)initWithName:(NSString *)name __attribute__((swift_name("init(name:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((swift_name("KotlinSuspendFunction2")))
@protocol ZmsKmmKotlinSuspendFunction2 <ZmsKmmKotlinFunction>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeP1:(id _Nullable)p1 p2:(id _Nullable)p2 completionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(p1:p2:completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpReceivePipeline.Phases")))
@interface ZmsKmmKtor_client_coreHttpReceivePipelinePhases : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_client_coreHttpReceivePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpRequestPipeline.Phases")))
@interface ZmsKmmKtor_client_coreHttpRequestPipelinePhases : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_client_coreHttpRequestPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Render __attribute__((swift_name("Render")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Send __attribute__((swift_name("Send")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponsePipeline.Phases")))
@interface ZmsKmmKtor_client_coreHttpResponsePipelinePhases : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_client_coreHttpResponsePipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *After __attribute__((swift_name("After")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Parse __attribute__((swift_name("Parse")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Transform __attribute__((swift_name("Transform")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpResponseContainer")))
@interface ZmsKmmKtor_client_coreHttpResponseContainer : ZmsKmmBase
- (instancetype)initWithExpectedType:(id<ZmsKmmKtor_utilsTypeInfo>)expectedType response:(id)response __attribute__((swift_name("init(expectedType:response:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithExpectedType:(ZmsKmmKtor_client_coreTypeInfo *)expectedType response_:(id)response __attribute__((swift_name("init(expectedType:response_:)"))) __attribute__((objc_designated_initializer));
- (ZmsKmmKtor_client_coreTypeInfo *)component1 __attribute__((swift_name("component1()")));
- (id)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmKtor_client_coreHttpResponseContainer *)doCopyExpectedType:(ZmsKmmKtor_client_coreTypeInfo *)expectedType response:(id)response __attribute__((swift_name("doCopy(expectedType:response:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmKtor_client_coreTypeInfo *expectedType __attribute__((swift_name("expectedType")));
@property (readonly) id response __attribute__((swift_name("response")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_client_coreHttpSendPipeline.Phases")))
@interface ZmsKmmKtor_client_coreHttpSendPipelinePhases : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)phases __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_client_coreHttpSendPipelinePhases *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Before __attribute__((swift_name("Before")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Engine __attribute__((swift_name("Engine")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Monitoring __attribute__((swift_name("Monitoring")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *Receive __attribute__((swift_name("Receive")));
@property (readonly) ZmsKmmKtor_utilsPipelinePhase *State __attribute__((swift_name("State")));
@end;

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol ZmsKmmKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<ZmsKmmKotlinKClass>)kClass provider:(id<ZmsKmmKotlinx_serialization_coreKSerializer> (^)(NSArray<id<ZmsKmmKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<ZmsKmmKotlinKClass>)kClass serializer:(id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<ZmsKmmKotlinKClass>)baseClass actualClass:(id<ZmsKmmKotlinKClass>)actualClass actualSerializer:(id<ZmsKmmKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<ZmsKmmKotlinKClass>)baseClass defaultSerializerProvider:(id<ZmsKmmKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultSerializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultSerializerProvider:)")));
@end;

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol ZmsKmmKotlinKDeclarationContainer
@required
@end;

__attribute__((swift_name("KotlinKClassifier")))
@protocol ZmsKmmKotlinKClassifier
@required
@end;

__attribute__((swift_name("KotlinKClass")))
@protocol ZmsKmmKotlinKClass <ZmsKmmKotlinKDeclarationContainer, ZmsKmmKotlinKAnnotatedElement, ZmsKmmKotlinKClassifier>
@required
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface ZmsKmmKotlinx_serialization_jsonJsonElementCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<ZmsKmmKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end;

__attribute__((swift_name("Kodein_diDIBuilderDirectBinder")))
@protocol ZmsKmmKodein_diDIBuilderDirectBinder
@required
- (void)fromBinding:(id<ZmsKmmKodein_diDIBinding>)binding __attribute__((swift_name("from(binding:)"))) __attribute__((deprecated("'bind() fron [BINDING]' might be replace by 'bind { [BINDING] }' (This will be remove in Kodein-DI 8.0)")));
@end;

__attribute__((swift_name("Kodein_diBinding")))
@protocol ZmsKmmKodein_diBinding
@required
- (id (^)(id _Nullable))getFactoryKey:(ZmsKmmKodein_diDIKey<id, id, id> *)key di:(id<ZmsKmmKodein_diBindingDI>)di __attribute__((swift_name("getFactory(key:di:)")));
@end;

__attribute__((swift_name("Kodein_diDIBinding")))
@protocol ZmsKmmKodein_diDIBinding <ZmsKmmKodein_diBinding>
@required
- (NSString *)factoryFullName __attribute__((swift_name("factoryFullName()")));
- (NSString *)factoryName __attribute__((swift_name("factoryName()")));
@property (readonly) id<ZmsKmmKodein_typeTypeToken> argType __attribute__((swift_name("argType")));
@property (readonly) id<ZmsKmmKodein_typeTypeToken> contextType __attribute__((swift_name("contextType")));
@property (readonly) id<ZmsKmmKodein_diDIBindingCopier> _Nullable copier __attribute__((swift_name("copier")));
@property (readonly) id<ZmsKmmKodein_typeTypeToken> createdType __attribute__((swift_name("createdType")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) NSString *fullDescription __attribute__((swift_name("fullDescription")));
@property (readonly) id<ZmsKmmKodein_diScope> _Nullable scope __attribute__((swift_name("scope")));
@property (readonly) BOOL supportSubTypes __attribute__((swift_name("supportSubTypes")));
@end;

__attribute__((swift_name("Kodein_diDIBuilderTypeBinder")))
@protocol ZmsKmmKodein_diDIBuilderTypeBinder
@required
- (void)withBinding:(id<ZmsKmmKodein_diDIBinding>)binding __attribute__((swift_name("with(binding:)")));
@end;

__attribute__((swift_name("Kodein_typeTypeToken")))
@protocol ZmsKmmKodein_typeTypeToken
@required
- (ZmsKmmKotlinArray<id<ZmsKmmKodein_typeTypeToken>> *)getGenericParameters __attribute__((swift_name("getGenericParameters()")));
- (id<ZmsKmmKodein_typeTypeToken>)getRaw __attribute__((swift_name("getRaw()")));
- (NSArray<id<ZmsKmmKodein_typeTypeToken>> *)getSuper __attribute__((swift_name("getSuper()")));
- (BOOL)isAssignableFromTypeToken:(id<ZmsKmmKodein_typeTypeToken>)typeToken __attribute__((swift_name("isAssignableFrom(typeToken:)")));
- (BOOL)isGeneric __attribute__((swift_name("isGeneric()")));
- (BOOL)isWildcard __attribute__((swift_name("isWildcard()")));
- (NSString *)qualifiedDispString __attribute__((swift_name("qualifiedDispString()")));
- (NSString *)qualifiedErasedDispString __attribute__((swift_name("qualifiedErasedDispString()")));
- (NSString *)simpleDispString __attribute__((swift_name("simpleDispString()")));
- (NSString *)simpleErasedDispString __attribute__((swift_name("simpleErasedDispString()")));
@end;

__attribute__((swift_name("Kodein_diContextTranslator")))
@protocol ZmsKmmKodein_diContextTranslator
@required
- (id _Nullable)translateDi:(id<ZmsKmmKodein_diDirectDI>)di ctx:(id)ctx __attribute__((swift_name("translate(di:ctx:)")));
@property (readonly) id<ZmsKmmKodein_typeTypeToken> contextType __attribute__((swift_name("contextType")));
@property (readonly) id<ZmsKmmKodein_typeTypeToken> scopeType __attribute__((swift_name("scopeType")));
@end;

__attribute__((swift_name("Kodein_diDIBuilderConstantBinder")))
@protocol ZmsKmmKodein_diDIBuilderConstantBinder
@required
- (void)WithValueType:(id<ZmsKmmKodein_typeTypeToken>)valueType value:(id)value __attribute__((swift_name("With(valueType:value:)")));
@end;

__attribute__((swift_name("Kodein_diDirectDIAware")))
@protocol ZmsKmmKodein_diDirectDIAware
@required
@property (readonly) id<ZmsKmmKodein_diDirectDI> directDI __attribute__((swift_name("directDI")));
@end;

__attribute__((swift_name("Kodein_diDirectDIBase")))
@protocol ZmsKmmKodein_diDirectDIBase <ZmsKmmKodein_diDirectDIAware>
@required
- (id (^)(id _Nullable))FactoryArgType:(id<ZmsKmmKodein_typeTypeToken>)argType type:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag __attribute__((swift_name("Factory(argType:type:tag:)")));
- (id (^ _Nullable)(id _Nullable))FactoryOrNullArgType:(id<ZmsKmmKodein_typeTypeToken>)argType type:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag __attribute__((swift_name("FactoryOrNull(argType:type:tag:)")));
- (id)InstanceType:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag __attribute__((swift_name("Instance(type:tag:)")));
- (id)InstanceArgType:(id<ZmsKmmKodein_typeTypeToken>)argType type:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag arg:(id _Nullable)arg __attribute__((swift_name("Instance(argType:type:tag:arg:)")));
- (id _Nullable)InstanceOrNullType:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag __attribute__((swift_name("InstanceOrNull(type:tag:)")));
- (id _Nullable)InstanceOrNullArgType:(id<ZmsKmmKodein_typeTypeToken>)argType type:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag arg:(id _Nullable)arg __attribute__((swift_name("InstanceOrNull(argType:type:tag:arg:)")));
- (id<ZmsKmmKodein_diDirectDI>)OnContext:(id<ZmsKmmKodein_diDIContext>)context __attribute__((swift_name("On(context:)")));
- (id (^)(void))ProviderType:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag __attribute__((swift_name("Provider(type:tag:)")));
- (id (^)(void))ProviderArgType:(id<ZmsKmmKodein_typeTypeToken>)argType type:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag arg:(id _Nullable (^)(void))arg __attribute__((swift_name("Provider(argType:type:tag:arg:)")));
- (id (^ _Nullable)(void))ProviderOrNullType:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag __attribute__((swift_name("ProviderOrNull(type:tag:)")));
- (id (^ _Nullable)(void))ProviderOrNullArgType:(id<ZmsKmmKodein_typeTypeToken>)argType type:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag arg:(id _Nullable (^)(void))arg __attribute__((swift_name("ProviderOrNull(argType:type:tag:arg:)")));
@property (readonly) id<ZmsKmmKodein_diDIContainer> container __attribute__((swift_name("container")));
@property (readonly) id<ZmsKmmKodein_diDI> di __attribute__((swift_name("di")));
@property (readonly) id<ZmsKmmKodein_diDI> lazy __attribute__((swift_name("lazy")));
@end;

__attribute__((swift_name("Kodein_diDirectDI")))
@protocol ZmsKmmKodein_diDirectDI <ZmsKmmKodein_diDirectDIBase>
@required
@end;

__attribute__((swift_name("Kodein_diDIContainerBuilder")))
@protocol ZmsKmmKodein_diDIContainerBuilder
@required
- (void)bindKey:(ZmsKmmKodein_diDIKey<id, id, id> *)key binding:(id<ZmsKmmKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule overrides:(ZmsKmmBoolean * _Nullable)overrides __attribute__((swift_name("bind(key:binding:fromModule:overrides:)")));
- (void)extendContainer:(id<ZmsKmmKodein_diDIContainer>)container allowOverride:(BOOL)allowOverride copy:(NSSet<ZmsKmmKodein_diDIKey<id, id, id> *> *)copy __attribute__((swift_name("extend(container:allowOverride:copy:)")));
- (void)onReadyCb:(void (^)(id<ZmsKmmKodein_diDirectDI>))cb __attribute__((swift_name("onReady(cb:)")));
- (void)registerContextTranslatorTranslator:(id<ZmsKmmKodein_diContextTranslator>)translator __attribute__((swift_name("registerContextTranslator(translator:)")));
- (id<ZmsKmmKodein_diDIContainerBuilder>)subBuilderAllowOverride:(BOOL)allowOverride silentOverride:(BOOL)silentOverride __attribute__((swift_name("subBuilder(allowOverride:silentOverride:)")));
@end;

__attribute__((swift_name("Kodein_diScope")))
@protocol ZmsKmmKodein_diScope
@required
- (ZmsKmmKodein_diScopeRegistry *)getRegistryContext:(id _Nullable)context __attribute__((swift_name("getRegistry(context:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDIKey")))
@interface ZmsKmmKodein_diDIKey<__contravariant C, __contravariant A, __covariant T> : ZmsKmmBase
- (instancetype)initWithContextType:(id<ZmsKmmKodein_typeTypeToken>)contextType argType:(id<ZmsKmmKodein_typeTypeToken>)argType type:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag __attribute__((swift_name("init(contextType:argType:type:tag:)"))) __attribute__((objc_designated_initializer));
- (id<ZmsKmmKodein_typeTypeToken>)component1 __attribute__((swift_name("component1()")));
- (id<ZmsKmmKodein_typeTypeToken>)component2 __attribute__((swift_name("component2()")));
- (id<ZmsKmmKodein_typeTypeToken>)component3 __attribute__((swift_name("component3()")));
- (id _Nullable)component4 __attribute__((swift_name("component4()")));
- (ZmsKmmKodein_diDIKey<C, A, T> *)doCopyContextType:(id<ZmsKmmKodein_typeTypeToken>)contextType argType:(id<ZmsKmmKodein_typeTypeToken>)argType type:(id<ZmsKmmKodein_typeTypeToken>)type tag:(id _Nullable)tag __attribute__((swift_name("doCopy(contextType:argType:type:tag:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<ZmsKmmKodein_typeTypeToken> argType __attribute__((swift_name("argType")));
@property (readonly) NSString *bindDescription __attribute__((swift_name("bindDescription")));
@property (readonly) NSString *bindFullDescription __attribute__((swift_name("bindFullDescription")));
@property (readonly) id<ZmsKmmKodein_typeTypeToken> contextType __attribute__((swift_name("contextType")));
@property (readonly) NSString *description_ __attribute__((swift_name("description_")));
@property (readonly) NSString *fullDescription __attribute__((swift_name("fullDescription")));
@property (readonly) NSString *internalDescription __attribute__((swift_name("internalDescription")));
@property (readonly) id _Nullable tag __attribute__((swift_name("tag")));
@property (readonly) id<ZmsKmmKodein_typeTypeToken> type __attribute__((swift_name("type")));
@end;

__attribute__((swift_name("Kodein_diDITree")))
@protocol ZmsKmmKodein_diDITree
@required
- (NSArray<ZmsKmmKotlinTriple<ZmsKmmKodein_diDIKey<id, id, id> *, ZmsKmmKodein_diDIDefinition<id, id, id> *, id<ZmsKmmKodein_diContextTranslator>> *> *)findKey:(ZmsKmmKodein_diDIKey<id, id, id> *)key overrideLevel:(int32_t)overrideLevel all:(BOOL)all __attribute__((swift_name("find(key:overrideLevel:all:)")));
- (NSArray<ZmsKmmKotlinTriple<ZmsKmmKodein_diDIKey<id, id, id> *, NSArray<ZmsKmmKodein_diDIDefinition<id, id, id> *> *, id<ZmsKmmKodein_diContextTranslator>> *> *)findSearch:(ZmsKmmKodein_diSearchSpecs *)search __attribute__((swift_name("find(search:)")));
- (ZmsKmmKotlinTriple<ZmsKmmKodein_diDIKey<id, id, id> *, NSArray<ZmsKmmKodein_diDIDefinition<id, id, id> *> *, id<ZmsKmmKodein_diContextTranslator>> * _Nullable)getKey__:(ZmsKmmKodein_diDIKey<id, id, id> *)key __attribute__((swift_name("get(key__:)")));
@property (readonly) NSDictionary<ZmsKmmKodein_diDIKey<id, id, id> *, NSArray<ZmsKmmKodein_diDIDefinition<id, id, id> *> *> *bindings __attribute__((swift_name("bindings")));
@property (readonly) NSArray<id<ZmsKmmKodein_diExternalSource>> *externalSources __attribute__((swift_name("externalSources")));
@property (readonly) NSArray<id<ZmsKmmKodein_diContextTranslator>> *registeredTranslators __attribute__((swift_name("registeredTranslators")));
@end;

__attribute__((swift_name("KotlinLazy")))
@protocol ZmsKmmKotlinLazy
@required
- (BOOL)isInitialized __attribute__((swift_name("isInitialized()")));
@property (readonly) id _Nullable value_ __attribute__((swift_name("value_")));
@end;

__attribute__((swift_name("KotlinKType")))
@protocol ZmsKmmKotlinKType
@required
@property (readonly) NSArray<ZmsKmmKotlinKTypeProjection *> *arguments __attribute__((swift_name("arguments")));
@property (readonly) id<ZmsKmmKotlinKClassifier> _Nullable classifier __attribute__((swift_name("classifier")));
@property (readonly) BOOL isMarkedNullable __attribute__((swift_name("isMarkedNullable")));
@end;

__attribute__((swift_name("Ktor_httpOutgoingContent")))
@interface ZmsKmmKtor_httpOutgoingContent : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id _Nullable)getPropertyKey:(ZmsKmmKtor_utilsAttributeKey<id> *)key __attribute__((swift_name("getProperty(key:)")));
- (void)setPropertyKey:(ZmsKmmKtor_utilsAttributeKey<id> *)key value:(id _Nullable)value __attribute__((swift_name("setProperty(key:value:)")));
@property (readonly) ZmsKmmLong * _Nullable contentLength __attribute__((swift_name("contentLength")));
@property (readonly) ZmsKmmKtor_httpContentType * _Nullable contentType __attribute__((swift_name("contentType")));
@property (readonly) id<ZmsKmmKtor_httpHeaders> headers __attribute__((swift_name("headers")));
@property (readonly) ZmsKmmKtor_httpHttpStatusCode * _Nullable status __attribute__((swift_name("status")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl")))
@interface ZmsKmmKtor_httpUrl : ZmsKmmBase
- (instancetype)initWithProtocol:(ZmsKmmKtor_httpURLProtocol *)protocol host:(NSString *)host specifiedPort:(int32_t)specifiedPort encodedPath:(NSString *)encodedPath parameters:(id<ZmsKmmKtor_httpParameters>)parameters fragment:(NSString *)fragment user:(NSString * _Nullable)user password:(NSString * _Nullable)password trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("init(protocol:host:specifiedPort:encodedPath:parameters:fragment:user:password:trailingQuery:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKtor_httpUrlCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmKtor_httpURLProtocol *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (int32_t)component3 __attribute__((swift_name("component3()")));
- (NSString *)component4 __attribute__((swift_name("component4()")));
- (id<ZmsKmmKtor_httpParameters>)component5 __attribute__((swift_name("component5()")));
- (NSString *)component6 __attribute__((swift_name("component6()")));
- (NSString * _Nullable)component7 __attribute__((swift_name("component7()")));
- (NSString * _Nullable)component8 __attribute__((swift_name("component8()")));
- (BOOL)component9 __attribute__((swift_name("component9()")));
- (ZmsKmmKtor_httpUrl *)doCopyProtocol:(ZmsKmmKtor_httpURLProtocol *)protocol host:(NSString *)host specifiedPort:(int32_t)specifiedPort encodedPath:(NSString *)encodedPath parameters:(id<ZmsKmmKtor_httpParameters>)parameters fragment:(NSString *)fragment user:(NSString * _Nullable)user password:(NSString * _Nullable)password trailingQuery:(BOOL)trailingQuery __attribute__((swift_name("doCopy(protocol:host:specifiedPort:encodedPath:parameters:fragment:user:password:trailingQuery:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *encodedPath __attribute__((swift_name("encodedPath")));
@property (readonly) NSString *fragment __attribute__((swift_name("fragment")));
@property (readonly) NSString *host __attribute__((swift_name("host")));
@property (readonly) id<ZmsKmmKtor_httpParameters> parameters __attribute__((swift_name("parameters")));
@property (readonly) NSString * _Nullable password __attribute__((swift_name("password")));
@property (readonly) int32_t port __attribute__((swift_name("port")));
@property (readonly) ZmsKmmKtor_httpURLProtocol *protocol __attribute__((swift_name("protocol")));
@property (readonly) int32_t specifiedPort __attribute__((swift_name("specifiedPort")));
@property (readonly) BOOL trailingQuery __attribute__((swift_name("trailingQuery")));
@property (readonly) NSString * _Nullable user __attribute__((swift_name("user")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioMemory.Companion")))
@interface ZmsKmmKtor_ioMemoryCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_ioMemoryCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_ioMemory *Empty __attribute__((swift_name("Empty")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioBuffer.Companion")))
@interface ZmsKmmKtor_ioBufferCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_ioBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_ioBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) int32_t ReservedSize __attribute__((swift_name("ReservedSize")));
@end;

__attribute__((swift_name("Ktor_ioObjectPool")))
@protocol ZmsKmmKtor_ioObjectPool <ZmsKmmKtor_ioCloseable>
@required
- (id)borrow __attribute__((swift_name("borrow()")));
- (void)dispose __attribute__((swift_name("dispose()")));
- (void)recycleInstance:(id)instance __attribute__((swift_name("recycle(instance:)")));
@property (readonly) int32_t capacity __attribute__((swift_name("capacity")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioChunkBuffer.Companion")))
@interface ZmsKmmKtor_ioChunkBufferCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_ioChunkBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_ioChunkBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) id<ZmsKmmKtor_ioObjectPool> EmptyPool __attribute__((swift_name("EmptyPool")));
@property (readonly) id<ZmsKmmKtor_ioObjectPool> Pool __attribute__((swift_name("Pool")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinCharArray")))
@interface ZmsKmmKotlinCharArray : ZmsKmmBase
+ (instancetype)arrayWithSize:(int32_t)size __attribute__((swift_name("init(size:)")));
+ (instancetype)arrayWithSize:(int32_t)size init:(id (^)(ZmsKmmInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (unichar)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (ZmsKmmKotlinCharIterator *)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(unichar)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioIoBuffer.Companion")))
@interface ZmsKmmKtor_ioIoBufferCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_ioIoBufferCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_ioIoBuffer *Empty __attribute__((swift_name("Empty")));
@property (readonly) id<ZmsKmmKtor_ioObjectPool> EmptyPool __attribute__((swift_name("EmptyPool")));
@property (readonly) id<ZmsKmmKtor_ioObjectPool> NoPool __attribute__((swift_name("NoPool")));
@property (readonly) id<ZmsKmmKtor_ioObjectPool> Pool __attribute__((swift_name("Pool")));
@property (readonly) int32_t ReservedSize __attribute__((swift_name("ReservedSize")));
@end;

__attribute__((swift_name("KotlinByteIterator")))
@interface ZmsKmmKotlinByteIterator : ZmsKmmBase <ZmsKmmKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (ZmsKmmByte *)next __attribute__((swift_name("next()")));
- (int8_t)nextByte __attribute__((swift_name("nextByte()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioAbstractInput.Companion")))
@interface ZmsKmmKtor_ioAbstractInputCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_ioAbstractInputCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacketBase.Companion")))
@interface ZmsKmmKtor_ioByteReadPacketBaseCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_ioByteReadPacketBaseCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_ioByteReadPacket *Empty __attribute__((swift_name("Empty"))) __attribute__((unavailable("Use ByteReadPacket.Empty instead")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteReadPacket.Companion")))
@interface ZmsKmmKtor_ioByteReadPacketCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_ioByteReadPacketCompanion *shared __attribute__((swift_name("shared")));
@property (readonly) ZmsKmmKtor_ioByteReadPacket *Empty __attribute__((swift_name("Empty")));
@property (readonly) int32_t ReservedSize __attribute__((swift_name("ReservedSize")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_ioByteOrder.Companion")))
@interface ZmsKmmKtor_ioByteOrderCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_ioByteOrderCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmKtor_ioByteOrder *)nativeOrder __attribute__((swift_name("nativeOrder()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsWeekDay.Companion")))
@interface ZmsKmmKtor_utilsWeekDayCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_utilsWeekDayCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmKtor_utilsWeekDay *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (ZmsKmmKtor_utilsWeekDay *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_utilsMonth.Companion")))
@interface ZmsKmmKtor_utilsMonthCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_utilsMonthCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmKtor_utilsMonth *)fromOrdinal:(int32_t)ordinal __attribute__((swift_name("from(ordinal:)")));
- (ZmsKmmKtor_utilsMonth *)fromValue:(NSString *)value __attribute__((swift_name("from(value:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol")))
@interface ZmsKmmKtor_httpURLProtocol : ZmsKmmBase
- (instancetype)initWithName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("init(name:defaultPort:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKtor_httpURLProtocolCompanion *companion __attribute__((swift_name("companion")));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (int32_t)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmKtor_httpURLProtocol *)doCopyName:(NSString *)name defaultPort:(int32_t)defaultPort __attribute__((swift_name("doCopy(name:defaultPort:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t defaultPort __attribute__((swift_name("defaultPort")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpParametersBuilder")))
@interface ZmsKmmKtor_httpParametersBuilder : ZmsKmmKtor_utilsStringValuesBuilder
- (instancetype)initWithSize:(int32_t)size urlEncodingOption:(ZmsKmmKtor_httpUrlEncodingOption *)urlEncodingOption __attribute__((swift_name("init(size:urlEncodingOption:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCaseInsensitiveName:(BOOL)caseInsensitiveName size:(int32_t)size __attribute__((swift_name("init(caseInsensitiveName:size:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
- (id<ZmsKmmKtor_httpParameters>)build __attribute__((swift_name("build()")));
@property ZmsKmmKtor_httpUrlEncodingOption *urlEncodingOption __attribute__((swift_name("urlEncodingOption")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLBuilder.Companion")))
@interface ZmsKmmKtor_httpURLBuilderCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_httpURLBuilderCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreDisposableHandle")))
@protocol ZmsKmmKotlinx_coroutines_coreDisposableHandle
@required
- (void)dispose __attribute__((swift_name("dispose()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildHandle")))
@protocol ZmsKmmKotlinx_coroutines_coreChildHandle <ZmsKmmKotlinx_coroutines_coreDisposableHandle>
@required
- (BOOL)childCancelledCause:(ZmsKmmKotlinThrowable *)cause __attribute__((swift_name("childCancelled(cause:)")));
@property (readonly) id<ZmsKmmKotlinx_coroutines_coreJob> _Nullable parent __attribute__((swift_name("parent")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreChildJob")))
@protocol ZmsKmmKotlinx_coroutines_coreChildJob <ZmsKmmKotlinx_coroutines_coreJob>
@required
- (void)parentCancelledParentJob:(id<ZmsKmmKotlinx_coroutines_coreParentJob>)parentJob __attribute__((swift_name("parentCancelled(parentJob:)")));
@end;

__attribute__((swift_name("KotlinSequence")))
@protocol ZmsKmmKotlinSequence
@required
- (id<ZmsKmmKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectClause0")))
@protocol ZmsKmmKotlinx_coroutines_coreSelectClause0
@required
- (void)registerSelectClause0Select:(id<ZmsKmmKotlinx_coroutines_coreSelectInstance>)select block:(id<ZmsKmmKotlinSuspendFunction0>)block __attribute__((swift_name("registerSelectClause0(select:block:)")));
@end;

__attribute__((swift_name("Kodein_diDIBindingCopier")))
@protocol ZmsKmmKodein_diDIBindingCopier
@required
- (id<ZmsKmmKodein_diDIBinding>)doCopyBuilder:(id<ZmsKmmKodein_diDIContainerBuilder>)builder __attribute__((swift_name("doCopy(builder:)")));
@end;

__attribute__((swift_name("Kodein_diWithContext")))
@protocol ZmsKmmKodein_diWithContext
@required
@property (readonly) id context __attribute__((swift_name("context")));
@end;

__attribute__((swift_name("Kodein_diBindingDI")))
@protocol ZmsKmmKodein_diBindingDI <ZmsKmmKodein_diDirectDI, ZmsKmmKodein_diWithContext>
@required
- (id<ZmsKmmKodein_diBindingDI>)onErasedContext __attribute__((swift_name("onErasedContext()")));
- (id (^)(id _Nullable))overriddenFactory __attribute__((swift_name("overriddenFactory()")));
- (id (^ _Nullable)(id _Nullable))overriddenFactoryOrNull __attribute__((swift_name("overriddenFactoryOrNull()")));
@end;

__attribute__((swift_name("Kodein_diScopeCloseable")))
@protocol ZmsKmmKodein_diScopeCloseable
@required
- (void)close __attribute__((swift_name("close()")));
@end;

__attribute__((swift_name("Kodein_diScopeRegistry")))
@interface ZmsKmmKodein_diScopeRegistry : ZmsKmmBase <ZmsKmmKodein_diScopeCloseable>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)clear __attribute__((swift_name("clear()")));
- (void)close __attribute__((swift_name("close()")));
- (id)getOrCreateKey:(id)key sync:(BOOL)sync creator:(ZmsKmmKodein_diReference<id> *(^)(void))creator __attribute__((swift_name("getOrCreate(key:sync:creator:)")));
- (id _Nullable (^ _Nullable)(void))getOrNullKey_:(id)key __attribute__((swift_name("getOrNull(key_:)")));
- (void)removeKey_:(id)key __attribute__((swift_name("remove(key_:)")));
- (id)values __attribute__((swift_name("values()")));
@end;

__attribute__((swift_name("Kodein_diDIDefining")))
@interface ZmsKmmKodein_diDIDefining<C, A, T> : ZmsKmmBase
- (instancetype)initWithBinding:(id<ZmsKmmKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule __attribute__((swift_name("init(binding:fromModule:)"))) __attribute__((objc_designated_initializer));
@property (readonly) id<ZmsKmmKodein_diDIBinding> binding __attribute__((swift_name("binding")));
@property (readonly) NSString * _Nullable fromModule __attribute__((swift_name("fromModule")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diDIDefinition")))
@interface ZmsKmmKodein_diDIDefinition<C, A, T> : ZmsKmmKodein_diDIDefining<C, A, T>
- (instancetype)initWithBinding:(id<ZmsKmmKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule tree:(id<ZmsKmmKodein_diDITree>)tree __attribute__((swift_name("init(binding:fromModule:tree:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithBinding:(id<ZmsKmmKodein_diDIBinding>)binding fromModule:(NSString * _Nullable)fromModule __attribute__((swift_name("init(binding:fromModule:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (readonly) id<ZmsKmmKodein_diDITree> tree __attribute__((swift_name("tree")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinTriple")))
@interface ZmsKmmKotlinTriple<__covariant A, __covariant B, __covariant C> : ZmsKmmBase
- (instancetype)initWithFirst:(A _Nullable)first second:(B _Nullable)second third:(C _Nullable)third __attribute__((swift_name("init(first:second:third:)"))) __attribute__((objc_designated_initializer));
- (A _Nullable)component1 __attribute__((swift_name("component1()")));
- (B _Nullable)component2 __attribute__((swift_name("component2()")));
- (C _Nullable)component3 __attribute__((swift_name("component3()")));
- (ZmsKmmKotlinTriple<A, B, C> *)doCopyFirst:(A _Nullable)first second:(B _Nullable)second third:(C _Nullable)third __attribute__((swift_name("doCopy(first:second:third:)")));
- (BOOL)equalsOther:(id _Nullable)other __attribute__((swift_name("equals(other:)")));
- (int32_t)hashCode __attribute__((swift_name("hashCode()")));
- (NSString *)toString __attribute__((swift_name("toString()")));
@property (readonly) A _Nullable first __attribute__((swift_name("first")));
@property (readonly) B _Nullable second __attribute__((swift_name("second")));
@property (readonly) C _Nullable third __attribute__((swift_name("third")));
@end;

__attribute__((swift_name("Kodein_diSearchSpecs")))
@interface ZmsKmmKodein_diSearchSpecs : ZmsKmmBase
- (instancetype)initWithContextType:(id<ZmsKmmKodein_typeTypeToken> _Nullable)contextType argType:(id<ZmsKmmKodein_typeTypeToken> _Nullable)argType type:(id<ZmsKmmKodein_typeTypeToken> _Nullable)type tag:(id _Nullable)tag __attribute__((swift_name("init(contextType:argType:type:tag:)"))) __attribute__((objc_designated_initializer));
- (NSString *)description __attribute__((swift_name("description()")));
@property id<ZmsKmmKodein_typeTypeToken> _Nullable argType __attribute__((swift_name("argType")));
@property id<ZmsKmmKodein_typeTypeToken> _Nullable contextType __attribute__((swift_name("contextType")));
@property id _Nullable tag __attribute__((swift_name("tag")));
@property id<ZmsKmmKodein_typeTypeToken> _Nullable type __attribute__((swift_name("type")));
@end;

__attribute__((swift_name("Kodein_diExternalSource")))
@protocol ZmsKmmKodein_diExternalSource
@required
- (id (^ _Nullable)(id _Nullable))getFactoryDi:(id<ZmsKmmKodein_diBindingDI>)di key:(ZmsKmmKodein_diDIKey<id, id, id> *)key __attribute__((swift_name("getFactory(di:key:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection")))
@interface ZmsKmmKotlinKTypeProjection : ZmsKmmBase
- (instancetype)initWithVariance:(ZmsKmmKotlinKVariance * _Nullable)variance type:(id<ZmsKmmKotlinKType> _Nullable)type __attribute__((swift_name("init(variance:type:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKotlinKTypeProjectionCompanion *companion __attribute__((swift_name("companion")));
- (ZmsKmmKotlinKVariance * _Nullable)component1 __attribute__((swift_name("component1()")));
- (id<ZmsKmmKotlinKType> _Nullable)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmKotlinKTypeProjection *)doCopyVariance:(ZmsKmmKotlinKVariance * _Nullable)variance type:(id<ZmsKmmKotlinKType> _Nullable)type __attribute__((swift_name("doCopy(variance:type:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) id<ZmsKmmKotlinKType> _Nullable type __attribute__((swift_name("type")));
@property (readonly) ZmsKmmKotlinKVariance * _Nullable variance __attribute__((swift_name("variance")));
@end;

__attribute__((swift_name("Ktor_httpHeaderValueWithParameters")))
@interface ZmsKmmKtor_httpHeaderValueWithParameters : ZmsKmmBase
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<ZmsKmmKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) ZmsKmmKtor_httpHeaderValueWithParametersCompanion *companion __attribute__((swift_name("companion")));
- (NSString * _Nullable)parameterName:(NSString *)name __attribute__((swift_name("parameter(name:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *content __attribute__((swift_name("content")));
@property (readonly) NSArray<ZmsKmmKtor_httpHeaderValueParam *> *parameters __attribute__((swift_name("parameters")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType")))
@interface ZmsKmmKtor_httpContentType : ZmsKmmKtor_httpHeaderValueWithParameters
- (instancetype)initWithContentType:(NSString *)contentType contentSubtype:(NSString *)contentSubtype parameters:(NSArray<ZmsKmmKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(contentType:contentSubtype:parameters:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithContent:(NSString *)content parameters:(NSArray<ZmsKmmKtor_httpHeaderValueParam *> *)parameters __attribute__((swift_name("init(content:parameters:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly, getter=companion) ZmsKmmKtor_httpContentTypeCompanion *companion __attribute__((swift_name("companion")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (BOOL)matchPattern:(ZmsKmmKtor_httpContentType *)pattern __attribute__((swift_name("match(pattern:)")));
- (BOOL)matchPattern_:(NSString *)pattern __attribute__((swift_name("match(pattern_:)")));
- (ZmsKmmKtor_httpContentType *)withParameterName:(NSString *)name value:(NSString *)value __attribute__((swift_name("withParameter(name:value:)")));
- (ZmsKmmKtor_httpContentType *)withoutParameters __attribute__((swift_name("withoutParameters()")));
@property (readonly) NSString *contentSubtype __attribute__((swift_name("contentSubtype")));
@property (readonly) NSString *contentType __attribute__((swift_name("contentType")));
@end;

__attribute__((swift_name("Ktor_httpParameters")))
@protocol ZmsKmmKtor_httpParameters <ZmsKmmKtor_utilsStringValues>
@required
@property (readonly) ZmsKmmKtor_httpUrlEncodingOption *urlEncodingOption __attribute__((swift_name("urlEncodingOption")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrl.Companion")))
@interface ZmsKmmKtor_httpUrlCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_httpUrlCompanion *shared __attribute__((swift_name("shared")));
@end;

__attribute__((swift_name("KotlinCharIterator")))
@interface ZmsKmmKotlinCharIterator : ZmsKmmBase <ZmsKmmKotlinIterator>
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (id)next __attribute__((swift_name("next()")));
- (unichar)nextChar __attribute__((swift_name("nextChar()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpURLProtocol.Companion")))
@interface ZmsKmmKtor_httpURLProtocolCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_httpURLProtocolCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmKtor_httpURLProtocol *)createOrDefaultName:(NSString *)name __attribute__((swift_name("createOrDefault(name:)")));
@property (readonly) ZmsKmmKtor_httpURLProtocol *HTTP __attribute__((swift_name("HTTP")));
@property (readonly) ZmsKmmKtor_httpURLProtocol *HTTPS __attribute__((swift_name("HTTPS")));
@property (readonly) ZmsKmmKtor_httpURLProtocol *SOCKS __attribute__((swift_name("SOCKS")));
@property (readonly) ZmsKmmKtor_httpURLProtocol *WS __attribute__((swift_name("WS")));
@property (readonly) ZmsKmmKtor_httpURLProtocol *WSS __attribute__((swift_name("WSS")));
@property (readonly) NSDictionary<NSString *, ZmsKmmKtor_httpURLProtocol *> *byName __attribute__((swift_name("byName")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpUrlEncodingOption")))
@interface ZmsKmmKtor_httpUrlEncodingOption : ZmsKmmKotlinEnum<ZmsKmmKtor_httpUrlEncodingOption *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) ZmsKmmKtor_httpUrlEncodingOption *default_ __attribute__((swift_name("default_")));
@property (class, readonly) ZmsKmmKtor_httpUrlEncodingOption *keyOnly __attribute__((swift_name("keyOnly")));
@property (class, readonly) ZmsKmmKtor_httpUrlEncodingOption *valueOnly __attribute__((swift_name("valueOnly")));
@property (class, readonly) ZmsKmmKtor_httpUrlEncodingOption *noEncoding __attribute__((swift_name("noEncoding")));
+ (ZmsKmmKotlinArray<ZmsKmmKtor_httpUrlEncodingOption *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreParentJob")))
@protocol ZmsKmmKotlinx_coroutines_coreParentJob <ZmsKmmKotlinx_coroutines_coreJob>
@required
- (ZmsKmmKotlinCancellationException *)getChildJobCancellationCause __attribute__((swift_name("getChildJobCancellationCause()")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreSelectInstance")))
@protocol ZmsKmmKotlinx_coroutines_coreSelectInstance
@required
- (void)disposeOnSelectHandle:(id<ZmsKmmKotlinx_coroutines_coreDisposableHandle>)handle __attribute__((swift_name("disposeOnSelect(handle:)")));
- (id _Nullable)performAtomicTrySelectDesc:(ZmsKmmKotlinx_coroutines_coreAtomicDesc *)desc __attribute__((swift_name("performAtomicTrySelect(desc:)")));
- (void)resumeSelectWithExceptionException:(ZmsKmmKotlinThrowable *)exception __attribute__((swift_name("resumeSelectWithException(exception:)")));
- (BOOL)trySelect __attribute__((swift_name("trySelect()")));
- (id _Nullable)trySelectOtherOtherOp:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp * _Nullable)otherOp __attribute__((swift_name("trySelectOther(otherOp:)")));
@property (readonly) id<ZmsKmmKotlinContinuation> completion __attribute__((swift_name("completion")));
@property (readonly) BOOL isSelected __attribute__((swift_name("isSelected")));
@end;

__attribute__((swift_name("KotlinSuspendFunction0")))
@protocol ZmsKmmKotlinSuspendFunction0 <ZmsKmmKotlinFunction>
@required

/**
 @note This method converts instances of CancellationException to errors.
 Other uncaught Kotlin exceptions are fatal.
*/
- (void)invokeWithCompletionHandler:(void (^)(id _Nullable_result, NSError * _Nullable))completionHandler __attribute__((swift_name("invoke(completionHandler:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kodein_diReference")))
@interface ZmsKmmKodein_diReference<__covariant T> : ZmsKmmBase
- (instancetype)initWithCurrent:(T)current next:(T _Nullable (^)(void))next __attribute__((swift_name("init(current:next:)"))) __attribute__((objc_designated_initializer));
- (T)component1 __attribute__((swift_name("component1()")));
- (T _Nullable (^)(void))component2 __attribute__((swift_name("component2()")));
- (ZmsKmmKodein_diReference<T> *)doCopyCurrent:(T)current next:(T _Nullable (^)(void))next __attribute__((swift_name("doCopy(current:next:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) T current __attribute__((swift_name("current")));
@property (readonly) T _Nullable (^next)(void) __attribute__((swift_name("next")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKVariance")))
@interface ZmsKmmKotlinKVariance : ZmsKmmKotlinEnum<ZmsKmmKotlinKVariance *>
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (instancetype)initWithName:(NSString *)name ordinal:(int32_t)ordinal __attribute__((swift_name("init(name:ordinal:)"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
@property (class, readonly) ZmsKmmKotlinKVariance *invariant __attribute__((swift_name("invariant")));
@property (class, readonly) ZmsKmmKotlinKVariance *in __attribute__((swift_name("in")));
@property (class, readonly) ZmsKmmKotlinKVariance *out __attribute__((swift_name("out")));
+ (ZmsKmmKotlinArray<ZmsKmmKotlinKVariance *> *)values __attribute__((swift_name("values()")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinKTypeProjection.Companion")))
@interface ZmsKmmKotlinKTypeProjectionCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKotlinKTypeProjectionCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmKotlinKTypeProjection *)contravariantType:(id<ZmsKmmKotlinKType>)type __attribute__((swift_name("contravariant(type:)")));
- (ZmsKmmKotlinKTypeProjection *)covariantType:(id<ZmsKmmKotlinKType>)type __attribute__((swift_name("covariant(type:)")));
- (ZmsKmmKotlinKTypeProjection *)invariantType:(id<ZmsKmmKotlinKType>)type __attribute__((swift_name("invariant(type:)")));
@property (readonly) ZmsKmmKotlinKTypeProjection *STAR __attribute__((swift_name("STAR")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueParam")))
@interface ZmsKmmKtor_httpHeaderValueParam : ZmsKmmBase
- (instancetype)initWithName:(NSString *)name value:(NSString *)value __attribute__((swift_name("init(name:value:)"))) __attribute__((objc_designated_initializer));
- (NSString *)component1 __attribute__((swift_name("component1()")));
- (NSString *)component2 __attribute__((swift_name("component2()")));
- (ZmsKmmKtor_httpHeaderValueParam *)doCopyName:(NSString *)name value:(NSString *)value __attribute__((swift_name("doCopy(name:value:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) NSString *value __attribute__((swift_name("value")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpHeaderValueWithParameters.Companion")))
@interface ZmsKmmKtor_httpHeaderValueWithParametersCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_httpHeaderValueWithParametersCompanion *shared __attribute__((swift_name("shared")));
- (id _Nullable)parseValue:(NSString *)value init:(id _Nullable (^)(NSString *, NSArray<ZmsKmmKtor_httpHeaderValueParam *> *))init __attribute__((swift_name("parse(value:init:)")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Ktor_httpContentType.Companion")))
@interface ZmsKmmKtor_httpContentTypeCompanion : ZmsKmmBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) ZmsKmmKtor_httpContentTypeCompanion *shared __attribute__((swift_name("shared")));
- (ZmsKmmKtor_httpContentType *)parseValue:(NSString *)value __attribute__((swift_name("parse(value:)")));
@property (readonly) ZmsKmmKtor_httpContentType *Any __attribute__((swift_name("Any")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicDesc")))
@interface ZmsKmmKotlinx_coroutines_coreAtomicDesc : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(ZmsKmmKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)prepareOp:(ZmsKmmKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
@property ZmsKmmKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreOpDescriptor")))
@interface ZmsKmmKotlinx_coroutines_coreOpDescriptor : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (BOOL)isEarlierThanThat:(ZmsKmmKotlinx_coroutines_coreOpDescriptor *)that __attribute__((swift_name("isEarlierThan(that:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreAtomicOp<id> * _Nullable atomicOp __attribute__((swift_name("atomicOp")));
@end;

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode.PrepareOp")))
@interface ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp : ZmsKmmKotlinx_coroutines_coreOpDescriptor
- (instancetype)initWithAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)next desc:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc *)desc __attribute__((swift_name("init(affected:next:desc:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)finishPrepare __attribute__((swift_name("finishPrepare()")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *affected __attribute__((swift_name("affected")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc *desc __attribute__((swift_name("desc")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *next __attribute__((swift_name("next")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreAtomicOp")))
@interface ZmsKmmKotlinx_coroutines_coreAtomicOp<__contravariant T> : ZmsKmmKotlinx_coroutines_coreOpDescriptor
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeAffected:(T _Nullable)affected failure:(id _Nullable)failure __attribute__((swift_name("complete(affected:failure:)")));
- (id _Nullable)decideDecision:(id _Nullable)decision __attribute__((swift_name("decide(decision:)")));
- (id _Nullable)performAffected:(id _Nullable)affected __attribute__((swift_name("perform(affected:)")));
- (id _Nullable)prepareAffected:(T _Nullable)affected __attribute__((swift_name("prepare(affected:)")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreAtomicOp<id> *atomicOp __attribute__((swift_name("atomicOp")));
@property (readonly) id _Nullable consensus __attribute__((swift_name("consensus")));
@property (readonly) BOOL isDecided __attribute__((swift_name("isDecided")));
@property (readonly) int64_t opSequence __attribute__((swift_name("opSequence")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode")))
@interface ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode : ZmsKmmBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)addLastNode:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("addLast(node:)")));
- (BOOL)addLastIfNode:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)node condition:(ZmsKmmBoolean *(^)(void))condition __attribute__((swift_name("addLastIf(node:condition:)")));
- (BOOL)addLastIfPrevNode:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)node predicate:(ZmsKmmBoolean *(^)(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *))predicate __attribute__((swift_name("addLastIfPrev(node:predicate:)")));
- (BOOL)addLastIfPrevAndIfNode:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)node predicate:(ZmsKmmBoolean *(^)(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *))predicate condition:(ZmsKmmBoolean *(^)(void))condition __attribute__((swift_name("addLastIfPrevAndIf(node:predicate:condition:)")));
- (BOOL)addOneIfEmptyNode:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("addOneIfEmpty(node:)")));
- (ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *> *)describeAddLastNode:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)node __attribute__((swift_name("describeAddLast(node:)")));
- (ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *> *)describeRemoveFirst __attribute__((swift_name("describeRemoveFirst()")));
- (void)helpRemove __attribute__((swift_name("helpRemove()")));
- (ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)nextIfRemoved __attribute__((swift_name("nextIfRemoved()")));
- (BOOL)remove __attribute__((swift_name("remove()")));
- (id _Nullable)removeFirstIfIsInstanceOfOrPeekIfPredicate:(ZmsKmmBoolean *(^)(id _Nullable))predicate __attribute__((swift_name("removeFirstIfIsInstanceOfOrPeekIf(predicate:)")));
- (ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)removeFirstOrNull __attribute__((swift_name("removeFirstOrNull()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) BOOL isRemoved __attribute__((swift_name("isRemoved")));
@property (readonly, getter=next__) id _Nullable next __attribute__((swift_name("next")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *nextNode __attribute__((swift_name("nextNode")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *prevNode __attribute__((swift_name("prevNode")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNode.AbstractAtomicDesc")))
@interface ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc : ZmsKmmKotlinx_coroutines_coreAtomicDesc
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)completeOp:(ZmsKmmKotlinx_coroutines_coreAtomicOp<id> *)op failure:(id _Nullable)failure __attribute__((swift_name("complete(op:failure:)")));
- (id _Nullable)failureAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)affected __attribute__((swift_name("failure(affected:)")));
- (void)finishOnSuccessAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (id _Nullable)onPreparePrepareOp:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("onPrepare(prepareOp:)")));
- (void)onRemovedAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)affected __attribute__((swift_name("onRemoved(affected:)")));
- (id _Nullable)prepareOp:(ZmsKmmKotlinx_coroutines_coreAtomicOp<id> *)op __attribute__((swift_name("prepare(op:)")));
- (BOOL)retryAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
- (ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(ZmsKmmKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable originalNext __attribute__((swift_name("originalNext")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc")))
@interface ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeAddLastDesc<T> : ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc
- (instancetype)initWithQueue:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)queue node:(T)node __attribute__((swift_name("init(queue:node:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (void)finishOnSuccessAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (BOOL)retryAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
- (ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(ZmsKmmKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));
@property (readonly) T node __attribute__((swift_name("node")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *originalNext __attribute__((swift_name("originalNext")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *queue __attribute__((swift_name("queue")));
@end;

__attribute__((swift_name("Kotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc")))
@interface ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeRemoveFirstDesc<T> : ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodeAbstractAtomicDesc
- (instancetype)initWithQueue:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)queue __attribute__((swift_name("init(queue:)"))) __attribute__((objc_designated_initializer));
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer)) __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
- (id _Nullable)failureAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)affected __attribute__((swift_name("failure(affected:)")));
- (void)finishOnSuccessAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("finishOnSuccess(affected:next:)")));
- (void)finishPreparePrepareOp:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNodePrepareOp *)prepareOp __attribute__((swift_name("finishPrepare(prepareOp:)")));
- (BOOL)retryAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(id)next __attribute__((swift_name("retry(affected:next:)")));
- (ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable)takeAffectedNodeOp:(ZmsKmmKotlinx_coroutines_coreOpDescriptor *)op __attribute__((swift_name("takeAffectedNode(op:)")));
- (id)updatedNextAffected:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)affected next:(ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *)next __attribute__((swift_name("updatedNext(affected:next:)")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable affectedNode __attribute__((swift_name("affectedNode")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode * _Nullable originalNext __attribute__((swift_name("originalNext")));
@property (readonly) ZmsKmmKotlinx_coroutines_coreLockFreeLinkedListNode *queue __attribute__((swift_name("queue")));
@property (readonly) T _Nullable result __attribute__((swift_name("result")));
@end;

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
